<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_settings'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $settings_id = $_SESSION['id_upd'];
            $settingsdeleted = 'no';
            $account = $_SESSION['userid'];
            $name = trim($_POST['txt_name']);
            $value = trim($_POST['txt_value']);
            $upd_obj->update_settings($settingsdeleted, $account, $name, $value, $settings_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $settingsdeleted = 'no';
        $account = $_SESSION['userid'];
        $name = trim($_POST['txt_name']);
        $value = trim($_POST['txt_value']);
        if (!empty($name) || !empty($value)) {
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_settings($settingsdeleted, $account, $name, $value);
        }
    }
}
if (isset($_POST['send_sms'])) {
    if (isset($_POST['farmerckbx_pack'])) {
        $farmers = $_POST['farmerckbx_pack'];
        foreach ($farmers as $frmr) {
            $subject = $_POST['subj'];
            $msg = $_POST['msg'];
            $url = 'https://rest.nexmo.com/sms/json?' . http_build_query([
                        'api_key' => '5456a3ca',
                        'api_secret' => '050ffe53e79e4ecd',
                        'to' => '+25' . trim($frmr),
                        'from' => trim($subject),
                        'text' => $msg
            ]);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
        }
        ?><script>alert('message sent ..');</script><?php
    }
}
?>

<html>
    <head>
        <title>
            settings
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_settings.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">   
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div><div class="parts eighty_centered off saved_dialog">
                settings saved successfully!</div>
            <div class="parts eighty_centered  margin_free   new_data_box ">

                <div class="parts margin_free no_bg no_shade_noBorder off"> 
                    <div class="parts margin_free xx_titles whilte_text no_shade_noBorder no_bg">Settings</div>

                    <table class="new_data_table off">
                        <tr><td>name :</td><td> <input type="text"     name="txt_name"  class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                        <tr><td>value :</td><td> <input type="text"     name="txt_value"  class="textbox" value="<?php echo trim(chosen_value_upd()); ?>"   />  </td></tr>
                        <tr><td colspan="2">
                                <?php
                                require_once '../web_db/multi_values.php';
                                ?>
                                <input type="submit" class="confirm_buttons" name="send_settings" value="Save setting"/>
                            </td></tr>
                    </table>
                </div>
                <div class="parts margin_free no_shade_noBorder no_bg">

                    <?php
                    $obj = new multi_values();
                    $obj->get_famers_tel_numbers();
                    ?>


                </div> 

            </div>

        </div>

        <div class="parts eighty_centered datalist_box off" >


            <div class="parts no_shade_noBorder xx_titles no_bg whilte_text ">settings List</div><?php
            $obj = new multi_values();
            $obj->list_settings();
            ?>
        </div>  
    </form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_settingsdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            $id = $_SESSION['id_upd'];
            $settingsdeleted = new multi_values();
            return $settingsdeleted->get_chosen_settings_settingsdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_setting_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            $id = $_SESSION['id_upd'];
            $setting_name = new multi_values();
            return $setting_name->get_chosen_settings_setting_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_settings_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_settings_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_value_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'settings') {
            $id = $_SESSION['id_upd'];
            $value = new multi_values();
            return $value->get_chosen_settings_value($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
