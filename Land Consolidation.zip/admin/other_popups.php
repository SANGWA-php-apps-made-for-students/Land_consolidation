 
<table class="whilte_text no_bg" style="background: none; color: #00fffa; border: none; box-shadow: none; font-weight: bolder;">
    <tr style="border: none;">
        <td>Seeds needed:</td>
        <td>Expected harvest:</td>
        <td>Fertilizer needed</td>
    </tr>
    <tr style="border: none;">
        <td>30  </td>
        <td>40</td>
        <td>230</td>
    </tr>
</table>
