<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_distribution'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();

            $distributiondeleted = 'no';
            $date = date("y-m-d");
            $seed = $_POST['txt_seed_id'];
            $fertilizer = $_POST['txt_fertilizer'];
            $farmer_consLand = $_POST['txt_farmer_consLand'];
            $account = $_SESSION['userid'];

            $qty_seed = $_POST['txt_qty_seed'];
            $qty_fertilizer = $_POST['txt_qty_fertilizer'];
            $expected_harvest = $_POST['txt_expected_harvest'];
            $total_value = $_POST['txt_total_value'];
            $consolidated = $_POST['txt_consolidated'];

            require_once '../web_db/update.php';
            $obj = new new_values();
            $obj->update_distribution($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated, $distribution_id);
        }
    } else {
        $distributiondeleted = 'no';
        $date = date("y-m-d");
        $seed = trim($_POST['txt_seed_id']);
        $farmer_consLand = $_POST['txt_farmer_consLand'];
        $account = $_SESSION['userid'];
        $qty_seed = (!empty($_POST['txt_qty_seed'])) ? $_POST['txt_qty_seed'] : 0;
        $expected_harvest = 0; //$_POST['txt_expected_harvest'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();

//if both seed and fertilizer are empty
        $selected_farmer = $_POST['txt_farmer_id'];
        if (empty($selected_farmer)) {
            ?><script>alert('You have to select the farmer');</script><?php
        } else {

//get seeds, seeds qty needed
// <editor-fold defaultstate="collapsed" desc="--save seed with 0 fert ---">
            $con = new dbconnection();
            $sql = "select  farmer.farmer_id, profile.name,seed.seed_id,  profile.last_name,consolidation.plot, seed.name as seed, 
                plot.area_m_sq, sum(area_m_sq*qty_m_sq) as tot_seed, sum(harvest_rate_m_sq*(area_m_sq*qty_m_sq)) as expharv,
                sum(fertilizer.qty_per_msq * area_m_sq) qty_per_msq
                from consolidation join plot on consolidation.plot = plot.plot_id 
                join seed on consolidation.seed = seed.seed_id 
                join fertilizer on fertilizer.seed = seed.seed_id
                join farmer on plot.farmer = farmer.farmer_id 
                join account on consolidation.account = account.account_id 
                join profile on farmer.profile = profile.profile_id 
                where farmer.farmer_id=:farmer group by farmer_id, seed";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":farmer" => $selected_farmer));
            $exp_harvest = 0;
            while ($row = $stmt->fetch()) {
                $farmerid = $row['farmer_id'];
                $seedid = $row['seed_id'];
                $qtyseed = $row['tot_seed'];
                $qty_fert=$row['qty_per_msq'];
                $exp_harvest = $row['expharv'];

                $obj->new_distribution($distributiondeleted, $date, $seedid, 0, $selected_farmer, $account, $qtyseed, $qty_fert, $exp_harvest, 0, 'yes');
            }

// </editor-fold>
            // <editor-fold defaultstate="collapsed" desc="---save fertilizer with 0 seeds ----">
            //save the fertilizer

            $sql2 = "select fertilizer.fertilizer_id, farmer.farmer_id, profile.name as prof,  profile.last_name, plot.plot_id, 
            fertilizer.qty_per_msq,   plot.area_m_sq, fertilizer.name as fert from plot  
                join farmer on plot.farmer = farmer.farmer_id 
                join profile on farmer.profile = profile.profile_id 
				join account on account.profile = profile.profile_id 
                 join fertilizer_order on fertilizer_order.account = account.account_id 
                 join fertilizer on fertilizer_order.fertilizer = fertilizer.fertilizer_id 
                where  plot.farmer =:farmer group by fertilizer_id";
            $stmt2 = $con->openconnection()->prepare($sql2);
            $stmt2->execute(array(":farmer" => $selected_farmer));

            while ($row2 = $stmt2->fetch()) {
                $fertilizer = $row2['fertilizer_id'];
                $tot_fertilizer = (($row2['area_m_sq'] * $row2['qty_per_msq']) >= 1000) ? ($row2['area_m_sq'] * $row2['qty_per_msq']) / 1000 : ($row2['area_m_sq'] * $row2['qty_per_msq']);
                $obj->new_distribution($distributiondeleted, $date, 0, $fertilizer, $selected_farmer, $account, 0, $tot_fertilizer, $exp_harvest, 0, 'yes');
            }
        }

// </editor-fold>
    }
}
?>

<html>
    <head>
        <title>
            distribution</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            #popup_bx{

                width: 100%;
            }
            #popups{

                right: 0px;
                top: -50px;
                height: 130px;
                width: 60%;
                background-color: #ffffff;
                color: #00450f;
                border: 1px solid ;
                box-shadow: 0px 0px 2px #ffffcc;
                font-size: 12px;
                text-shadow: none;
                font-weight: bolder;
            }
            .calc_links{
                font-size: 12px;
            }
            .loading{
                width: 100px;
                height: 100px;
                background-color: #659175;

            }
            .ready_to_hide{

            }
            .no_border_tab, .no_border_tab tr,  .no_border_tab td{
                border: none;
            }
            #calc_row{
                display: none;
                min-height: 100px;
            }
            .load_bg{
                background-image: url('../web_images/loading.gif');
            }
            .col_highlight_good{
                color: #000e5e;
                font-weight: bolder;
            }
            #alert{
                color: #ff0000;
                font-size: 17px;
                background: none;
            }
        </style>
    </head>  
    <body>
        <form action="new_distribution.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_seed_id"   name="txt_seed_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_farmer_id"   name="txt_farmer_id"/>
            <?php
            include 'admin_header.php';
            include './Foreign_selects.php';
            $obj = new multi_values();
            $res = $obj->get_if_any_plot();
            if ($res >= 2) {
                ?>
                <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                    <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  
                </div>
                <div class="parts eighty_centered off saved_dialog">
                    distribution saved successfully!
                </div>
                <div class="parts eighty_centered new_data_box off">
                    <div class="parts eighty_centered " id="popup_bx">  Distribution

                    </div>

                    <div class="parts eighty_centered">

                    </div>

                    <?php
                    echo farmers_no_plot();
                    ?>
                    <table style="min-width: 300px;">
                        <tr style="background-color: #004f5e;">
                            <td colspan="2" class="whilte_text" id="calc_row">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table border="0" class="no_border_tab">
                                    <tr><td>Farmer:</td><td> 
                                            <input type="hidden"     name="txt_farmer_consLand" required class="textbox" value=" <?php echo chosen_farmer_consLand_upd(); ?> "   /> 
                                            <a href="#" id="foreign_farmer_distr" class="select_link_farmer foreign_select_link">Select</a>
                                            <span id="name_holder"></span> 
                                        </td></tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                    <?php
                } else {
                    echo '<div class="parts eighty_centered no_bg  no_paddin_shade_no_Border"> '
                    . '<div class="parts xx_titles no_bg no_shade_noBorder" id="alert"> You have to add more plots in order to make distribution </div>'
                    . ''
                    . ''
                    . '<br/>'
                    . '<a href="new_plot.php">Go to plots</a>'
                    . '</div>';
                }
                ?>
            </div>

            <div class="parts eighty_centered datalist_box " >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Distribution List</div>
                <?php
                $obj = new multi_values();
                $obj->list_distribution();
                ?>
            </div>      
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_seed_combo() {
    $obj = new multi_values();
    $obj->get_seed_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_fertilizer_combo() {
    $obj = new multi_values();
    $obj->get_fertilizer_in_combo();
}

function chosen_distributiondeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $distributiondeleted = new multi_values();
            return $model->get_chosen_distribution_distributiondeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $model->get_chosen_distribution_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_seed_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $seed = new multi_values();
            return $model->get_chosen_distribution_seed($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_fertilizer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $fertilizer = new multi_values();
            return $model->get_chosen_distribution_fertilizer($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_farmer_consLand_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $farmer_consLand = new multi_values();
            return $model->get_chosen_distribution_farmer_consLand($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $model->get_chosen_distribution_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_qty_seed_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $qty_seed = new multi_values();
            return $model->get_chosen_distribution_qty_seed($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_qty_fertilizer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $qty_fertilizer = new multi_values();
            return $model->get_chosen_distribution_qty_fertilizer($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_expected_harvest_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $expected_harvest = new multi_values();
            return $model->get_chosen_distribution_expected_harvest($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_total_value_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $total_value = new multi_values();
            return $model->get_chosen_distribution_total_value($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_consolidated_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'distribution') {
            $id = $_SESSION['id_upd'];
            $consolidated = new multi_values();
            return $model->get_chosen_distribution_consolidated($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function farmers_no_plot() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = trim($obj->get_unassigned_farmers());
    if ($res > 0) {
        return '<div class="parts no_paddin_shade_no_Border" id="alert">'
                . 'There are farmers (' . tot_frmr_noPlots() . ') without plots. You can assign them plots by going to "Consolidation=>plot" and add their plots'
                . '  </div>';
    } else {
        return '';
    }
}

function tot_frmr_noPlots() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    return $res = trim($obj->get_unassigned_farmers());
}

function save_distribution() {
    $farmer = 42;
    $con = new dbconnection();
    $sql = "select  farmer.farmer_id, profile.name,  profile.last_name,consolidation.plot, seed.name as seed, 
                plot.area_m_sq, sum(area_m_sq*qty_m_sq) as tot_seed, sum(harvest_rate_m_sq*(area_m_sq*qty_m_sq)) as expharv
                from consolidation join plot on consolidation.plot = plot.plot_id 
                join seed on consolidation.seed = seed.seed_id 
                join farmer on plot.farmer = farmer.farmer_id 
                join account on consolidation.account = account.account_id 
                join profile on farmer.profile = profile.profile_id 
                where farmer.farmer_id=:farmer group by farmer_id, seed";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":farmer" => $farmer));

    while ($row = $stmt->fetch()) {
        $farmerid = $row['farmer_id'];
        $seed = $row['tot_seed'];
        echo 'seed: ' . $seed;
        echo '<br/>--------------<br/>';
//                $obj->new_distribution($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated);
    }

// </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="---save fertilizer with 0 seeds ----">
    //save the fertilizer
    echo 'saving the fertilizer ...<br/><br/><br/><br/><br/>';
    $sql2 = "select farmer.farmer_id, profile.name as prof,  profile.last_name, plot.plot_id, 
            fertilizer.qty_per_msq,   plot.area_m_sq, fertilizer.name as fert from plot  
                join farmer on plot.farmer = farmer.farmer_id 
                join profile on farmer.profile = profile.profile_id 
				join account on account.profile = profile.profile_id 
                 join fertilizer_order on fertilizer_order.account = account.account_id 
                 join fertilizer on fertilizer_order.fertilizer = fertilizer.fertilizer_id 
                where  plot.farmer =:farmer group by fertilizer_id";
    $stmt2 = $con->openconnection()->prepare($sql2);
    $stmt2->execute(array(":farmer" => $farmerid));
    while ($row2 = $stmt2->fetch()) {
        echo $row2['farmer_id'] .
        '<br/>' . $row2['prof'] .
        '<br/>' . $row2['last_name'] .
        '<br/>' . $row2['plot_id'] .
        '<br/>' . $row2['fert'] .
        '<br/>Tot area: ' . $row2['area_m_sq'] .
        '<br/>Tot seed: ' . $seed;
        $tot_fertilizer = $row2['area_m_sq'] * $row2['qty_per_msq'];
        echo '<br/> Tot fert: ' . $tot_fertilizer = ($tot_fertilizer >= 1000) ? $tot_fertilizer / 1000 . ' kg' : $tot_fertilizer;

        echo'<br/><br/>+++++++++++++    <br/>';
//                $obj->new_distribution($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated);
    }
}
