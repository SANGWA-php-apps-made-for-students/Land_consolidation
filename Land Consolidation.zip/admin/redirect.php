<?php
    session_start();



if (!empty($_SESSION['table_to_update'])) {
    header('location: new_' . $_SESSION['table_to_update'] . '.php');
    echo $_SESSION['table_to_update'];
} else{
    echo 'the session is not set';
}
