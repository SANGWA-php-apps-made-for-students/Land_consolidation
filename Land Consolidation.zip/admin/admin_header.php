<?php
if (!isset($_SESSION)) {
    session_start();
}
if ($_SESSION['cat'] == 'admin') {
    admin_menu();
} else if ($_SESSION['cat'] == 'farmer') {
    farmer_menu();
} else if ($_SESSION['cat'] == 'agronomist') {
    agronomist_menu();
}

function admin_menu() {
    ?>
    <div class="parts  eighty_centered " style="height: 100px">  
        <div class="parts logo no_bg">

        </div>  
        <div class="parts x_width_4h no_shade_noBorder" style="width: 400px;">
            <div class="parts  no_paddin_shade_no_Border xxx_titles whilte_text " style="width: 700px;">
                CROP CULTIVATION MANAGEMENT SYSTEM
            </div>
        </div>
    </div>       
    <div class="parts menu eighty_centered ">  
        <a href="admin_dashboard.php" class="menu_bg" style="color: #fff;">Dashboard</a>
        <div class="allow_drop">
            <span class="menu_bg">Users</span> 
            <div class="hovable_item">
                <div class="parts s_hov">
                    <a href="new_account.php">account</a>
                    <a href="new_account_category.php">account_category</a>
                    <!--<a href="new_profile.php">profile</a>-->
                </div>
            </div>
        </div>
        <div class="allow_drop">
            <span class="menu_bg"> Locations</span> 
            <div class="hovable_item"> 
                <div class="parts s_hov">
                    <a href="new_sector.php">sector</a>
                    <a href="new_cell.php">cell</a>
                    <!--                    <a href="new_village.php">village</a>-->
                </div>    </div>
        </div>


        <div class="allow_drop">
            <span class="menu_bg"> Plots</span> 
            <div class="hovable_item"> 
                <div class="parts s_hov">
                    <a href="new_plot.php">plot</a>
                    <!--<a href="new_consolidation.php">consolidation</a>-->
                </div>    </div>
        </div>


        <div class="allow_drop">
            <span class="menu_bg">Distribution</span> 
            <div class="hovable_item"> <div class="parts s_hov">
                    <a href="new_seed.php">seed</a>
                    <a href="new_fertilizer.php">fertilizer</a>
                    <a href="new_farmer.php">farmer</a>
                    <!--<a href="new_seed_order.php">Orders</a>-->
                    <a href="new_distribution.php">distribution</a>
                </div>
            </div>
        </div>

        <a href="new_expenses.php"  class="menu_bg" style="margin-left: 23px;  color: #fff;">expenses</a>
        <a href="new_harvest.php" class="menu_bg " style="margin-left: 23px;  color: #fff;">harvest</a>

        <a href="new_settings.php"  class="">
            <div  style="width: 32px; height: 32px; float: right; background-image: url('../web_images/settings.png'); ">

            </div>
        </a>

        <a href="../logout.php"class="menu_bg" style="  background-color: #de3d00; margin-left: 70px;color: #fff; margin-top: 0px;">Logout</a>

    </div>
    <?php
}

function agronomist_menu() {
    ?>
    <div class="parts  eighty_centered ">  
        <div class="parts logo">

        </div>  
        <div class="parts x_width_4h no_shade_noBorder">
            <div class="parts  no_paddin_shade_no_Border xxx_titles whilte_text">
                E-Hinga Land Consolidation
            </div>
        </div>
    </div>       
    <div class="parts menu eighty_centered ">  
        <a href="admin_dashboard.php" class="menu_bg" style="color: #fff;">Dashboard</a>



        <div class="allow_drop">
            <span class="menu_bg"> Locations</span> 
            <div class="hovable_item"> 
                <div class="parts s_hov">
                    <a href="new_sector.php">sector</a>
                    <a href="new_cell.php">cell</a>
                    <!--                    <a href="new_village.php">village</a>-->
                </div>    </div>
        </div>



        <div class="allow_drop">
            <span class="menu_bg"> Consolidation</span> 
            <div class="hovable_item"> 
                <div class="parts s_hov">
                    <a href="new_plot.php">plot</a>
                    <a href="new_consolidation.php">consolidation</a>
                </div>    
            </div>
        </div>
        <div class="allow_drop">
            <span class="menu_bg">Distribution</span> 
            <div class="hovable_item"> 
                <div class="parts s_hov">
                    <a href="new_seed.php">seed</a>
                    <a href="new_fertilizer.php">fertilizer</a>
                    <a href="new_seed_order.php">Orders</a>
                    <a href="new_farmer.php">farmer</a>
                    <a href="new_distribution.php">distribution</a>
                </div>
            </div>
        </div>
        <a href="new_expenses.php"  class="menu_bg"        style="margin-left: 23px;  color: #fff;">expenses</a>
        <a href="new_harvest.php" class="menu_bg" style="margin-left: 23px;  color: #fff;">harvest</a>
        <a href="new_settings.php"  class="">
            <div  style="width: 32px; height: 32px; float: right;      background-image: url('../web_images/settings.png'); ">

            </div>
        </a>
        <a href="../logout.php"class="menu_bg" style="  background-color: #de3d00; margin-left: 70px;color: #fff; margin-top: 0px;">Logout</a>
    </div>
    <?php
}

function farmer_menu() {
    ?>
    <div class="parts  eighty_centered ">  
        <div class="parts logo">

        </div>  
        <div class="parts x_width_4h no_shade_noBorder">
            <div class="parts  no_paddin_shade_no_Border xxx_titles whilte_text">
                E-Hinga Land Consolidation
            </div>
        </div>
    </div>       
    <div class="parts menu eighty_centered ">  
        <a href="admin_dashboard.php" class="menu_bg" style="color: #fff;">Dashboard</a>
        <a href="new_seed_order.php" class="menu_bg" style="margin-left: 23px;  color: #fff;">seed order</a>
        <a href="new_fertilizer_order.php" class="menu_bg" style="margin-left: 23px;  color: #fff;">fertilizer order</a>

        <a href="../logout.php"class="menu_bg" style="  background-color: #de3d00; margin-left: 70px;color: #fff; margin-top: 0px;">Logout</a>

    </div>    
    <?php
}
