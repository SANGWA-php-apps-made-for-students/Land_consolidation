 
<div class="parts abs_full off foreign_select">

</div>  
<div class="parts dialog eighty_centered off no_paddin_shade_no_Border"   >
    <div class="parts title margin_free full_center_two_h heit_free no_shade_noBorder ">
        <span class="dialog_title">Title</span>
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="farmer">
        <?php list_selectable_farmer() ?> 
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="farmer_with_plots">
        <?php list_selectable_farmer_with_plots() ?> 
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="farmer_no_plot">
        <?php list_selectable_farmer_no_plots() ?> 
    </div>
    <div class="parts tables off no_shade_noBorder reverse_border" id="farmer_chk">
        <?php list_selectable_farmer_chkbox() ?> 
        <div class="parts full_center_two_h heit_free">
            <a href="#" class="hide_checkbox" style="color: #000;">Confirm</a>
        </div> 
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="distribution">
        <?php list_selectable_distribution()//this is found on the harvest page ?> 
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="distribution_expense">
        <?php list_selectable_distribution_expense()//this is found on the harvest page ?> 
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="plots_with_cells">
        <div class="parts  margin_free full_center_two_h heit_free no_shade_noBorder no_bg ">
            <div class="parts link_cursor" id="hide_famer_btn">Show/Hide Farmers' Plot</div>
        </div>
        <?php list_plot_with_cells() ?> 
    </div>

    <div class="parts tables  off no_shade_noBorder reverse_border" id="delete_stock">
        <div class="parts two_fifty_left  yes_no_btns" id="del_yes" >Yes</div>
        <div class="parts two_fifty_right yes_no_btns" id="del_no">No</div>
    </div>
</div>
<?php
//selectables
require_once '../web_db/connection.php';

function list_selectable_farmer() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, profile.name,  profile.last_name,  farmer.profile  from profile
                    join farmer on farmer.profile = profile.profile_id
                 join image on profile.image = image.image_id  ";
    ?>
    <table class="dataList_table">
        <thead>
            <tr><td> Farmer ID </td>
                <td> name </td>
                <td> Has a plot </td>
                <td> last_name </td> 
                <td> Plot consolidated </td>
                <td> Option </td> 
            </tr>
        </thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td class="farmerid_cols"> <?php echo $row['farmer_id']; ?> </td>
                <td class="farmer_name">   <?php echo $row['name']; ?> </td>
                <?php
                if (!get_if_farmer_has_plot($row['farmer_id'])) {
                    ?> <td class="col_highlight">   <?php echo $has = (get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td><?php
                } else {
                    ?>
                    <td>        <?php echo $has = (get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td>
                <?php } ?>
                <td class="farmer_name">   <?php echo $row['last_name']; ?> </td>
                <td class="cons_not">   <?php
                    echo $found = (farmer_consolidated($row['farmer_id']) == TRUE) ? 'Consolidated' : 'Not consolidated';
                    ?> </td>
                <td> <a href="#" class="select_link_farmer" value="<?php echo $row['farmer_id']; ?>">select</a> </td>

            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_farmer_with_plots() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, profile.name,  profile.last_name,  farmer.profile  from profile
                    join farmer on farmer.profile = profile.profile_id
                    join plot on plot.farmer = farmer.farmer_id 
                 join image on profile.image = image.image_id 
                 group by  farmer.farmer_id";
    ?>
    <table class="dataList_table">
        <thead>
            <tr><td> Farmer ID </td>
                <td> name </td>
                <td> Has a plot </td>
                <td> last_name </td> 
                <td> Plot consolidated </td>
                <td> Option </td> 
            </tr>
        </thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td class="farmerid_cols"> <?php echo $row['farmer_id']; ?> </td>
                <td class="farmer_name">   <?php echo $row['name']; ?> </td>
                <?php
                if (!get_if_farmer_has_plot($row['farmer_id'])) {
                    ?> <td class="col_highlight">   <?php echo $has = (get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td><?php
                } else {
                    ?>
                    <td>        <?php echo $has = (get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td>
                <?php } ?>
                <td class="farmer_name">   <?php echo $row['last_name']; ?> </td>
                <td class="cons_not">   <?php
                    echo $found = (farmer_consolidated($row['farmer_id']) == TRUE) ? 'Consolidated' : 'Not consolidated';
                    ?> </td>
                <td> <a href="#" class="select_link_farmer" value="<?php echo $row['farmer_id']; ?>">select</a> </td>

            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_farmer_no_plots() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, profile.name,  profile.last_name,  farmer.profile  from profile
                    join farmer on farmer.profile = profile.profile_id
                 join image on profile.image = image.image_id  
                 where farmer.farmer_id not in (select plot.farmer from plot )";
    ?>
    <table class="dataList_table">
        <thead>
            <tr><td> Farmer ID </td>
                <td> name </td>
                <td> Plot consolidated </td>
                <td> last_name </td> 
                <td> Option </td> 
            </tr>
        </thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td class="farmerid_cols"> <?php echo $row['farmer_id']; ?> </td>
                <td class="farmer_name">   <?php echo $row['name']; ?> </td>
                <td class="farmer_name">   <?php echo $row['last_name']; ?> </td>
                <td class="cons_not">   <?php
                    echo $found = (farmer_consolidated($row['farmer_id']) == TRUE) ? 'Consolidated' : 'Not consolidated';
                    ?> </td>
                <td> <a href="#" class="select_link_farmer" value="<?php echo $row['farmer_id']; ?>">select</a> </td>

            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_farmer_chkbox() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, profile.name,  profile.last_name,  profile.dob
            from profile
             join farmer on farmer.profile = profile.profile_id 
             join plot on plot.farmer = farmer.farmer_id 
             where plot.plot_id not in (select plot from consolidation) ";
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td>  <input  type="checkbox" name="farmerckbx"  class="farmr_chk_all"/> </td>
                <td> Farmer ID </td>

                <td> name </td>
                <td> Last name </td>

                <td>Delete</td>

            </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr>

                <td class="profile_id_col">
                    <input type="checkbox" name="farmerckbx_pack[]"  value="<?php echo $row['farmer_id'] ?>"  class="farmr_chkbx"/>
                </td>
                <td>
                    <?php echo $row['farmer_id']; ?>
                </td>
                <td>
                    <?php echo $row['name']; ?>
                </td>
                <td>
                    <?php echo $row['last_name']; ?>
                </td>
                <td class="profile_names_col">
                    <?php echo $row['name']; ?>
                </td>

            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_distribution() {//this is for harvest
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, distribution.distribution_id,  distribution.date,  distribution.qty_seed,  distribution.qty_fertilizer, "
            . " distribution.expected_harvest,  distribution.total_value, profile.name,  profile.last_name from distribution   "
            . " join farmer on distribution.farmer_consLand=farmer.farmer_id "
            . "  join profile on farmer.profile = profile.profile_id  "
            . " where distribution.distribution_id not in (select distribution from harvest)"
            . " group by farmer_id";
    ?>
    <table class="dataList_table">
        <thead>
            <tr>
                <td> Distr. ID </td>
                <td> date </td><td> name </td><td> last_name </td>
                <td> Quanatity seed</td>
                <td> qty_fertilizer </td>
                <td> expected_harvest </td>
                <td> total_value </td>

                <td>Option</td>
            </tr>
        </thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 

                <td class="distrId_cols">
                    <?php echo $row['distribution_id']; ?>
                </td>
                <td class="distr_date_cols">
                    <?php echo $row['date']; ?>
                </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['last_name']; ?> </td>
                <td>
                    <?php
                    echo
                    $row['qty_seed'];
                    ?>
                </td>
                <td>
                    <?php echo $row['qty_fertilizer']; ?>
                </td>
                <td>
                    <?php echo $row['expected_harvest']; ?>
                </td>
                <td>
                    <?php echo $row['total_value']; ?>
                </td>

                <td>
                    <a href="#" class="select_link_distribution" style="color: #000080;" value="
                       <?php echo $row['distribution_id']; ?>">Select</a>
                </td>
            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_distribution_expense() {//this is for harvest
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select farmer.farmer_id, distribution.distribution_id,  distribution.date,  distribution.qty_seed,  distribution.qty_fertilizer, "
            . " distribution.expected_harvest,  distribution.total_value, profile.name,  profile.last_name from distribution   "
            . " join farmer on distribution.farmer_consLand=farmer.farmer_id "
            . "  join profile on farmer.profile = profile.profile_id  "
            . " where  distribution.distribution_id not in (select distribution from expenses)"
            . " group by farmer_id";
    ?>
    <table class="dataList_table">
        <thead>
            <tr>
                <td> Distr. ID </td>
                <td> date </td><td> name </td><td> last_name </td>
                <td> Quanatity seed</td>
                <td> qty_fertilizer </td>
                <td> expected_harvest </td>
                <td> total_value </td>

                <td>Option</td>
            </tr>
        </thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td class="distrId_cols">
                    <?php echo $row['distribution_id']; ?>
                </td>
                <td class="distr_date_cols">
                    <?php echo $row['date']; ?>
                </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['last_name']; ?> </td>
                <td>
                    <?php
                    echo
                    $row['qty_seed'];
                    ?>
                </td>
                <td>
                    <?php echo $row['qty_fertilizer']; ?>
                </td>
                <td>
                    <?php echo $row['expected_harvest']; ?>
                </td>
                <td>
                    <?php echo $row['total_value']; ?>
                </td>

                <td>
                    <a href="#" class="select_link_distribution" style="color: #000080;" value="
                       <?php echo $row['distribution_id']; ?>">Select</a>
                </td>
            </tr>
        <?php } ?></table>
    <?php
}

function list_plot_with_cells() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select cell.cell_id, cell.name,  sector.name as sector from cell   join sector on cell.sector = sector.sector_id   ";
    ?>
    <table class="dataList_table cellz_plots_tab">
        <thead><tr>
                <td> cell </td>
                <td> Cell name </td>
                <td>Option</td>
            </tr></thead>
        <?php
        foreach ($db->query($sql) as $row) {
            ?><tr> 
                <td class="plotcell_cellid_cols">
                    <?php echo $row['cell_id']; ?>
                </td>
                <td class="cell_name_cols cell " title="cell" >
                    <?php echo $row['name'] . ' <b>(' . get_tot_plot_by_cell($row['cell_id']) . ' plots)</b>';
                    ?>
                </td>

                <td><a href="#" class="cell_select_link" value="<?php echo $row['cell_id'] ?>"     >Select</a></td>
            </tr> 
            <tr class="corr_plots"><td colspan="7">
                    <?php get_plot_by_village($row['cell_id']) ?>
                </td>
            </tr>
        <?php } ?></table>
    <?php
}

function get_plot_by_village($cell_id) {
    $con = new dbconnection();
    $sql = "select farmer.farmer_id, profile.name,
                    profile.last_name, plot.estimated_value,    profile.gender,  profile.telephone_number, 
                    profile.email,  profile.residence  
                    from farmer
                    join profile on farmer.profile = profile.profile_id 
                    join plot on plot.farmer = farmer.farmer_id 
                    join cell on plot.village = cell.cell_id 
                    where plot.village=:cell and  plot.plot_id not in (select plot from consolidation)";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":cell" => $cell_id));
    ?>
    <table class="corr_plots_tab">
        <thead>
            <tr class="corr_plots_tab_head">
                <td> farmer_id </td>
                <td> Farmer name </td>
                <td> Farmer last_name </td>
                <td> Plot estimated_value </td>
                <td> gender </td>
                <td> telephone_number </td>
                <td> email </td>
                <td> residence </td>

            </tr></thead><?php
        while ($row = $stmt->fetch()) {
            ?><tr>   
                <td>        <?php echo $row['farmer_id']; ?> </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['last_name']; ?> </td>
                <td>        <?php echo $row['estimated_value']; ?> </td>
                <td>        <?php echo $row['gender']; ?> </td>
                <td>        <?php echo $row['telephone_number']; ?> </td>
                <td>        <?php echo $row['email']; ?> </td>
                <td>        <?php echo $row['residence']; ?> </td>

            </tr>
        <?php } ?></table>
    <?php
}

function farmer_consolidated($farmer) {
    $con = new dbconnection();
    $sql = "select farmer.farmer_id from farmer
                     where farmer_id  in 
                    (select farmer.farmer_id
                 from consolidation
                 join plot on consolidation.plot = plot.plot_id 
                 join farmer on plot.farmer = farmer.farmer_id )
                        and farmer.farmer_id=:farmerid";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array("farmerid" => $farmer));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $res = $row['farmer_id'];
    if ($res > 0) {
        return TRUE;
    } else {
        return FALSE;
    }
}

function get_tot_plot_by_cell($cell) {//noon consolidated
    $con = new dbconnection();
    $sql = "select  count(*) as tot_plots from cell  join plot on plot.village = cell.cell_id  "
            . " where cell.cell_id=:cellid and plot.plot_id not in (select plot from consolidation) ";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":cellid" => $cell));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['tot_plots'];
    return $userid;
}

function get_if_farmer_has_plot($farmer) {
    $con = new dbconnection();
    $sql = "select plot.farmer
                from plot
                join farmer on plot.farmer = farmer.farmer_id 
                where farmer.farmer_id=:farmer";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":farmer" => $farmer));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $res = $row['farmer'];
    if ($res > 0) {
        return true;
    } else {
        return false;
    }
}

function df() {
    require_once('../web_db/connection.php');
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select profile.name,  profile.last_name
 from profile

 join image on profile.image = image.image_id 
 join profile on farmer.profile = profile.profile_id 
[]";
    ?>
    <table class="new_data_table">
        <thead><tr>
                <td> name </td><td> last_name </td>
            </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['last_name']; ?> </td>

            </tr>
        <?php } ?></table>
    <?php
}
