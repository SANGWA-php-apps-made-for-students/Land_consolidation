<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_consolidation'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $consolidationdeleted = 'no';
            $date = date("y-m-d");
            $account = $_POST['txt_account_id'];
            $plot = $_POST['txt_plot_id'];
            $given_number = $_POST['txt_given_number'];
            require_once '../web_db/update.php';
            $obj = new new_values();
            $obj->update_consolidation($consolidationdeleted, $date, $account, $plot, $given_number, $consolidation_id);
        }
    } else {
        $consolidationdeleted = 'no';
        $date = date("y-m-d");
        $account = $_SESSION['userid'];
        $plot = $_POST['txt_plot_id'];
        $seed = trim($_POST['txt_seed_id']);
        require_once '../web_db/multi_values.php';
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $mul = new multi_values();
//        $farmers = $_POST['farmerckbx_pack'];
        $sess_array = array();
        $c = 0;
        $working_cell = $_POST['txt_selected_cell'];
        $first = $mul->get_first_plot_by_cell($working_cell);
        $last = $mul->get_last_plot_by_cell($working_cell);
        $auto_give_number = $first . '-' . $last;

        //select the range of the plots and save them in the consolidation table
        // <editor-fold defaultstate="collapsed" desc="-----save the consolidation ------">
        $con = new dbconnection();
        $sql = "select plot_id from plot where plot_id>=:splot and plot_id<=:gplot and plot.village=:plot";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":splot" => $first, ":gplot" => $last, ":plot" => $working_cell));


        $c = 0;
        if ($first < $last) {//we have to check also of the farmer has plots in different areas, if so the sys has to consolidate by the cell
            while ($row = $stmt->fetch()) {
                $plot_id = $row['plot_id'];
                $obj->new_consolidation($consolidationdeleted, $date, $account, $plot_id, $auto_give_number, $seed);
            }

            // </editor-fold>
        } else {
            ?><script>alert('Consolidation must be only when there are more that one plots');</script><?php
        }
    }
}
?>

<html>
    <head>
        <title>
            consolidation</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            #alert{
                color: #ffbbbb;
                /*font-size: 14px;*/
                background: none;
            }
            #tab_larger{
                min-width: 300px;
            }
            #tab_larger a{
                color: #fff;

            }
            .corr_plots{
                background-color: #78bfad;
            }
            .corr_plots_tab{
                font-size: 13px;
            }
            .corr_plots_tab_head{
                background-color: #417e77;
                font-size: 13px;

            }
            .cell_select_link{
                color: #417e77;   
            }
            #hide_famer_btn{
                background-color: #2fff2a;
            }
            .btn_switch{
                border: 1px solid #fff;
                background-color: #eb6a00;
                box-shadow: none;
            }
            .big_shade{
                box-shadow: 0px 0px 10px  #da00ff;
            }     #alert{
                color: #ff0000;
                font-size: 17px;
                background: none;
            }
        </style>
    </head> 
    <body>
        <form action="new_consolidation.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_plot_id"   name="txt_plot_id"/>
            <input type="hidden" id="txt_seed_id"   name="txt_seed_id"/>
            <input type="hidden"  placeholder="first plot" id="txt_selected_cell"   name="txt_selected_cell"/>
            <?php
            include './Foreign_selects.php';
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  
            </div>
            <div class="parts eighty_centered off saved_dialog">
                consolidation saved successfully!</div>
            <div class="parts eighty_centered new_data_box off ">
                <div class="parts eighty_centered ">  
                    <?php echo farmers_no_plot(); ?>
                </div>
                <?php
                $obj = new multi_values();
                $res2 = $obj->get_if_any_seed();
                if ($res2 < 1) {
                    echo '<div class="parts no_paddin_shade_no_Border" id="alert">'
                    . 'There are no seed regostered in the system. First add some and then proceed'
                    . '  <br/><a class="color:#000fff;" href="new_seed.php">Go to seed</a></div>';
                } else {
                    ?>
                    <div class="parts xx_titles whilte_text no_bg no_shade_noBorder ">
                        Consolidation
                    </div>
                    <table class="new_data_table" id="tab_larger" >
                        <tr class="off"><td>date :</td><td> <input type="text"     name="txt_date" required class="textbox" value=" <?php echo chosen_date_upd(); ?> "   />  </td></tr>
                        <tr>
                            <td>Select By cell:</td>
                            <td>
                                <a id="foreign_plots_by_cell" href="#">select</a>
                                <span id="selected_cell_name"></span>
                            </td>
                        </tr>
                        <tr><td>Select seed :</td><td> 
                                <?php get_seed_combo(); ?>
                            </td></tr> 
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_consolidation" value="Save"/>  </td></tr>
                    </table>
                <?php } ?>
            </div>

            <div class="parts eighty_centered datalist_box">
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Consolidation List (<?php
                    $obj = new multi_values();
                    echo 'about ' . $obj->get_tot_consolidation_sumary() . ' consolidations,  Consolidating: ' . $obj->get_tot_consolidation() . ' Plots';
                    ?>)</div>
                <div class="parts full_center_two_h heit_free no_bg no_paddin_shade_no_Border">
                    <div class="parts link_cursor whilte_text btn_switch" id="btn_cons_sumary">summary</div><div class="parts btn_switch link_cursor whilte_text" id="btn_cons_det">details</div>
                </div>
                <div class="parts no_paddin_shade_no_Border no_bg" id="cons_summary">
                    <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Consolidation Summary</div>
                    <?php
                    $obj->list_consolidation_summary();
                    ?>
                </div>
                <div class="parts no_bg no_paddin_shade_no_Border off" id="cons_details">
                    <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Consolidation details</div>
                    <?php $obj->list_consolidation_no_summary(); ?>
                </div>

                <div class="parts full_center_two_h heit_free no_bg xx_titles no_shade_noBorder top_off_xx">
                    Plots by cells</div><?php
                $obj->list_cell_with_plots_consolidated();
                ?>

            </div>  
            <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script>
                $(document).ready(function () {
                    $('#btn_cons_sumary').unbind('click').click(function () {
                        $('.btn_switch').removeClass('big_shade');
                        $(this).addClass('big_shade');

                        $('#cons_summary').show(function () {
                            $('#cons_details').hide();
                        });
                    });
                    $('#btn_cons_det').unbind('click').click(function () {
                        $('.btn_switch').removeClass('big_shade');
                        $(this).addClass('big_shade');
                        $('#cons_details').show(function () {
                            $('#cons_summary').hide();
                        });
                    });
                });
        </script>
    </body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_plot_combo() {
    $obj = new multi_values();
    $obj->get_plot_in_combo();
}

function get_seed_combo() {
    $obj = new multi_values();
    $obj->get_seed_in_combo();
}

function chosen_consolidationdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            $id = $_SESSION['id_upd'];
            $consolidationdeleted = new multi_values();
            return $model->get_chosen_consolidation_consolidationdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $date->get_chosen_consolidation_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_consolidation_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_plot_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            $id = $_SESSION['id_upd'];
            $plot = new multi_values();
            return $plot->get_chosen_consolidation_plot($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_given_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'consolidation') {
            $id = $_SESSION['id_upd'];
            $given_number = new multi_values();
            return $given_number->get_chosen_consolidation_given_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function farmers_no_plot() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = trim($obj->get_unassigned_farmers());
    $res2 = $obj->get_if_any_seed();
    if ($res > 0) {
        return '<div class="parts no_paddin_shade_no_Border" id="alert">'
                . 'There are farmers (' . tot_frmr_noPlots() . ') without plots. You can assign them plots by going to "Consolidation=>plot" and add their plots'
                . '  </div>';
    }
}

function tot_frmr_noPlots() {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    return $res = trim($obj->get_unassigned_farmers());
}
