<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>


    </head>
    <body>


        <?php
        require_once '../web_db/report.php';

        $rep = new app_report();
        $rep->get_general_report_with_button();
        ?>








        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script> 
        <script type="text/javascript">
            function print_page() {
                var ButtonControl = document.getElementById("print_general_report");
                ButtonControl.style.visibility = "hidden";
                window.print();
            }
        </script>
    </body>
</html>


