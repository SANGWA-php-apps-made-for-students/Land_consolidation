<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_harvest'])) {
    if (isset($_POST['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $harvestdeleted = 'no';
            $date = date("y-m-d");
            $farmer_consolidation = 'yes';
            $distribution = $_POST['txt_distribution_id'];
            $quantity_harvested = $_POST['txt_quantity_harvested'];
            require_once '../web_db/update.php';
            $obj = new new_values();
            $obj->update_harvest($harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $harvest_id);
        }
    } else {
        $harvestdeleted = 'no';
        $date = date("y-m-d");
        $farmer_consolidation = 'yes';
        $distribution = $_POST['txt_distribution_id'];
        $quantity_harvested = $_POST['txt_quantity_harvested'];
        $cost_per_unit = $_POST['txt_cost_per_unit'];
        if (!empty($_POST['txt_distribution_id'])) {//even though it is written farmer on the front page inside we save distribution id
            get_distrid_by_farmer($distribution, $harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $cost_per_unit);
        } else {
            ?><script>alert('You have to select the distribution')</script><?php
        }
    }
}
?>

<html>
    <head>
        <title>
            harvest</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_harvest.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_distr_harvst_id"   name="txt_distribution_id"/>
            <?php
            include 'admin_header.php';
            include './Foreign_selects.php';
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            $res = $obj->get_if_any_distribution();
            if ($res > 0) {
                ?>
                <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                    <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  
                </div>
                <div class="parts eighty_centered off saved_dialog">
                    harvest saved successfully!</div>
                <div class="parts eighty_centered new_data_box off">
                    <div class="parts eighty_centered ">  harvest</div>
                    <table class="new_data_table">
                        <tr class="off"><td>farmer_consolidation :</td><td> 
                                <input type="text"     name="txt_farmer_consolidation" required class="textbox" value=" <?php echo chosen_farmer_consolidation_upd(); ?> "   />  </td></tr>
                        <tr><td>Farmer :</td><td> 
                                <a href="#" id="foreign_harvest" class="select_link_farmer foreign_select_link">Select</a>
                                <span id="selected_distr_harvest"></span> 
                            </td></tr><tr><td>quantity harvested (Kg):</td><td> <input type="text"     name="txt_quantity_harvested" required class="textbox" value="<?php echo chosen_quantity_harvested_upd(); ?>"   />  </td></tr>
                        <tr><td>cost per unit :</td><td> <input type="text"     name="txt_cost_per_unit" required class="textbox only_numbers" value="<?php echo trim(chosen_cost_per_unit_upd()); ?>"   />  </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_harvest" value="Save"/>  </td></tr>
                    </table>
                </div>

                <?php
            } else {
                echo '<div class="parts eighty_centered no_bg  no_paddin_shade_no_Border"> '
                . '<div class="parts xx_titles no_bg no_shade_noBorder" id="alert"> You have to add more distributions in the system </div>'
                . ''
                . ''
                . '<br/>'
                . '<a href="new_distribution.php">Go to distribution</a>'
                . '</div>';
            }
            ?>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Harvest report</div>
                <?php
                $obj = new multi_values();
                $obj->list_harvest();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_distribution_combo() {
    $obj = new multi_values();
    $obj->get_distribution_in_combo();
}

function chosen_harvestdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $harvestdeleted = new multi_values();
            return $model->get_chosen_harvest_harvestdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $model->get_chosen_harvest_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_farmer_consolidation_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $farmer_consolidation = new multi_values();
            return $model->get_chosen_harvest_farmer_consolidation($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_distribution_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $distribution = new multi_values();
            return $model->get_chosen_harvest_distribution($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_quantity_harvested_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $quantity_harvested = new multi_values();
            return $model->get_chosen_harvest_quantity_harvested($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_cost_per_unit_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'harvest') {
            $id = $_SESSION['id_upd'];
            $cost_per_unit = new multi_values();
            return $cost_per_unit->get_chosen_harvest_cost_per_unit($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_distrid_by_farmer($consolidation, $harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $cost_per_unit) {
    $con = new dbconnection();
    $sql1 = "select    farmer_consLand  from distribution   
                where distribution.distribution_id =:farmer";
    $stmt1 = $con->openconnection()->prepare($sql1);
    $stmt1->execute(array(":farmer" => $consolidation));
    $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
    $farmer = $row1['farmer_consLand'];

    $sql = "select distribution.distribution_id
                    from distribution 
                    where   distribution.farmer_consLand =:farmer";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":farmer" => $farmer));
    while ($row = $stmt->fetch()) {
        //here goes the distribution_ids list 
        //after we have to save the distribution id in the database
        $distribution = $row['distribution_id'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_harvest($harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $cost_per_unit);
    }
}
