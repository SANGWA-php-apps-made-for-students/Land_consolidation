<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .count_div div{
                background-color: #659d5f;
                font-size:   14px;
                color: #ffffff;
                border: 1px solid #fff;
                text-transform: capitalize;
                min-height: 50px;
            }
            .count_div{
                background: none;
            }
            .dataList_table{
                background-color: #fff;
                color: #003d11;

            }
            .dataList_table tr{
                border: 1px solid #00847d;
            }

            .rep_distr_row{
                background-color: #1faf8e;
            }
            .rep_exp_row{
                background-color: #129c7d;
            }
            .rep_harv_row{
                background-color: #19834e;
            }
            .dataList_table thead{
                background: none;

            }
            .dataList_table td{
                text-align: center;
            }
            .dataList_table .top_header{
                border-bottom:  2px solid #fff;
            }
        </style>
    </head>
    <body>
        <form action="admin_dashboard.php" method="post">
            <?php
            require_once './admin_header.php';
            ?>
            <div class="part eighty_centered">
                <?php if ($_SESSION['cat'] == 'admin' || $_SESSION['cat'] == 'agronomist') { ?>
                    <div class="parts full_center_two_h heit_free no_bg no_shade_noBorder">
                        <?php
                        require_once '../web_db/report.php';

                        $rep = new app_report();
                        $rep->get_general_report_summary();
                        ?>
                    </div>
                <?php } ?>
            </div>

            <div class="parts eighty_centered no_bg no_shade_noBorder no_bg"> 
                <div class="parts xx_titles whilte_text no_bg no_paddin_shade_no_Border">Welcome dear <?php echo $_SESSION['cat'] . ', ' ?> <?php echo $_SESSION['names']; ?></div>

                <div class="parts x_titles no_paddin_shade_no_Border no_bg whilte_text">Brief summary</div>
                <div class="parts no_bg no_shade_noBorder">


                    <?php
                    require_once '../web_db/multi_values.php';
                    $count = new multi_values();
                    //Counting all records ...
                    require_once '../web_db/multi_values.php';
                    $count_obj = new multi_values();

                    if (!isset($_SESSION)) {
                        session_start();
                    }
                    if ($_SESSION['cat'] == 'admin' || $_SESSION['cat'] == 'agronomist') {
                        echo '<div class="whilte_text count_div no_bg">
                        <div class="parts fixed_box_xx">account<br/>' . $count_obj->All_account() . '</div>                
                        <div class="parts fixed_box_xx">Users <br/>categories<br/>' . $count_obj->All_account_category() . '</div>                
                        <div class="parts fixed_box_xx">profile<br/>' . $count_obj->All_profile() . '</div>                
                        <div class="parts fixed_box_xx">image<br/>' . $count_obj->All_image() . '</div>                
                                                                         
                        <div class="parts fixed_box_xx">cell<br/>' . $count_obj->All_cell() . '</div>                
                        <div class="parts fixed_box_xx">village<br/>' . $count_obj->All_village() . '</div>                
                        <div class="parts fixed_box_xx">seed<br/>' . $count_obj->All_seed() . '</div>                
                        <div class="parts fixed_box_xx">fertilizer<br/>' . $count_obj->All_fertilizer() . '</div>                
                        <div class="parts fixed_box_xx">settings<br/>' . $count_obj->All_settings() . '</div>                
                        <div class="parts fixed_box_xx">farmer<br/>' . $count_obj->All_farmer() . '</div>                
                        <div class="parts fixed_box_xx">plot<br/>' . $count_obj->All_plot() . '</div>                
                        <div class="parts fixed_box_xx">consolidation<br/>' . $count_obj->All_consolidation() . '</div>                
                        <div class="parts fixed_box_xx">Seasons<br/>(distribution)<br/>' . $count_obj->All_distribution() . '</div>                
                        <div class="parts fixed_box_xx">expenses<br/>' . $count_obj->All_expenses() . '</div>                
                        <div class="parts fixed_box_xx">harvest<br/>' . $count_obj->All_harvest() . '</div>  ' .
                        '<div class="parts fixed_box_xx ">seed<br/>order<br/>' . $count_obj->All_seed_order() . '</div>                
                        <div class="parts fixed_box_xx ">fertilizer<br/>order<br/>' . $count_obj->All_fertilizer_order() . '</div>   </div>';
                    } else if ($_SESSION['cat'] == 'farmer') {
                        echo '<div class="whilte_text count_div no_bg">
                      <div class="parts fixed_box_xx">seed<br/>' . $count_obj->All_seed() . '</div>                
                        <div class="parts fixed_box_xx">fertilizer<br/>' . $count_obj->All_fertilizer() . '</div>                
                         <div class="parts fixed_box_xx">expenses<br/>' . $count_obj->All_expenses() . '</div>                
                        <div class="parts fixed_box_xx">harvest<br/>' . $count_obj->All_harvest() . '</div>  </div>              ';
                    } else if ($_SESSION['cat'] == 'agronomist') {
                        echo '<div class="whilte_text count_div no_bg">
                                                                         
                          <div class="parts fixed_box_xx">seed<br/>' . $count_obj->All_seed() . '</div>                
                        <div class="parts fixed_box_xx">fertilizer<br/>' . $count_obj->All_fertilizer() . '</div>                
                        <div class="parts fixed_box_xx">settings<br/>' . $count_obj->All_settings() . '</div>                
                        <div class="parts fixed_box_xx">farmer<br/>' . $count_obj->All_farmer() . '</div>                
                        <div class="parts fixed_box_xx">plot<br/>' . $count_obj->All_plot() . '</div>                
                        <div class="parts fixed_box_xx">consolidation<br/>' . $count_obj->All_consolidation() . '</div>                
                        <div class="parts fixed_box_xx">Seasons<br/>(distribution)<br/>' . $count_obj->All_distribution() . '</div>                
                        <div class="parts fixed_box_xx">expenses<br/>' . $count_obj->All_expenses() . '</div>                
                        <div class="parts fixed_box_xx">harvest<br/>' . $count_obj->All_harvest() . '</div>  </div>              ';
                    }



//End conting all records .
                    ?>

                </div>

            </div>
        </form>
    </body>
</html>
