<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_plot'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'plot') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $plotdeleted = 'no';
            $area_m_sq = $_POST['txt_area_m_sq'];
            $estimated_value = $_POST['txt_estimated_value'];
            $farmer = $_POST['txt_farmer_id'];
            $village = $_POST['txt_cell_id'];

            require_once '../web_db/update.php';
            $obj = new new_values();
            $obj->update_plot($plotdeleted, $area_m_sq, $estimated_value, $farmer, $plot_id);
        }
    } else {
        $plotdeleted = 'no';
        $area_m_sq = trim($_POST['txt_area_m_sq']);
        $estimated_value = $_POST['txt_estimated_value'];
        $farmer = $_POST['txt_farmer_id'];
        $village = $_POST['txt_cell_id'];

        require_once '../web_db/new_values.php';
        require_once '../web_db/multi_values.php';
        $mult2 = new multi_values();
        $obj = new new_values();
        if (!empty($farmer)) {
            //check if the farmer already has a plot and consolidate plot.
            $consolidated = $_POST['txt_cconsolidated'];

            $new_plot_address = trim($mult2->get_plot_address($farmer));
            // if chesen the farmer, selected cell is same as  the other plots of the farmer 

            $obj->new_plot($plotdeleted, $area_m_sq, $estimated_value, $farmer, $village);
            //here the person already has a consolidated land and the address of his pl
            //get the given number of his plot
            $given_number = $mult2->get_given_number_by_farmer($farmer);
            $plot_id = $mult2->get_plot_by_farmer($farmer);

            //get the seed assigned to the area
            $seed = $mult2->get_seed_by_farmerconsol($farmer);
            $consolidationdeleted = $plotdeleted;
            $date = date("y-m-d");
            $account = $_SESSION['userid'];
 
            //get the last plot id
            //Get the cellid
            $village = $mult2->get_plot_address($farmer);
            $last_seed = $mult2->get_last_seed();
            
            $obj->new_plot($plotdeleted, $area_m_sq, $estimated_value, $farmer, $village);
            $last_plotid = $mult2->get_last_plot();
            $obj->new_consolidation($consolidationdeleted, $date, $account, $last_plotid, $given_number, $last_seed);
        } else {
            ?><script>alert('You have to choose a farmer to save the plot!!');</script><?php
        }
    }
}
?>

<html>
    <head>
        <title>
            Plot</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .sml_font{
                font-size: 12px;
                color: #e2ff00;
            }
        </style>
    </head>   
    <body>
        <form action="new_plot.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_farmer_id"     name="txt_farmer_id"/>
            <input type="hidden" id="txt_cell_id"       name="txt_cell_id"  placeholder="cell"/>
            <input type="hidden" id="txt_cconsolidated" name="txt_cconsolidated"/>
            <?php include './Foreign_selects.php'; ?>

            <?php
            include 'admin_header.php';
            require_once '../web_db/multi_values.php';
            $obj = new multi_values();
            $res = $obj->get_if_any_farmer();
            if ($res > 0) {
                ?>
                <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                    <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  
                </div>
                <div class="parts eighty_centered off saved_dialog">
                    plot saved successfully!</div>
                <div class="parts eighty_centered new_data_box off">
                    <div class="parts eighty_centered ">  plot</div>
                    <table class="new_data_table">
                        <tr><td>area m<sup>2</sup><br/><span class="sml_font">
                                    1 hactare=10,000m<sup>2</sup></span> :</td><td> 
                                <input type="text" placeholder="in meter square"    name="txt_area_m_sq" required class="textbox" value="<?php echo chosen_area_m_sq_upd(); ?>"   />  </td></tr>
                        <tr><td>estimated_value :</td><td> <input type="text"     name="txt_estimated_value" required class="textbox" value="<?php echo chosen_estimated_value_upd(); ?>"   />  </td></tr>
                        <tr><td>farmer :</td><td>
                                <a href="#" id="foreign_farmer" class="select_link_farmer foreign_select_link">Select</a>
                                <span id="name_holder"></span> 
                            </td></tr>
                        <tr><td>Cell :</td><td> <?php get_village_combo(); ?>  </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_plot" value="Save"/>  </td></tr>
                    </table>
                </div>

                <?php
            } else {
                echo '<div class="parts eighty_centered no_bg  no_paddin_shade_no_Border"> '
                . '<div class="parts xx_titles no_bg no_shade_noBorder" id="alert"> You have to add more farmers in the system!! </div>'
                . ''
                . ''
                . '<br/>'
                . '<a href="new_farmer.php">Go to Farmers</a>'
                . '</div>';
            }
            ?>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">All plots available</div>
                <div class="parts seventy_centered no_bg heit_free no_shade_noBorder no_paddin_shade_no_Border" style="border: none;">
                    <table class="full_center_two_h heit_free no_shade_noBorder" style="border: none;">
                        <tr>
                            <td>Cell</td>
                            <td><?php get_cell_in_combo_search(); ?>
                            </td>
                            <td class="off"><input type="text" autocomplete="off" placeholder="Enter farmer's name" class="textbox txt_search" name="txt_name"  />  </td><td> <input type="button" class="confirm_buttons btn_search" value="Search" />  </td>
                        </tr>
                    </table>
                </div>
                <div class="parts full_center_two_h heit_free no_shade_noBorder no_bg my_res">
                    <?php
                    $obj = new multi_values();
                    $obj->list_cell_with_plots_consolidated();
                    ?>
                </div>
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">All plots available</div>
                <?php
                $obj->list_plot();
                ?>
            </div>  
        </form>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script>
                $('.btn_search').click(function () {
                    var plot_by_cell = $('.cbo_cell_search option:selected').text();
//                        alert(plot_by_cell);
                    $.post('handler.php', {plot_by_cell: plot_by_cell}, function (data) {
                        $('.my_res').html(data);
                    }).complete(function () {
//                            alert('finished');
                    });
                });
        </script>
    </body>
</hmtl>
<?php

function get_farmer_combo() {
    $obj = new multi_values();
    $obj->get_farmer_in_combo();
}

function get_cell_in_combo_search() {
    $obj = new multi_values();
    $obj->get_cell_search_in_combo();
}

function get_village_combo() {
    $obj = new multi_values();
    $obj->get_cell_in_combo();
}

function chosen_plotdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'plot') {
            $id = $_SESSION['id_upd'];
            $plotdeleted = new multi_values();
            return $model->get_chosen_plot_plotdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_area_m_sq_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'plot') {
            $id = $_SESSION['id_upd'];
            $area_m_sq = new multi_values();
            return $model->get_chosen_plot_area_m_sq($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_estimated_value_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'plot') {
            $id = $_SESSION['id_upd'];
            $estimated_value = new multi_values();
            return $model->get_chosen_plot_estimated_value($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_farmer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'plot') {
            $id = $_SESSION['id_upd'];
            $farmer = new multi_values();
            return $model->get_chosen_plot_farmer($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
