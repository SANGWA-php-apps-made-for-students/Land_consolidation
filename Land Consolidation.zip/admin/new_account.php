<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_account'])) {

    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $account_category = $_POST['txt_account_category_id'];
            $date_created = date("y-m-d");
            $profile = $_POST['txt_profile_id'];
            $username = $_POST['txt_username'];
            $password = $_POST['txt_password'];
            $is_online = 'no';
            require_once '../web_db/update.php';
            $obj->update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id);
        }
    } else {
        require_once '../web_db/multi_values.php';
        $obj2 = new multi_values();
        //save the image
        save_image();
        $last_image = $obj2->get_lastimage();
        //save the profile
        $dob = $_POST['txt_dob'];
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $gender = $_POST['txt_gender'];
        $telephone_number = $_POST['txt_telephone_number'];
        $email = $_POST['txt_email'];
        $residence = $_POST['txt_residence'];
        $image = 1;
        $objn = new new_values();
        $objn->new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $last_image);
        $last_profile = $obj2->get_lastprofile();

        //account
        $account_category = filter_input(INPUT_POST, 'txt_account_category_id');
        $date_created = date("y-m-d");
        $profile = $last_profile;
        $username = $email;
        $password = trim($_POST['txt_password']);
        $is_online = 'no';
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_account($account_category, $date_created, $profile, $username, $password, $is_online);

        //get the category name
        $obj_mul = new multi_values();
        $name_category = trim($obj_mul->get_cat_name_byId(trim($account_category)));

        if ($name_category == 'farmer') {
            //create his id in farmer table
            $obj->new_farmer('no', $last_profile);
        }
    }
}
?>
<html>
    <head>
        <title>
            account</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/ui_scripts/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>   
    </head>   <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/>
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div> 
            </div>
            <div class="parts eighty_centered off saved_dialog">
                account saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  account</div>
                <table>
                    <tr>
                        <td>
                            <table>
                                <tr><td>account_category :</td><td> <?php get_account_category_combo(); ?>  </td></tr>
                                <tr><td>username :</td><td>
                                        <input type="email"     name="txt_email" required class="textbox" value="<?php echo trim(chosen_email_upd()); ?>"   /> 

                                    </td></tr>
                                <tr><td>password :</td><td> <input type="password"     name="txt_password" required class="textbox" value="<?php echo trim(chosen_password_upd()); ?>"   />  </td></tr>
                                <tr><td>dob :</td><td> <input type="text"  id="date"   name="txt_dob" required class="textbox" value="<?php echo trim(chosen_dob_upd()); ?>"   />  </td></tr>
                                <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" value="<?php echo trim(chosen_name_upd()); ?>"   />  </td></tr>
                                <tr><td>last_name :</td><td> <input type="text"     name="txt_last_name" required class="textbox" value="<?php echo trim(chosen_last_name_upd()); ?>"   />  </td></tr>
                            </table>
                        </td>
                        <td>
                            <table class="new_data_table">
                                <tr><td>gender :</td><td> 
                                        <select name="txt_gender" required  class="textbox">
                                            <option></option>
                                            <option>Male</option>
                                            <option>Female</option>
                                        </select>

                                    </td></tr>
                                <tr><td>telephone_number :</td><td> <input type="text"     name="txt_telephone_number" required class="textbox" value="<?php echo chosen_telephone_number_upd(); ?>"   />  </td></tr>
                                <tr class="off"><td>email :</td><td>  <input type="email"    name="txt_username"  class="textbox" value="<?php echo trim(chosen_username_upd()); ?>"   /> </td></tr>
                                <tr><td>residence :</td><td> <input type="text"     name="txt_residence" required class="textbox" value="<?php echo chosen_residence_upd(); ?>"   />  </td></tr>
                                <tr><td>image :</td><td> <input type="file" required="" name="txt_path" />
                                    </td></tr>
                                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_account" value="Save"/>  </td></tr>
                            </table>

                        </td>
                    </tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box no_paddin_shade_no_Border">
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Users List</div>
                <div class="parts  margin_free full_center_two_h heit_free no_shade_noBorder no_bg ">
                    <div class="parts link_cursor" id="hide_famer_btn">Show/Hide Users details</div>
                </div>
                <?php
                $obj = new multi_values();
                $obj->list_accounts_by_categories();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('#date').datepicker({
                    dateFormat: 'yy-mm-dd',
                    maxDate: '1980-01-01'
                });
            });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_account_category_combo() {
    $obj = new multi_values();
    $obj->get_account_category_in_combo();
}

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function chosen_account_category_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $account_category = new multi_values();
            return $model->get_chosen_account_account_category($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_created_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $date_created = new multi_values();
            return $model->get_chosen_account_date_created($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $profile = new multi_values();
            return $model->get_chosen_account_profile($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_username_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $username = new multi_values();
            return $username->get_chosen_account_username($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_password_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $password = new multi_values();
            return $password->get_chosen_account_password($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_is_online_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'account') {
            $id = $_SESSION['id_upd'];
            $is_online = new multi_values();
            return $is_online->get_chosen_account_is_online($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

//profile

function get_image_combo() {
    $obj = new multi_values();
    $obj->get_image_in_combo();
}

function chosen_dob_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $dob = new multi_values();
            return $model->get_chosen_profile_dob($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $model->get_chosen_profile_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_last_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $last_name = new multi_values();
            return $model->get_chosen_profile_last_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_gender_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $gender = new multi_values();
            return $model->get_chosen_profile_gender($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_telephone_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $telephone_number = new multi_values();
            return $model->get_chosen_profile_telephone_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_email_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $email = new multi_values();
            return $model->get_chosen_profile_email($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_residence_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $residence = new multi_values();
            return $residence->get_chosen_profile_residence($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_image_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'profile') {
            $id = $_SESSION['id_upd'];
            $image = new multi_values();
            return $image->get_chosen_profile_image($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function save_image() {
    $target_dir = "../web_images/people/";
    $target_file = $target_dir . basename($_FILES["txt_path"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;
    $file_with_noExtension = basename($target_file, $ExtensionWithDot);
//save the image in folder (upload)

    require_once '../web_db/multi_values.php';
    $obj2 = new multi_values();
//Last profile
    $img = $obj2->get_lastprofile();
    $newname = $img . '.' . $imageFileType;
    $new_target_file = $target_dir . $newname;

    require_once '../web_db/new_values.php';
    $new = new new_values();
    $new->new_image($newname);

    $target_file_for_db = $new_target_file;

// Check if image file is a actual image or fake image
    if (isset($_POST["send"])) {
        $check = getimagesize($_FILES["txt_path"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }
// Check if file already exists
    if (file_exists($target_file)) {
//        echo "Sorry, file already exists.";
//        $uploadOk = 0;
    }
// Check file size
    if ($_FILES["txt_path"]["size"] > 3000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
//                    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["txt_path"]["tmp_name"], $new_target_file)) {
            
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
