<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_expenses'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $expensesdeleted = 'no';
            $date = date("y-m-d");
            $distribution = $_POST['txt_distribution_id'];
            $expense_name = $_POST['txt_expense_name'];
            $total_cost = $_POST['txt_total_cost'];
            $upd_obj->update_expenses($expensesdeleted, $date, $distribution, $expense_name, $total_cost, $expenses_id);
        }
    } else {
        $expensesdeleted = 'no';
        $date = date("y-m-d");
        $distribution = $_POST['txt_distribution_id'];
        $expense_name = $_POST['txt_expense_name'];
        $total_cost = $_POST['txt_total_cost'];
        get_distrid_by_farmer($distribution, $expensesdeleted, $date, $distribution, $expense_name, $total_cost);
    }
}
?>

<html>
    <head>
        <title>
            expenses</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head> 
    <body>
        <form action="new_expenses.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_distribution_id"   name="txt_distribution_id"/>
            <?php
            include 'admin_header.php';
            include './Foreign_selects.php';
            $obj = new multi_values();
            $res = $obj->get_if_any_distribution();
            if ($res > 0) {
                ?>

                <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                    <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  
                </div>
                <div class="parts eighty_centered off saved_dialog">
                    expenses saved successfully!</div>
                <div class="parts eighty_centered new_data_box off">
                    <div class="parts eighty_centered ">  expenses</div>
                    <table class="new_data_table">
                        <tr><td>Select farmer:</td><td>
                                <a href="#" id="foreign_distribution" class="select_link_farmer foreign_select_link">Select</a>
                                <span id="selected_profile"></span> 
                            </td>
                        </tr>
                        <tr><td>expense_name :</td><td> 

                                <select class="textbox" required  name="txt_expense_name">
                                    <option></option>
                                    <option>Transport</option>
                                    <option>watering</option>
                                    <option>cultivating</option>
                                    <option>mowing</option>
                                    <option>security</option>
                                    </option>
                                </select>

                            </td></tr>
                        <tr><td>Cost :</td><td> <input type="text"     name="txt_total_cost" required class="textbox" value="<?php echo chosen_total_cost_upd(); ?>"   />  </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_expenses" value="Save"/>  </td></tr>
                    </table>
                </div>

                <?php
            } else {
                echo '<div class="parts eighty_centered no_bg  no_paddin_shade_no_Border"> '
                . '<div class="parts xx_titles no_bg no_shade_noBorder" id="alert"> You have to add more distributions in the system </div>'
                . ''
                . ''
                . '<br/>'
                . '<a href="new_distribution.php">Go to Distribution</a>'
                . '</div>';
            }
            ?>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Expenses report</div>
                <?php
                $obj = new multi_values();
                $obj->list_expenses();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_distribution_combo() {
    $obj = new multi_values();
    $obj->get_distribution_in_combo();
}

function chosen_expensesdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            $id = $_SESSION['id_upd'];
            $expensesdeleted = new multi_values();
            return $model->get_chosen_expenses_expensesdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $model->get_chosen_expenses_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_distribution_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            $id = $_SESSION['id_upd'];
            $distribution = new multi_values();
            return $model->get_chosen_expenses_distribution($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_expense_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            $id = $_SESSION['id_upd'];
            $expense_name = new multi_values();
            return $model->get_chosen_expenses_expense_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_total_cost_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'expenses') {
            $id = $_SESSION['id_upd'];
            $total_cost = new multi_values();
            return $model->get_chosen_expenses_total_cost($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_distrid_by_farmer($consolidation, $expensesdeleted, $date, $distribution, $expense_name, $total_cost) {
    $con = new dbconnection();
    $sql1 = "select    farmer_consLand  from distribution   
                where distribution.distribution_id =:farmer";
    $stmt1 = $con->openconnection()->prepare($sql1);
    $stmt1->execute(array(":farmer" => $consolidation));
    $row1 = $stmt1->fetch(PDO::FETCH_ASSOC);
    $farmer = $row1['farmer_consLand'];


    $sql = "select distribution.distribution_id
                    from distribution 
                    where   distribution.farmer_consLand =:farmer";
    $stmt = $con->openconnection()->prepare($sql);
    $stmt->execute(array(":farmer" => $farmer));
    while ($row = $stmt->fetch()) {
        //here goes the distribution_ids list 
        //after we have to save the distribution id in the database
        $distribution = $row['distribution_id'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_expenses($expensesdeleted, $date, $distribution, $expense_name, $total_cost);
    }
}
