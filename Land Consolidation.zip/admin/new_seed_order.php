<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_seed_order'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $seed_order_id = $_SESSION['id_upd'];
            $seed_orderdeleted = $_POST['txt_seed_orderdeleted'];
            $date = $_POST['txt_date'];
            $seed = $_POST['txt_seed_id'];
            $account = $_POST['txt_account_id'];
            $quantity = $_POST['txt_quantity'];
            $unit_measure = 'kg';

            $upd_obj->update_seed_order($seed_orderdeleted, $date, $seed, $account, $quantity, $unit_measure, $seed_order_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $seed_orderdeleted = 'no';
        $date = date("y-m-d");
        $mul = new multi_values();
        $farmerid = $mul->get_farmer_id_by_account($_SESSION['userid']);
        $seeid = $mul->get_seed_by_farmerconsol($farmerid);
        $seed = $seeid;
        $account = $_SESSION['userid'];
        $quantity = $_POST['txt_quantity'];
        $unit_measure = 'kg';

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_seed_order($seed_orderdeleted, $date, $seed, $account, $quantity, $unit_measure);
    }
}
?>

<html>
    <head>
        <title>
            seed_order</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_seed_order.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_seed_id"   name="txt_seed_id"/><input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div><div class="parts eighty_centered off saved_dialog">
                seed_order saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  seed_order</div>
                <div class="parts no_shade_noBorder no_bg x_titles">
                    <?php
                    if ($_SESSION['cat'] == 'agronomist' || $_SESSION['cat'] == 'admin') {
                        
                    } else {
                        $obj = new multi_values();
                        $farmerid = $obj->get_farmer_id_by_account($_SESSION['userid']);
                        $nseeds = $obj->get_seed_by_farmerconsol_count($farmerid);
                        $seeid = $obj->get_seed_by_farmerconsol($farmerid);
                        $seed_name = $obj->get_seed_name_by_the_seed_id($seeid);
                        if (empty($seeid)) {
                            echo '  Dear Farmer you can\'t make an order yet. Your account is not fully setup yet';
                        } else if ($nseeds == 1) {
                            echo '  ' . $nseeds . '  -  Dear Farmer the seed to cultivate on your field is: <b><u>' . $seed_name . '</u></b>'
                            . '<br/> You can just add the quantity';
                        }
                    }
                    ?>
                </div>
                <?php if (!empty($seeid)) { ?>
                    <table class="new_data_table">
                        <?php
                        $obj = new multi_values();
                        $frmr = $obj->get_farmer_id_by_account($_SESSION['userid']);
                        $nseeds = $obj->get_seed_by_farmerconsol_count($frmr);
                        if ($nseeds > 1) {
                            ?>
                            <tr><td>seed :</td><td>
                                    <?php
                                    require_once '../web_db/connection.php';
                                    $con = new dbconnection();
                                    $sql = "select  distinct seed.name as seed,seed_id from consolidation 
                                            join plot on consolidation.plot = plot.plot_id 
                                            join seed on consolidation.seed = seed.seed_id 
                                            join farmer on plot.farmer = farmer.farmer_id  
                                            where plot.farmer =:name";
                                    $stmt = $con->openconnection()->prepare($sql);
                                    $stmt->execute(array(":name" => $frmr));
                                    ?>
                                    <select  class="textbox cbo_seed"><option></option>
                                        <?php
                                        while ($row = $stmt->fetch()) {
                                            echo "<option value=" . $row['seed_id'] . ">" . $row['seed'] . " </option>";
                                        }
                                        ?>
                                    </select>
                                    <?php
                                    ?>

                                </td></tr>
                        <?php } ?>
                        <tr><td>quantity (Kg) :</td><td> <input type="text"     name="txt_quantity" required class="textbox" value=" <?php echo trim(chosen_quantity_upd()); ?> "   />  </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_seed_order" value="Save"/>  </td></tr>
                    </table><?php } ?>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Orders List</div><?php
                $obj = new multi_values();
                if ($_SESSION['cat'] == 'admin' || $_SESSION['cat'] == 'agronomist') {
                    $obj->get_oders_seed_fertilizer();
                } else {
                    $obj->get_seed_order_by_acc($_SESSION['userid']);
                }
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_seed_combo() {
    $obj = new multi_values();
    $obj->get_seed_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_seed_orderdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $seed_orderdeleted = new multi_values();
            return $seed_orderdeleted->get_chosen_seed_order_seed_orderdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $date->get_chosen_seed_order_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_seed_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $seed = new multi_values();
            return $seed->get_chosen_seed_order_seed($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_seed_order_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_quantity_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $quantity = new multi_values();
            return $quantity->get_chosen_seed_order_quantity($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_unit_measure_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'seed_order') {
            $id = $_SESSION['id_upd'];
            $unit_measure = new multi_values();
            return $unit_measure->get_chosen_seed_order_unit_measure($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
