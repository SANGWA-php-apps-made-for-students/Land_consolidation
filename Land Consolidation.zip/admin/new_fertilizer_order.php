<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_fertilizer_order'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $fertilizer_order_id = $_SESSION['id_upd'];
            $fertilizer_orderdeleted = 'no';
            $date = date("y-m-d");
            $fertilizer = trim($_POST['txt_fertilizer_id']);
            $account = $_SESSION['userid'];
            $quantity = $_POST['txt_quantity'];
            $unit_measure = $_POST['txt_unit_measure'];
            $upd_obj->update_fertilizer_order($fertilizer_orderdeleted, $date, $fertilizer, $account, $quantity, $unit_measure, $fertilizer_order_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $fertilizer_orderdeleted = 'no';
        $date = date("y-m-d");
        $fertilizer = trim($_POST['txt_fertilizer_id']);
        $account = $_SESSION['userid'];
        $quantity = $_POST['txt_quantity'];
        $unit_measure = 'Kg';

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_fertilizer_order($fertilizer_orderdeleted, $date, $fertilizer, $account, $quantity, $unit_measure);
    }
}
?>

<html>
    <head>
        <title>
            fertilizer_order</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_fertilizer_order.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_fertilizer_id"   name="txt_fertilizer_id"/>

            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border no_bg">   
                <div class="parts  no_paddin_shade_no_Border new_data_hider">  </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                fertilizer_order saved successfully!</div>

            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  fertilizer_order</div>
                <table class="new_data_table">
                    <tr><td>fertilizer : </td><td> <?php get_fertilizer_combo(); ?>  </td></tr> 
                    <tr><td>quantity (Kg):</td><td> <input type="text"     name="txt_quantity" required class="textbox" value=" <?php echo trim(chosen_quantity_upd()); ?> "   />  </td></tr>
                    <tr class="off"><td>unit_measure :</td><td> <input type="text"     name="txt_unit_measure" required class="textbox" value=" <?php echo trim(chosen_unit_measure_upd()); ?> "   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_fertilizer_order" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">fertilizer_order List</div><?php
                $obj = new multi_values();
                if ($_SESSION['cat'] == 'admin' || $_SESSION['cat'] == 'agronomist') {
                    $obj->list_fertilizer_order();
                } else {
                    $obj->get_fertilizer_order_by_acc($_SESSION['userid']);
                }
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_fertilizer_combo() {
    $obj = new multi_values();
    $obj->get_fertilizer_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_fertilizer_orderdeleted_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $fertilizer_orderdeleted = new multi_values();
            return $fertilizer_orderdeleted->get_chosen_fertilizer_order_fertilizer_orderdeleted($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $date = new multi_values();
            return $date->get_chosen_fertilizer_order_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_fertilizer_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $fertilizer = new multi_values();
            return $fertilizer->get_chosen_fertilizer_order_fertilizer($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_fertilizer_order_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_quantity_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $quantity = new multi_values();
            return $quantity->get_chosen_fertilizer_order_quantity($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_unit_measure_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'fertilizer_order') {
            $id = $_SESSION['id_upd'];
            $unit_measure = new multi_values();
            return $unit_measure->get_chosen_fertilizer_order_unit_measure($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
