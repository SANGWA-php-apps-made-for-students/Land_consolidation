<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_image'])){
                 if ($_SESSION['table_to_update'] == 'image'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      
$path = $_POST['txt_path'];

require_once '../web_db/update.php';
 $obj = new new_values();
$obj->update_image(
$path,$image_id);}else{$path = $_POST['txt_path'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_image($path);
}}
?>

 <html>
<head>
<title>
image</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_image.php" method="post" enctype="multipart/form-data">



      <?php
            include 'admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div><div class="parts eighty_centered off saved_dialog">
 image saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  image</div>
 <table class="new_data_table">


<tr><td>path :</td><td> <input type="text"     name="txt_path" required class="textbox" value=" <?php echo chosen_path_upd();?> "   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_image" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
<?php 
 $obj = new multi_values();
$obj->list_image(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function chosen_path_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'image') {               $id = $_SESSION['id_upd'];
               $path = new multi_values();
               return $model->get_chosen_image_path($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
