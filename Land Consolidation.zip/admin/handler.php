<?php

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_province'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_province_id_by_province_name($_POST['cbo_province']);
        return $id;
    }
    if (isset($_POST['cbo_district'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_district_id_by_district_name($_POST['cbo_district']);
        return $id;
    }
    if (isset($_POST['cbo_sector'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_cell'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_farmer'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_farmer_id_by_farmer_name($_POST['cbo_farmer']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_plot'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_plot_id_by_plot_name($_POST['cbo_plot']);
        return $id;
    }
    if (isset($_POST['cbo_seed'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_seed_id_by_seed_name($_POST['cbo_seed']);
        return $id;
    }
    if (isset($_POST['cbo_account'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
        return $id;
    }
    if (isset($_POST['cbo_distribution'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_distribution_id_by_distribution_name($_POST['cbo_distribution']);
        return $id;
    }

//The Delete fromaccount

    if (isset($_POST['table_to_update'])) {
//    session_start();
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo 'the session we got is:  ' . $_SESSION['table_to_update'];
    }
//The Delete fromcontact_us
//The Delete fromaccount
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';


        $obj = new deletions();
        // <editor-fold defaultstate="collapsed" desc="--check if he is a farmer ----">
        $accid = $_POST['id_delete'];
        $con = new dbconnection;
        $sql = "select account_category.name from account_category
                        join account
                        on account.account_category=account_category.account_category_id
                        where account.account_id=:cat;
                       ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":cat" => $accid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = trim($row['name']);
// </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="--- get the corrsponding farmer -----">

        $sql = "select farmer.farmer_id from farmer
                join profile on farmer.profile = profile.profile_id 
                join account on account.profile = profile.profile_id 
                where  account.account_id =:accid";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":accid" => $accid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $farmerid = $row['farmer_id'];


// </editor-fold>





        if ($userid == 'farmer') {
            $obj->deleteFrom_account($accid);
            $obj->deleteFrom_farmer($farmerid);
            echo 'Shall delete the  farmer too';
        } else {
            $obj->deleteFrom_account($id);
            echo 'Shall not delete the  farmer too';
        }
    }
//The Delete fromaccount_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete fromprofile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete fromimage
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete fromprovince
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'province') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_province($id);
    }
//The Delete fromdistrict
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'district') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_district($id);
    }
//The Delete fromsector
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_sector($id);
    }
//The Delete fromcell
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_cell($id);
    }
//The Delete fromcontact_us
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'contact_us') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_contact_us($id);
    }
//The Delete fromvillage
//The Delete fromseed
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'seed') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_seed($id);
    }
//The Delete fromfertilizer
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'fertilizer') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_fertilizer($id);
    }
//The Delete fromsettings
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'settings') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_settings($id);
    }
//The Delete fromfarmer
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'farmer') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_farmer($id);
    }
//The Delete fromplot
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'plot') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_plot($id);
    }
//The Delete fromconsolidation
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'consolidation') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_consolidation($id);
    }
//The Delete fromdistribution
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'distribution') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_distribution($id);
    }
//The Delete fromexpenses
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'expenses') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_expenses($id);
    }
//The Delete fromharvest
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'harvest') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_harvest($id);
    }
//The Delete from seed_order
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'seed_order') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_seed_order($id);
    }
//The Delete from fertilizer_order
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'fertilizer_order') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_fertilizer_order($id);
    }
//Other addon
    if (isset($_POST['farmer_needed_seeds'])) {
        //get the seeds, fertilizer and the harvest as json
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $farmer = $_POST['farmer_needed_seeds'];
        $qty = $obj->get_needed_qtyseedBY_seed($farmer);
        echo $qty;
    }

    if (filter_has_var(INPUT_POST, 'plot_by_cell')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $cell = filter_input(INPUT_POST, 'plot_by_cell');

        echo $obj->list_cell_with_plots_consolidated_by_cell($cell);
    }

