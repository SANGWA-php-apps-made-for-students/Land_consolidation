<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="aboutus.php" method="post" >

            <div class="parts margin_free home_bg">
            </div>
            <div class="parts eighty_centered  home_parts no_paddin_shade_no_Border" style="box-shadow: none;">
                <?php include './header_menu.php'; ?>
                <div class="parts full_center_two_h heit_free skin top_off_xx no_shade_noBorder">
                    <h1>
                        About us
                    </h1>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                        <h3>
                            Who we are
                        </h3>
                        <div class="parts no_shade_noBorder full_center_two_h heit_free">
                            E-Hinga Conslidation is a group of people committed in 
                            boosting small farmers' harvest by  investing, analysing their
                            problems and seeking for the solutions. Thus we have come up with ideas
                            along with the purpose: to consolidate land and provide enough fertilizers. 
                        </div>
                        <h3>
                            Our Target
                        </h3>
                        <div class="parts  no_shade_noBorder">
                            Since we have already finished analysing the project of consolidating the 
                            farmers plots, we are looking forward to establish a system that will help 
                            sum up the quantity of the harvest in the country, the farmers participated in seasons,
                            evaluations of the harves, the evaluations of the expenses incurred in cultivations
                            per seasons and much more.
                        </div>
                    </div>

                </div>
        </form>
    </body>
</html>
