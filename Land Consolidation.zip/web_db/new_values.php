<?php

require_once('../web_db/connection.php');

class new_values {

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account_category($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
            $stm->execute(array(':account_category_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
            $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_image($path) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into image values(:image_id, :path)");
            $stm->execute(array(':image_id' => 0, ':path' => $path
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_province($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into province values(:province_id, :name)");
            $stm->execute(array(':province_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_district($name, $province) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into district values(:district_id, :name,  :province)");
            $stm->execute(array(':district_id' => 0, ':name' => $name, ':province' => $province
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_sector($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into sector values(:sector_id, :name)");
            $stm->execute(array(':sector_id' => 0, ':name' => $name));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cell($name, $sector) {
        try {
//            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cell values(:cell_id, :name,  :sector)");
            $stm->execute(array(':cell_id' => 0, ':name' => $name, ':sector' => $sector));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_contact_us($account, $date_contact, $message) {
        try {
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into contact_us values(:contact_us_id, :account,  :date_contact,  :message)");
            $stm->execute(array(':contact_us_id' => 0, ':account' => $account, ':date_contact' => $date_contact, ':message' => $message
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_village($name, $cell) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into village values(:village_id, :name,  :cell)");
            $stm->execute(array(':village_id' => 0, ':name' => $name, ':cell' => $cell
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_seed($seeddeleted, $name, $cost_per_unit, $measure_unit, $qty_m_sq, $harvest_rate_m_sq) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into seed values(:seed_id, :seeddeleted,  :name,  :cost_per_unit,  :measure_unit,  :qty_m_sq,  :harvest_rate_m_sq)");
            $stm->execute(array(':seed_id' => 0, ':seeddeleted' => $seeddeleted, ':name' => $name, ':cost_per_unit' => $cost_per_unit, ':measure_unit' => $measure_unit, ':qty_m_sq' => $qty_m_sq, ':harvest_rate_m_sq' => $harvest_rate_m_sq
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_fertilizer($fertilizerdeleted, $name, $cost_per_unit, $qty_per_msq,$seed) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into fertilizer values(:fertilizer_id, :fertilizerdeleted,  :name,  :cost_per_unit,  :qty_per_msq, :seed)");
            $stm->execute(array(':fertilizer_id' => 0, ':fertilizerdeleted' => $fertilizerdeleted, ':name' => $name, ':cost_per_unit' => $cost_per_unit, ':qty_per_msq' => $qty_per_msq, ':seed'=>$seed));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_settings($settingsdeleted, $account, $name, $value) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into settings values(:settings_id, :settingsdeleted,  :account,  :name,  :value)");
            $stm->execute(array(':settings_id' => 0, ':settingsdeleted' => $settingsdeleted, ':account' => $account, ':name' => $name, ':value' => $value
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_farmer($farmerdeleted, $profile) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into farmer values(:farmer_id, :farmerdeleted,  :profile)");
            $stm->execute(array(':farmer_id' => 0, ':farmerdeleted' => $farmerdeleted, ':profile' => $profile
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_plot($plotdeleted, $area_m_sq, $estimated_value, $farmer, $village) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into plot values(:plot_id, :plotdeleted,  :area_m_sq,  :estimated_value,  :farmer,  :village)");
            $stm->execute(array(':plot_id' => 0, ':plotdeleted' => $plotdeleted, ':area_m_sq' => $area_m_sq, ':estimated_value' => $estimated_value, ':farmer' => $farmer, ':village' => $village));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_consolidation($consolidationdeleted, $date, $account, $plot, $given_number, $seed) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into consolidation values(:consolidation_id, :consolidationdeleted,  :date,  :account,  :plot,  :given_number,  :seed)");
            $stm->execute(array(':consolidation_id' => 0, ':consolidationdeleted' => $consolidationdeleted, ':date' => $date, ':account' => $account, ':plot' => $plot, ':given_number' => $given_number, ':seed' => $seed
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_distribution($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into distribution values(:distribution_id, :distributiondeleted,  :date,  :seed,  :fertilizer,  :farmer_consLand,  :account,  :qty_seed,  :qty_fertilizer,  :expected_harvest,  :total_value,  :consolidated)");
            $stm->execute(array(':distribution_id' => 0, ':distributiondeleted' => $distributiondeleted, ':date' => $date, ':seed' => $seed, ':fertilizer' => $fertilizer, ':farmer_consLand' => $farmer_consLand, ':account' => $account, ':qty_seed' => $qty_seed, ':qty_fertilizer' => $qty_fertilizer, ':expected_harvest' => $expected_harvest, ':total_value' => $total_value, ':consolidated' => $consolidated
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_expenses($expensesdeleted, $date, $distribution, $expense_name, $total_cost) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into expenses values(:expenses_id, :expensesdeleted,  :date,  :distribution,  :expense_name,  :total_cost)");
            $stm->execute(array(':expenses_id' => 0, ':expensesdeleted' => $expensesdeleted, ':date' => $date, ':distribution' => $distribution, ':expense_name' => $expense_name, ':total_cost' => $total_cost
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_harvest($harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $cost_per_unit) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into harvest values(:harvest_id, :harvestdeleted,  :date,  :farmer_consolidation,  :distribution,  :quantity_harvested,  :cost_per_unit)");
            $stm->execute(array(':harvest_id' => 0, ':harvestdeleted' => $harvestdeleted, ':date' => $date, ':farmer_consolidation' => $farmer_consolidation, ':distribution' => $distribution, ':quantity_harvested' => $quantity_harvested, ':cost_per_unit' => $cost_per_unit
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_seed_order($seed_orderdeleted, $date, $seed, $account, $quantity, $unit_measure) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into seed_order values(:seed_order_id, :seed_orderdeleted,  :date,  :seed,  :account,  :quantity,  :unit_measure)");
            $stm->execute(array(':seed_order_id' => 0, ':seed_orderdeleted' => $seed_orderdeleted, ':date' => $date, ':seed' => $seed, ':account' => $account, ':quantity' => $quantity, ':unit_measure' => $unit_measure
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_fertilizer_order($fertilizer_orderdeleted, $date, $fertilizer, $account, $quantity, $unit_measure) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into fertilizer_order values(:fertilizer_order_id, :fertilizer_orderdeleted,  :date,  :fertilizer,  :account,  :quantity,  :unit_measure)");
            $stm->execute(array(':fertilizer_order_id' => 0, ':fertilizer_orderdeleted' => $fertilizer_orderdeleted, ':date' => $date, ':fertilizer' => $fertilizer, ':account' => $account, ':quantity' => $quantity, ':unit_measure' => $unit_measure
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
