<?php

require_once '../Admin/dbConnection.php';

class deletions {

    function deleteFrom_account($account_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account where account_id =:account_id");
        $smt->bindValue(':account_id', $account_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_account_category($account_category_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
        $smt->bindValue(':account_category_id', $account_category_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_profile($profile_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM profile where profile_id =:profile_id");
        $smt->bindValue(':profile_id', $profile_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_image($image_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM image where image_id =:image_id");
        $smt->bindValue(':image_id', $image_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_province($province_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM province where province_id =:province_id");
        $smt->bindValue(':province_id', $province_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_district($district_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM district where district_id =:district_id");
        $smt->bindValue(':district_id', $district_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_sector($sector_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM sector where sector_id =:sector_id");
        $smt->bindValue(':sector_id', $sector_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cell($cell_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cell where cell_id =:cell_id");
        $smt->bindValue(':cell_id', $cell_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_contact_us($contact_us_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM contact_us where contact_us_id =:contact_us_id");
        $smt->bindValue(':contact_us_id', $contact_us_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_village($village_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM village where village_id =:village_id");
        $smt->bindValue(':village_id', $village_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_seed($seed_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM seed where seed_id =:seed_id");
        $smt->bindValue(':seed_id', $seed_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_fertilizer($fertilizer_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM fertilizer where fertilizer_id =:fertilizer_id");
        $smt->bindValue(':fertilizer_id', $fertilizer_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_settings($settings_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM settings where settings_id =:settings_id");
        $smt->bindValue(':settings_id', $settings_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_farmer($farmer_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM farmer where farmer_id =:farmer_id");
        $smt->bindValue(':farmer_id', $farmer_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_plot($plot_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM plot where plot_id =:plot_id");
        $smt->bindValue(':plot_id', $plot_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_consolidation($consolidation_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM consolidation where consolidation_id =:consolidation_id");
        $smt->bindValue(':consolidation_id', $consolidation_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_distribution($distribution_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM distribution where distribution_id =:distribution_id");
        $smt->bindValue(':distribution_id', $distribution_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_expenses($expenses_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM expenses where expenses_id =:expenses_id");
        $smt->bindValue(':expenses_id', $expenses_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_harvest($harvest_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM harvest where harvest_id =:harvest_id");
        $smt->bindValue(':harvest_id', $harvest_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

}
