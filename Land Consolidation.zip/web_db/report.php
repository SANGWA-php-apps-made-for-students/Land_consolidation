<?php
require_once '../web_db/connection.php';

class app_report {

    function get_general_report_summary() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  distribution.distribution_id,  distribution.date, year(distribution.date) as year, month(distribution.date) as month,  distribution.seed,  distribution.fertilizer,  distribution.farmer_consLand,  
                sum(distribution.qty_seed * seed.cost_per_unit) as qty_seed ,  sum(distribution.qty_fertilizer * fertilizer.cost_per_unit) as qty_fertilizer ,  sum(distribution.expected_harvest) as expected_harvest,  sum(distribution.total_value) as total_value ,
                expenses.expenses_id,  expenses.date as expdate,  expenses.expense_name,  sum(expenses.total_cost) as total_cost,
                harvest.date as harvdate,  sum(harvest.quantity_harvested * harvest.cost_per_unit) as  quantity_harvested
                from distribution
                join seed on distribution.seed = seed.seed_id
                join fertilizer on seed.seed_id=fertilizer.seed
                left join expenses on expenses.distribution = distribution.distribution_id 
                left join harvest on harvest.distribution = distribution.distribution_id  
                group by   year,   month
";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead>
                <tr class="top_header">
                    <td class="rep_distr_row"  colspan="4"> INVESTMENT </td>
                    <td class="rep_exp_row" colspan="3">    EXPENSES   </td>
                    <td class="rep_harv_row" colspan="3">   PRODUCTION </td>
                </tr>
                <tr>
                    <td class="rep_distr_row off"> ID </td>
                    <td class="rep_distr_row"> date </td>
                    <td class="rep_distr_row"> seed </td>
                    <td class="rep_distr_row"> fertilizer </td>

                    <td class="rep_distr_row"> total_value </td>
                    <td class="rep_exp_row"> expenses_id </td>
                    <td class="rep_exp_row"> date </td>
                    <td class="rep_exp_row"> total_cost </td>
                    <td class="rep_harv_row"> expected harvest </td>
                    <td class="rep_harv_row"> date </td>
                    <td class="rep_harv_row"> Produced </td>
                </tr>
            </thead>
            <?php while ($row = $stmt->fetch()) { ?>
                <tr>
                    <td class="rep_distr_row off">    <?php echo $row['distribution_id']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['date']; ?> </td>

                    <td class="rep_distr_row">        <?php echo 'RWF '.number_format( $row['qty_seed']/1000); ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['qty_fertilizer']/1000; ?> </td>

                    <td class="rep_distr_row">        <?php echo 'RWF '.number_format( $row['qty_seed']/1000 +$row['qty_fertilizer']/1000) ; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['expenses_id']; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['expdate']; ?> </td>

                    <td class="rep_exp_row">          <?php echo 'RWF '.number_format($row['total_cost']); ?> </td>
                    
                    <td class="rep_harv_row">         <?php  echo 'RWF '. number_format($row['expected_harvest']); ?> </td> <?php //this belongs to distribution column though it is put here                  ?>
                    <td class="rep_harv_row">         <?php echo $row['harvdate']; ?> </td>
                    <td class="rep_harv_row">         <?php echo 'RWF '.number_format( $row['quantity_harvested']); ?> </td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="15">
                    <a class="confirm_buttons" href="../admin/print_report.php">Print</a>

                </td>
            </tr>



        </table> <?php
    }

    function get_general_report_detailed() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = " select  distribution.distribution_id,  distribution.date, year(distribution.date) as year, month(distribution.date) as month,  distribution.seed,  distribution.fertilizer,  distribution.farmer_consLand,  
                sum(distribution.qty_seed) as qty_seed ,  sum(distribution.qty_fertilizer) as qty_fertilizer ,  sum(distribution.expected_harvest) as expected_harvest,  sum(distribution.total_value) as total_value ,
                expenses.expenses_id,  expenses.date as expdate,  expenses.expense_name,  sum(expenses.total_cost) as total_cost,
                harvest.date as harvdate,  sum( harvest.quantity_harvested) as  quantity_harvested
                from distribution
                left join expenses on expenses.distribution = distribution.distribution_id 
                left join harvest on harvest.distribution = distribution.distribution_id  
                group by   year,   month
";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>

        <table class="dataList_table">
            <thead>
                <tr>
                    <td colspan="9">                        INVESTMENT                    </td>
                    <td colspan="4">                        EXPENSES                    </td>
                    <td colspan="2">                        PRODUCTION                    </td>
                </tr>
                <tr>

                    <td> ID </td><td> date </td><td> seed </td><td> fertilizer </td><td> farmer_consLand </td><td> qty_seed </td><td> qty_fertilizer </td><td> expected_harvest </td><td> total_value </td>
                    <td> expenses_id </td><td> date </td><td> expense_name </td><td> total_cost </td>
                    <td> date </td><td> quantity_harvested </td>
                </tr>
            </thead>
            <?php while ($row = $stmt->fetch()) { ?>
                <tr>
                    <td class="rep_distr_row">        <?php echo $row['distribution_id']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['date']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['seed']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['fertilizer']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['farmer_consLand']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['qty_seed']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['qty_fertilizer']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['expected_harvest']; ?> </td>
                    <td class="rep_distr_row">        <?php echo $row['total_value']; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['expenses_id']; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['expdate']; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['expense_name']; ?> </td>
                    <td class="rep_exp_row">          <?php echo $row['total_cost']; ?> </td>
                    <td class="rep_harv_row">         <?php echo $row['harvdate']; ?> </td>
                    <td class="rep_harv_row">         <?php echo $row['quantity_harvested']; ?> </td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="15">
                    <a class="confirm_buttons" href="../admin/print_report.php">Print</a>

                </td>
            </tr>



        </table> <?php
    }

    function get_general_report_with_button() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  distribution.distribution_id,  distribution.date,  distribution.seed,  distribution.fertilizer,  
            distribution.farmer_consLand,  distribution.qty_seed,  distribution.qty_fertilizer,  distribution.expected_harvest, 
            distribution.total_value from distribution
             left join expenses on expenses.distribution = distribution.distribution_id 
            left join harvest on harvest.distribution = distribution.distribution_id 
             group by date";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead>
                <tr><td> distribution_id </td><td> date </td><td> seed </td><td> fertilizer </td><td> farmer_consLand </td><td> qty_seed </td><td> qty_fertilizer </td><td> expected_harvest </td><td> total_value </td>
                </tr>
            </thead>
            <?php while ($row = $stmt->fetch()) { ?>
                <tr>
                    <td>        <?php echo $row['distribution_id']; ?> </td>
                    <td>        <?php echo $row['date']; ?> </td>
                    <td>        <?php echo $row['seed']; ?> </td>
                    <td>        <?php echo $row['fertilizer']; ?> </td>
                    <td>        <?php echo $row['farmer_consLand']; ?> </td>
                    <td>        <?php echo $row['qty_seed']; ?> </td>
                    <td>        <?php echo $row['qty_fertilizer']; ?> </td>
                    <td>        <?php echo $row['expected_harvest']; ?> </td>
                    <td>        <?php echo $row['total_value']; ?> </td>

                </tr>
            <?php } ?>
            <tr>
                <td colspan="9">
                    <a class="confirm_buttons" id="print_general_report" href="../admin/print_report.php" onclick="print_page()"> Print </a>

                </td>
            </tr>

        </table> <?php
    }

}
