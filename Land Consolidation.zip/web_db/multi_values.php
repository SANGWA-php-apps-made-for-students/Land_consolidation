<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_accounts_by_categories() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> name </td>

                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category" title="account_category">
                        <?php echo $row['name'] . ' <b>(' . $this->get_tot_accounts_by_accCat($row['account_category_id']) . ')</b>'; ?>
                    </td>
                    <td class="off">
                        <a href="#" class="account_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td class="off">
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td>
                </tr>
                <tr class="corr_plots">
                    <td colspan="2">
                        <?php $this->list_account($row['account_category_id']) ?>
                    </td>
                </tr>

            <?php } ?></table>
        <?php
    }

    function list_account_category() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category  ";
        ?>
        <table class="dataList_table">
            <thead ><tr>
                    <td> ID </td>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category" title="account_category">
                        <?php echo $row['name']; ?>
                    </td>

                    <td class="off">
                        <a href="#" class="account_category_delete_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Delete</a>
                    </td>
                    <td class="off">
                        <a href="#" class="account_category_update_link" style="color: #000080;" value="
                           <?php echo $row['account_category_id']; ?>">Update</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_account_category_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account_category'];
        echo $field;
    }

    function list_profile() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> profile </td>
                    <td> dob </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telephone_number </td>
                    <td> email </td>
                    <td> residence </td>
                    <td> image </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class=dob_id_cols>
                        <?php echo $row['dob']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telephone_number']; ?>
                    </td>
                    <td>
                        <?php echo $row['email']; ?>
                    </td>
                    <td>
                        <?php echo $row['residence']; ?>
                    </td>
                    <td>
                        <?php echo $row['image']; ?>
                    </td>


                    <td>
                        <a href="#" class="delete_link_profile" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Delete</a>
                    </td><td>
                        <a href="#" class="update_link_profile" style="color: #000080;" value="
                           <?php echo $row['profile_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_image() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from image    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> image </td>
                    <td> path </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class=path_id_cols>
                        <?php echo $row['path']; ?>
                    </td>


                    <td>
                        <a href="#" class="delete_link_image" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Delete</a>
                    </td><td>
                        <a href="#" class="update_link_image" style="color: #000080;" value="
                           <?php echo $row['image_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_district() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from district   ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> district </td>
                    <td> name </td>
                    <td> province </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['district_id']; ?>
                    </td>
                    <td class=name_id_cols>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['province']; ?>
                    </td>


                    <td>
                        <a href="#" class="delete_link_district" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Delete</a>
                    </td><td>
                        <a href="#" class="update_link_district" style="color: #000080;" value="
                           <?php echo $row['district_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field

    function list_cell() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id, cell.name,  sector.name as sector from cell   join sector on cell.sector = sector.sector_id   ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> cell </td>
                    <td> Cell name </td>
                    <td> Sector Name </td>

                    <td>Delete</td>
                    <td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['sector']; ?>
                    </td>
                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['cell_id']; ?>">Update</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_cell_with_plots() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id, cell.name,  sector.name as sector from cell   join sector on cell.sector = sector.sector_id   ";
        ?>
        <table class="dataList_table cellz_plots_tab">
            <thead><tr>
                    <td> cell </td>
                    <td> Cell name </td>
                    <td> Sector Name </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td class="plotcell_cellid_cols">
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo '<b>' . $row['name'] . '</b>'; ?>
                    </td>
                    <td>
                        <?php echo $row['sector']; ?>
                    </td>
                </tr>
                <tr class="corr_plots"><td colspan="7">
                        <?php $this->get_plot_by_village($row['cell_id']) ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_contact_us() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from contact_us    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> contact_us </td>
                    <td> account </td>
                    <td> date_contact </td>
                    <td> message </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['contact_us_id']; ?>
                    </td>
                    <td class=account_id_cols>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_contact']; ?>
                    </td>
                    <td>
                        <?php echo $row['message']; ?>
                    </td>


                    <td>
                        <a href="#" class="delete_link_contact_us" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Delete</a>
                    </td><td>
                        <a href="#" class="update_link_contact_us" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_village() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,  village.name,  cell.name as cell from village  join cell on village.cell = cell.cell_id    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> village </td>
                    <td> Village name </td>
                    <td> Cell name </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['village_id']; ?>
                    </td>
                    <td class="name_id_cols village " title="village">
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['cell']; ?>
                    </td>

                    <td>
                        <a href="#" class="village_delete_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="village_update_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_seed() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from seed where seed.seeddeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> seed </td>
                    <td> name </td><td> cost_per_unit </td><td> qty_m_sq </td><td> harvest_rate_m_sq </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="seeddeleted_id_cols seed " title="seed">
                        <?php echo $row['seed_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['cost_per_unit']; ?>
                    </td>

                    <td>
                        <?php echo $row['qty_m_sq']; ?>
                    </td>
                    <td>
                        <?php echo $row['harvest_rate_m_sq']; ?>
                    </td>


                    <td>
                        <a href="#" class="seed_delete_link" style="color: #000080;" value="
                           <?php echo $row['seed_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="seed_update_link" style="color: #000080;" value="
                           <?php echo $row['seed_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_settings() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from settings where settings.settingsdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> settings </td>
                    <td> setting_name </td>
                    <td> value </td>
                    <td>Delete</td>
                    <td>Update</td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="settings" title="settings">
                        <?php echo $row['settings_id']; ?>
                    </td>


                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['value']; ?>
                    </td>

                    <td>
                        <a href="#" class="settings_delete_link" style="color: #000080;" value="
                           <?php echo $row['settings_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="settings_update_link" style="color: #000080;" value="
                           <?php echo $row['settings_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_farmer() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from farmer    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> farmer </td>

                    <td> profile </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['farmer_id']; ?>
                    </td>

                    <td class="farmerdeleted_id_cols farmer " title="farmer">
                        <?php echo $row['profile']; ?>
                    </td>
                    <td>
                        <a href="#" class="farmer_delete_link" style="color: #000080;" value="
                           <?php echo $row['farmer_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="farmer_update_link" style="color: #000080;" value="
                           <?php echo $row['farmer_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_plot() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select plot.plot_id,plot.area_m_sq,plot.estimated_value, plot.village,  profile.name,profile.last_name,  profile.last_name,  profile.gender,"
                . "  profile.telephone_number, cell.name as cell"
                . " from plot "
                . " join farmer on plot.farmer = farmer.farmer_id"
                . " join profile on farmer.profile = profile.profile_id  "
                . " join cell on plot.village=cell.cell_id"
                . " order by plot.plot_id  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> plot </td>

                    <td> area_m_sq </td>
                    <td> estimated_value </td>
                    <td> farmer name </td>
                    <td> farmer Last name</td><td> Cell name </td>

                    <td>Delete</td><td>Update</td></tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['plot_id']; ?>
                    </td>
                    <td class="plotdeleted_id_cols plot " title="plot">
                        <?php echo $row['area_m_sq']; ?>
                    </td>
                    <td>
                        <?php echo $row['estimated_value']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td class="col_highlight_good">
                        <?php echo $row['cell']; ?>
                    </td>

                    <td>
                        <a href="#" class="plot_delete_link" style="color: #000080;" value="
                           <?php echo $row['plot_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="plot_update_link" style="color: #000080;" value="
                           <?php echo $row['plot_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_plot_by_villages() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,  village.name,  cell.name as cell from village  join cell on village.cell = cell.cell_id    ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> village </td>
                    <td> Village name </td>
                    <td> Cell name </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['village_id']; ?>
                    </td>
                    <td class="name_id_cols village " title="village">
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['cell']; ?>
                    </td>

                    <td>
                        <a href="#" class="village_delete_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="village_update_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Update</a>
                    </td>



                </tr>
            <?php } ?></table>
        <?php
    }

    function list_consolidation() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from consolidation where consolidation.consolidationdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> consolidation </td>
                    <td> consolidationdeleted </td><td> date </td><td> account </td><td> plot </td><td> given_number </td><td> seed </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['consolidation_id']; ?>
                    </td>
                    <td class="consolidationdeleted_id_cols consolidation " title="consolidation" >
                        <?php echo $row['consolidationdeleted']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['plot']; ?>
                    </td>
                    <td>
                        <?php echo $row['given_number']; ?>
                    </td>
                    <td>
                        <?php echo $row['seed']; ?>
                    </td>


                    <td>
                        <a href="#" class="consolidation_delete_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="consolidation_update_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_consolidation_summary() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  consolidation.consolidation_id,cell.name as cell,  consolidation.date, count(consolidation.plot) as plot,"
                . " sum(plot.area_m_sq) as area_m_sq, sum(  plot.estimated_value) as tot_val, consolidation.given_number,  seed.name "
                . "from consolidation    join seed on consolidation.seed = seed.seed_id "
                . " join plot on consolidation.plot = plot.plot_id "
                . "  join cell on plot.village = cell.cell_id "
                . "group by given_number";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> date </td> 
                    <td> Location </td>

                    <td>Total plots </td>
                    <td> Size </td>
                    <td> Total Value </td>
                    <td> seed </td>
                    <td> given_number </td>
                    <td>Delete</td>
                    <td>Update</td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?>
                <tr class="data_row"> 
                    <td>
                        <?php echo $row['consolidation_id']; ?>
                    </td>
                    <td class="consolidationdeleted_id_cols consolidation " title="consolidation">
                        <?php echo $row['date']; ?>
                    </td> 
                    <td>
                        <?php echo $row['cell']; ?>
                    </td>

                    <td>
                        <?php echo $row['plot'] . ' plots'; ?>
                    </td>
                    <td>
                        <?php echo $row['area_m_sq']; ?>
                    </td>

                    <td>
                        <?php echo $row['tot_val']; ?>
                    </td>


                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['given_number']; ?>
                    </td>
                    <td>
                        <a href="#" class="consolidation_delete_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="consolidation_update_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_consolidation_no_summary() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  consolidation.consolidation_id,cell.name as cell,  consolidation.date,  consolidation.plot,  "
                . " plot.area_m_sq,  plot.estimated_value,   consolidation.given_number,  seed.name "
                . " from consolidation    join seed on consolidation.seed = seed.seed_id "
                . " join plot on consolidation.plot = plot.plot_id "
                . "  join cell on plot.village = cell.cell_id "
                . "";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> date </td>  <td> Location </td>
                    <td> plot number</td>
                    <td> Area </td>
                    <td> Value </td>
                    <td> seed </td>
                    <td> given_number </td>
                    <td>Delete</td>
                    <td>Update</td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?>
                <tr class="data_row"> 
                    <td>
                        <?php echo $row['consolidation_id']; ?>
                    </td>
                    <td class="consolidationdeleted_id_cols consolidation " title="consolidation">
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['cell']; ?>
                    </td>

                    <td>
                        <?php echo $row['plot']; ?>
                    </td>
                    <td>
                        <?php echo $row['area_m_sq']; ?>
                    </td>
                    <td>
                        <?php echo $row['estimated_value']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['given_number']; ?>
                    </td>
                    <td>
                        <a href="#" class="consolidation_delete_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="consolidation_update_link" style="color: #000080;" value="
                           <?php echo $row['consolidation_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_distribution() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  distribution.distribution_id, seed.name, distribution.date,  distribution.seed,  "
                . "distribution.fertilizer,    distribution.qty_seed,  "
                . "distribution.qty_fertilizer,  distribution.expected_harvest,  distribution.total_value, "
                . " profile.name as prof,  profile.last_name"
                . " from distribution  "
                . " join seed on distribution.seed = seed.seed_id "
                . " join farmer on  distribution.farmer_consLand= farmer.farmer_id "
                . " join profile on farmer.profile = profile.profile_id "
                . "group by farmer_consLand";
        ?>
        <table class="dataList_table">
            <thead>
                <tr>
                    <td> ID </td>
                    <td> date </td>
                    <td> seed </td><td>quantity seed</td>
                    <td> farmer name </td>
                    <td> farmer last name </td>
                    <td> qty_fertilizer </td>
                    <td> Exp. Harvest </td>
                    <td class="off"> total_value </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['distribution_id']; ?>
                    </td>
                    <td class="distributiondeleted_id_cols distribution " title="distribution" >
                        <?php echo $row['date']; ?>
                    </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td>
                        <?php echo $row['qty_seed']; ?>
                    </td>
                    <td>
                        <?php echo $row['prof'] ?>
                    </td>
                    <td>
                        <?php echo $row['last_name'] ?>
                    </td>


                    <td>
                        <?php echo $row['qty_fertilizer']; ?>
                    </td>
                    <td>
                        <?php echo $row['expected_harvest']; ?>
                    </td>
                    <td class="off">
                        <?php echo $row['total_value']; ?>
                    </td>
                    <td>
                        <a href="#" class="distribution_delete_link" style="color: #000080;" value="
                           <?php echo $row['distribution_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="distribution_update_link" style="color: #000080;" value="
                           <?php echo $row['distribution_id']; ?>">Update</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_expenses() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select expenses.expenses_id ,expenses.date,  expenses.expense_name,  
            expenses.total_cost,  distribution.date
                from expenses
                 join distribution on expenses.distribution = distribution.distribution_id 
                 group by expense_name";
        ?>
        <table class="dataList_table" style="width: 100%;">
            <thead><tr>
                    <td> expenses </td>
                    <td> Expense Date </td>
                    <td> Distribution Date </td>
                    <td> expense_name </td>
                    <td> total_cost </td>

                </tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="expensesdeleted_id_cols expenses " title="expenses">
                        <?php echo $row['expenses_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['expense_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['total_cost']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_harvest() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select harvest.distribution,distribution.date distrdate,  harvest.harvest_id,  harvest.date,  harvest.farmer_consolidation, 
                        harvest.quantity_harvested,       harvest.quantity_harvested *  harvest.cost_per_unit as val,  distribution.date as distr_date
                        from harvest     join distribution on harvest.distribution = distribution.distribution_id  
                                                  group by distrdate";
        ?>
        <table class="dataList_table" style="width: 100%;">
            <thead><tr>
                    <td> harvest </td>
                    <td> Harvest date </td>
                    <td> Land consolidated </td>
                    <td> Distribution Date</td>
                    <td> quantity_harvested </td>
                    <td> value </td>
                    <td>Delete</td><td>Update</td></tr></thead>
            <?php
            $grand_tot = 0;
            foreach ($db->query($sql) as $row) {
                $grand_tot += $row['val'];
                ?><tr> 
                    <td class="harvestdeleted_id_cols harvest " title="harvest">
                        <?php echo $row['harvest_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['farmer_consolidation']; ?>
                    </td>
                    <td>
                        <?php echo $row['distr_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity_harvested'] . ' kg'; ?>
                    </td>
                    <td>
                        <?php echo $row['val']; ?>
                    </td>
                    <td>
                        <a href="#" class="harvest_delete_link" style="color: #000080;" value="
                           <?php echo $row['harvest_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="harvest_update_link" style="color: #000080;" value="
                           <?php echo $row['harvest_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?>

            <tr>
                <td style="font-weight: bolder; font-size: 20px; color: #fff; text-align: right;" colspan="8">
                    <?php echo 'Grand total: ' . $grand_tot; ?>
                </td>
            </tr>
        </table>
        <?php
    }

    function list_sector() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from sector  ";
        foreach ($db->query($sql) as $row) {
            echo $row['name'] . ' sector';
        }
    }

    function get_chosen_account_account_category($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.account_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_account_date_created($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.date_created from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_account_profile($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.profile from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_account_username($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    }

    function get_chosen_account_password($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_account_is_online($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.is_online from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_profile_dob($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_last_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_gender($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_telephone_number($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_email($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_residence($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_profile_image($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   profile.image from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    }

    function get_chosen_image_path($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   image.path from image where image_id=:image_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':image_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['image'];
        echo $field;
    }

    function get_chosen_sector_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   sector.name from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    }

    function get_chosen_sector_district($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   sector.district from sector where sector_id=:sector_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':sector_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['sector'];
        echo $field;
    }

    function get_chosen_cell_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   cell.name from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_cell_sector($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   cell.sector from cell where cell_id=:cell_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':cell_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cell'];
        echo $field;
    }

    function get_chosen_contact_us_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.account from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['contact_us'];
        echo $field;
    }

    function get_chosen_contact_us_date_contact($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.date_contact from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['contact_us'];
        echo $field;
    }

    function get_chosen_contact_us_message($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   contact_us.message from contact_us where contact_us_id=:contact_us_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':contact_us_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['contact_us'];
        echo $field;
    }

    function get_chosen_village_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   village.name from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['village'];
        echo $field;
    }

    function get_chosen_village_cell($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   village.cell from village where village_id=:village_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':village_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['village'];
        echo $field;
    }

//chosen individual field
    function get_chosen_seed_seeddeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed.seeddeleted from seed where seed_id=:seed_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['seed'];
        echo $field;
    }

    function get_chosen_seed_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed.name from seed where seed_id=:seed_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['seed'];
        echo $field;
    }

    function get_chosen_seed_cost_per_unit($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed.cost_per_unit from seed where seed_id=:seed_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['seed'];
        echo $field;
    }

    function list_fertilizer() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from fertilizer where fertilizer.fertilizerdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> fertilizer </td>
                    <td> name </td><td> cost_per_unit </td>
                    <td> Quantity per m<sup>2</sup> </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="fertilizerdeleted_id_cols fertilizer " title="fertilizer">
                        <?php echo $row['fertilizer_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['cost_per_unit']; ?>
                    </td>
                    <td>
                        <?php echo $row['qty_per_msq']; ?>
                    </td>
                    <td>
                        <a href="#" class="fertilizer_delete_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="fertilizer_update_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_fertilizer_fertilizerdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer.fertilizerdeleted from fertilizer where fertilizer_id=:fertilizer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['fertilizer'];
        echo $field;
    }

    function get_chosen_fertilizer_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer.name from fertilizer where fertilizer_id=:fertilizer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['fertilizer'];
        echo $field;
    }

//chosen individual field
    function get_chosen_settings_settingsdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   settings.settingsdeleted from settings where settings_id=:settings_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':settings_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['settings'];
        echo $field;
    }

    function get_chosen_settings_setting_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   settings.setting_name from settings where settings_id=:settings_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':settings_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['settings'];
        echo $field;
    }

    function get_chosen_settings_qty_m_sq($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   settings.qty_m_sq from settings where settings_id=:settings_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':settings_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['settings'];
        echo $field;
    }

    function get_chosen_settings_unit_kg_liter($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   settings.unit_kg_liter from settings where settings_id=:settings_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':settings_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['settings'];
        echo $field;
    }

    function get_chosen_settings_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   settings.account from settings where settings_id=:settings_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':settings_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['settings'];
        echo $field;
    }

//chosen individual field
    function get_chosen_farmer_farmerdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   farmer.farmerdeleted from farmer where farmer_id=:farmer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':farmer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['farmer'];
        echo $field;
    }

    function get_chosen_farmer_profile($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   farmer.profile from farmer where farmer_id=:farmer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':farmer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['farmer'];
        echo $field;
    }

//chosen individual field
    function get_chosen_plot_plotdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   plot.plotdeleted from plot where plot_id=:plot_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':plot_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['plot'];
        echo $field;
    }

    function get_chosen_plot_area_m_sq($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   plot.area_m_sq from plot where plot_id=:plot_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':plot_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['plot'];
        echo $field;
    }

    function get_chosen_plot_estimated_value($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   plot.estimated_value from plot where plot_id=:plot_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':plot_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['plot'];
        echo $field;
    }

    function get_chosen_plot_farmer($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   plot.farmer from plot where plot_id=:plot_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':plot_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['plot'];
        echo $field;
    }

//chosen individual field
    function get_chosen_consolidation_consolidationdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   consolidation.consolidationdeleted from consolidation where consolidation_id=:consolidation_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':consolidation_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['consolidation'];
        echo $field;
    }

    function get_chosen_consolidation_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   consolidation.date from consolidation where consolidation_id=:consolidation_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':consolidation_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['consolidation'];
        echo $field;
    }

    function get_chosen_consolidation_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   consolidation.account from consolidation where consolidation_id=:consolidation_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':consolidation_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['consolidation'];
        echo $field;
    }

    function get_chosen_consolidation_plot($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   consolidation.plot from consolidation where consolidation_id=:consolidation_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':consolidation_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['consolidation'];
        echo $field;
    }

    function get_chosen_consolidation_given_number($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   consolidation.given_number from consolidation where consolidation_id=:consolidation_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':consolidation_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['consolidation'];
        echo $field;
    }

//chosen individual field
    function get_chosen_distribution_distributiondeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.distributiondeleted from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.date from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_seed($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.seed from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_fertilizer($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.fertilizer from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_farmer_consLand($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.farmer_consLand from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.account from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_qty_seed($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.qty_seed from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_qty_fertilizer($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.qty_fertilizer from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_expected_harvest($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.expected_harvest from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_total_value($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.total_value from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

    function get_chosen_distribution_consolidated($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   distribution.consolidated from distribution where distribution_id=:distribution_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':distribution_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['distribution'];
        echo $field;
    }

//chosen individual field
    function get_chosen_expenses_expensesdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   expenses.expensesdeleted from expenses where expenses_id=:expenses_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':expenses_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['expenses'];
        echo $field;
    }

    function get_chosen_expenses_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   expenses.date from expenses where expenses_id=:expenses_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':expenses_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['expenses'];
        echo $field;
    }

    function get_chosen_expenses_distribution($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   expenses.distribution from expenses where expenses_id=:expenses_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':expenses_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['expenses'];
        echo $field;
    }

    function get_chosen_expenses_expense_name($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   expenses.expense_name from expenses where expenses_id=:expenses_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':expenses_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['expenses'];
        echo $field;
    }

    function get_chosen_expenses_total_cost($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   expenses.total_cost from expenses where expenses_id=:expenses_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':expenses_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['expenses'];
        echo $field;
    }

//chosen individual field
    function get_chosen_harvest_harvestdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   harvest.harvestdeleted from harvest where harvest_id=:harvest_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':harvest_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['harvest'];
        echo $field;
    }

    function get_chosen_harvest_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   harvest.date from harvest where harvest_id=:harvest_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':harvest_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['harvest'];
        echo $field;
    }

    function get_chosen_harvest_farmer_consolidation($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   harvest.farmer_consolidation from harvest where harvest_id=:harvest_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':harvest_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['harvest'];
        echo $field;
    }

    function get_chosen_harvest_distribution($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   harvest.distribution from harvest where harvest_id=:harvest_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':harvest_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['harvest'];
        echo $field;
    }

    function get_chosen_harvest_quantity_harvested($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   harvest.quantity_harvested from harvest where harvest_id=:harvest_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':harvest_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['harvest'];
        echo $field;
    }

//chosen individual field
    function get_chosen_seed_order_seed_orderdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed_order.seed_orderdeleted from seed_order where seed_order_id=:seed_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['seed_orderdeleted'];
        echo $field;
    }

    function get_chosen_seed_order_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed_order.date from seed_order where seed_order_id=:seed_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    }

    function get_chosen_seed_order_seed($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed_order.seed from seed_order where seed_order_id=:seed_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['seed'];
        echo $field;
    }

    function get_chosen_seed_order_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   seed_order.account from seed_order where seed_order_id=:seed_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':seed_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

//chosen individual field
    function get_chosen_fertilizer_order_fertilizer_orderdeleted($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer_order.fertilizer_orderdeleted from fertilizer_order where fertilizer_order_id=:fertilizer_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['fertilizer_orderdeleted'];
        echo $field;
    }

    function get_chosen_fertilizer_order_date($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer_order.date from fertilizer_order where fertilizer_order_id=:fertilizer_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['date'];
        echo $field;
    }

    function get_chosen_fertilizer_order_fertilizer($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer_order.fertilizer from fertilizer_order where fertilizer_order_id=:fertilizer_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['fertilizer'];
        echo $field;
    }

    function get_chosen_fertilizer_order_account($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer_order.account from fertilizer_order where fertilizer_order_id=:fertilizer_order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['account'];
        echo $field;
    }

    function get_chosen_fertilizer_qty_per_msq($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   fertilizer.qty_per_msq from fertilizer where fertilizer_id=:fertilizer_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':fertilizer_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['qty_per_msq'];
        echo $field;
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category"
                . "  where name<>'farmer' ";
        ?>
        <select class="textbox cbo_account_category" required="" name="cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_category_id_by_account_category_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account_category.account_category_id from account_category where account_category.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        echo $userid;
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_province_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select province.province_id,   province.name from province";
        ?>
        <select class="textbox cbo_province"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['province_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_district_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select district.district_id,   district.name from district";
        ?>
        <select class="textbox cbo_district"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['district_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_sector_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.sector_id,   sector.name from sector";
        ?>
        <select  class="textbox cbo_sector"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_village_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.village_id,   village.name from village";
        ?>
        <select class="textbox cbo_village"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_cell_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select required class="textbox cbo_cell"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_cell_search_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id,   cell.name from cell";
        ?>
        <select required class="textbox cbo_cell_search"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_plot_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select plot.plot_id,   plot.name from plot";
        ?>
        <select class="textbox cbo_plot"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['plot_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_seed_by_farmerPlot_in_combo($farmer) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  distinct seed.name as seed from consolidation 
                    join plot on consolidation.plot = plot.plot_id 
                     join seed on consolidation.seed = seed.seed_id 
                     join farmer on plot.farmer = farmer.farmer_id  
                    where plot.farmer =:name";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":name" => $farmer));
        ?>
        <select  class="textbox cbo_seed"><option></option>
            <?php
            while ($row = $stmt->fetch()) {
                echo "<option value=" . $row['seed_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_seed_in_combo() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select seed.seed_id,   seed.name from seed";
        ?>
        <select  class="textbox cbo_seed"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['seed_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_fertilizer_in_combo() {

        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select fertilizer.fertilizer_id,   fertilizer.name from fertilizer";
        ?>
        <select class="textbox cbo_fertilizer"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['fertilizer_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_distribution_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select distribution.distribution_id,   distribution.name from distribution";
        ?>
        <select class="textbox cbo_distribution"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['distribution_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_distribution_id_by_distribution_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    distribution.distribution_id from distribution where distribution.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['distribution_id'];
        echo $userid;
    }

    function list_fertilizer_order() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select fertilizer_order.fertilizer_order_id,  fertilizer_order.fertilizer_orderdeleted,  fertilizer_order.date, 
            fertilizer_order.fertilizer,  fertilizer_order.account,  fertilizer_order.quantity,  fertilizer_order.unit_measure,
            fertilizer.name as fert_name
 from fertilizer_order  join fertilizer on fertilizer_order.fertilizer = fertilizer.fertilizer_id  where fertilizer_order.fertilizer_orderdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> fertilizer_order </td>
                    <td> date </td><td> fertilizer </td><td> account </td><td> quantity </td><td> unit_measure </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td class="fertilizer_orderdeleted_id_cols fertilizer_order " title="fertilizer_order" >
                        <?php echo $row['fertilizer_order_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['fert_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['unit_measure']; ?>
                    </td>
                    <td>
                        <a href="#" class="fertilizer_order_delete_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_order_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="fertilizer_order_update_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_order_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function get_fertilizer_order_by_acc($acc) {
        $res = '';
        $con = new dbconnection();
        $sql = "select * from fertilizer_order where fertilizer_order.fertilizer_orderdeleted='no' and account=:account";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account" => $acc));
        ?>

        <table class="dataList_table">
            <thead><tr>
                    <td> fertilizer_order </td>
                    <td> date </td><td> fertilizer </td><td> account </td><td> quantity </td><td> unit_measure </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php while ($row = $stmt->fetch()) { ?>
                <td class="fertilizer_orderdeleted_id_cols fertilizer_order " title="fertilizer_order" >
                    <?php echo $row['fertilizer_order_id']; ?>
                </td>

                <td>
                    <?php echo $row['date']; ?>
                </td>
                <td>
                    <?php echo $row['fertilizer']; ?>
                </td>
                <td>
                    <?php echo $row['account']; ?>
                </td>
                <td>
                    <?php echo $row['quantity']; ?>
                </td>
                <td>
                    <?php echo $row['unit_measure']; ?>
                </td>


                <td>
                    <a href="#" class="fertilizer_order_delete_link" style="color: #000080;" value="
                       <?php echo $row['fertilizer_order_id']; ?>">Delete</a>
                </td>
                <td>
                    <a href="#" class="fertilizer_order_update_link" style="color: #000080;" value="
                       <?php echo $row['fertilizer_order_id']; ?>">Update</a>
                </td></tr>
        <?php } ?></table><?php
    }

// <editor-fold defaultstate="collapsed" desc="---All Counts-----">
    function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_account_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_category_id   from account_category";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_image() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  image_id   from image";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_district() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  district_id   from district";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_sector() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  sector_id   from sector";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_cell() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  cell_id   from cell";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_contact_us() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  contact_us_id   from contact_us";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_village() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  village_id   from village";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_seed() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  seed_id   from seed";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_fertilizer() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  fertilizer_id   from fertilizer";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_settings() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  settings_id   from settings";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_farmer() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  farmer_id   from farmer";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_consolidation() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  consolidation_id   from consolidation";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_distribution() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  distribution_id   from distribution";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_expenses() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  expenses_id   from expenses";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_harvest() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  harvest_id   from harvest";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_seed_order() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  seed_order_id   from seed_order";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function All_fertilizer_order() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  fertilizer_order_id   from fertilizer_order";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

// </editor-fold>
// Add on
    function All_plot() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  plot_id   from plot";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_lastprofile() {

        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile.profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_farmers() {

        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select farmer.farmer_id, profile.name,  profile.last_name, profile.gender,  profile.telephone_number from profile
                    join farmer on farmer.profile = profile.profile_id
                 join image on profile.image = image.image_id ";
        ?>
        <table class="dataList_table">
            <thead>
                <tr><td> Farmer ID </td>
                    <td> name </td>
                    <td> last_name </td> 
                    <td> Gender </td> 
                    <td> Telephone </td> 
                    <td> Owns a plot </td> 
                    <td> Delete </td> 
                    <td> Update </td> 

                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td class="farmerdeleted_id_cols farmer " title="farmer">        <?php echo $row['farmer_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['telephone_number']; ?> </td>
                    <?php
                    if (!$this->get_if_farmer_has_plot($row['farmer_id'])) {
                        ?> <td class="col_highlight">   <?php echo $has = ($this->get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td><?php
                    } else {
                        ?>
                        <td>        <?php echo $has = ($this->get_if_farmer_has_plot($row['farmer_id'])) ? 'Yes' : 'No'; ?> </td>
                    <?php } ?>

                    <td>
                        <a href="#" class="farmer_delete_link" style="color: #000080;" value="
                           <?php echo $row['farmer_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="farmer_update_link" style="color: #000080;" value="
                           <?php echo $row['farmer_id']; ?>">Update</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_lastimage() {
        $db = new dbconnection();
        $sql = "select   image.image_id from image order by image.image_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['image_id'];
        return $userid;
    }

    function get_plot_id_by_farmer($farmer) {
        $con = new dbconnection();
        $sql = "select    plot_id  from plot  
            join farmer on plot.farmer = farmer.farmer_id 
                 where  plot.farmer =:farmer ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_unassigned_farmers() {
        $db = new dbconnection();
        $sql = " select count(farmer_id) as farmer_id from farmer where farmer_id not in 
                    (select farmer from plot) ";
        $stmt = $db->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['farmer_id'];
        return $userid;
    }

    function get_account() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number
            from profile    join profile on account.profile = profile.profile_id 
            join image on profile.image = image.image_id 
            join profile on account.profile = profile.profile_id 
            join image on profile.image = image.image_id 
            ";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> dob </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telephone_number </td>
                </tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['dob']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['telephone_number']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_seed_order() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from seed_order where seed_order.seed_orderdeleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> seed_order </td>

                    <td> date </td><td> seed </td><td> account </td><td> quantity </td><td> unit_measure </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['seed_order_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['seed']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['unit_measure']; ?>
                    </td>


                    <td>
                        <a href="#" class="seed_order_delete_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="seed_order_update_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function get_seed_order_by_acc($acc) {
        $res = '';
        $con = new dbconnection();
        $sql = "select * from seed_order where seed_order.seed_orderdeleted='no' and account=:account";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account" => $acc));
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> seed_order </td>
                    <td> seed_orderdeleted </td><td> date </td><td> seed </td><td> account </td><td> quantity </td><td> unit_measure </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php while ($row = $stmt->fetch()) { ?>
                <tr> 

                    <td>
                        <?php echo $row['seed_order_id']; ?>
                    </td>
                    <td class="seed_orderdeleted_id_cols seed_order " title="seed_order" >
                        <?php echo $row['seed_orderdeleted']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['seed']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['unit_measure']; ?>
                    </td>


                    <td>
                        <a href="#" class="seed_order_delete_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="seed_order_update_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table><?php
    }

    function get_cat_id_byName($cat) {
        $con = new dbconnection();
        $sql = "select account_category.account_category_id from account_category
                        join account
                        on account.account_category=account_category.account_category_id
                        where account_category.name=:cat;
                       ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":cat" => $cat));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }

    function get_cat_name_byAcc_id($accid) {
        $con = new dbconnection();
        $sql = "select account_category.name 
                from account_category
                join account on account.account_id = account_category.account_category_id 
                 where  account.account_id = :account_id ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account_id" => $accid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_cat_name_byId($cat) {
        $con = new dbconnection();
        $sql = "select account_category.name from account_category
                        join account
                        on account.account_category=account_category.account_category_id
                        where account_category.account_category_id=:cat;
                       ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":cat" => $cat));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_tot_consolidation() {
        $con = new dbconnection();
        $sql = "select  count( *) as tot_cons from consolidation ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['tot_cons'];
        return $userid;
    }

    function get_tot_consolidation_sumary() {
        $con = new dbconnection();
        $sql = "select    count(distinct given_number)as all_cons  from consolidation group by given_number";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $c = 0;
        while ($row = $stmt->fetch()) {
            $c += 1;
        }
        return $c;
    }

    function get_plot_by_village($cell_id) {
        //this is on the consolidation form
        $con = new dbconnection();
        $sql = "select farmer.farmer_id, profile.name,
                                profile.last_name, plot.estimated_value,    profile.gender,  profile.telephone_number, 
                                profile.email,  profile.residence  
                                from farmer
                                join profile on farmer.profile = profile.profile_id 
                                join plot on plot.farmer = farmer.farmer_id 
                                join cell on plot.village = cell.cell_id 
                                where plot.village=:cell and  plot.plot_id not in (select plot from consolidation)";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":cell" => $cell_id));
        ?>
        <table class="corr_plots_tab">
            <thead>
                <tr class="corr_plots_tab_head">

                    <td> farmer_id </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> Plot estimated_value </td>
                    <td> gender </td>
                    <td> telephone_number </td>
                    <td> email </td>
                    <td> residence </td>

                </tr></thead><?php
            while ($row = $stmt->fetch()) {
                ?><tr>   
                    <td>        <?php echo $row['farmer_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['estimated_value']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['telephone_number']; ?> </td>
                    <td>        <?php echo $row['email']; ?> </td>
                    <td>        <?php echo $row['residence']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_cell_with_plots_consolidated_by_cell($cell) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id, cell.name,  sector.name as sector "
                . " from cell "
                . "  join sector on cell.sector = sector.sector_id  "
                . " where cell.name=:cell";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":cell" => $cell));
        ?>
        <table class="dataList_table cellz_plots_tab ">
            <thead><tr>
                    <td> cell </td>
                    <td> Cell name </td>
                    <td> Sector Name </td>
                </tr>
            </thead>
            <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td class="plotcell_cellid_cols">
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo '<b>' . $row['name'] . '</b>'; ?>
                    </td>
                    <td>
                        <?php echo $row['sector']; ?>
                    </td>
                </tr>
                <tr class="corr_plots"><td colspan="7">
                        <?php $this->get_plot_by_village_consolidated($row['cell_id']) ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_cell_with_plots_consolidated() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.cell_id, cell.name,  sector.name as sector from cell   join sector on cell.sector = sector.sector_id   ";
        ?>
        <table class="dataList_table cellz_plots_tab ">
            <thead><tr>
                    <td> cell </td>
                    <td> Cell name </td>
                    <td> Sector Name </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td class="plotcell_cellid_cols">
                        <?php echo $row['cell_id']; ?>
                    </td>
                    <td class="name_id_cols cell " title="cell" >
                        <?php echo '<b>' . $row['name'] . '</b>'; ?>
                    </td>
                    <td>
                        <?php echo $row['sector']; ?>
                    </td>
                </tr>
                <tr class="corr_plots"><td colspan="7">
                        <?php $this->get_plot_by_village_consolidated($row['cell_id']) ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_plot_by_village_consolidated($cell_id) {
        //this can appear anywhere
        $con = new dbconnection();
        $sql = "select farmer.farmer_id, profile.name,
                                profile.last_name, plot.estimated_value,    profile.gender,  profile.telephone_number, 
                                profile.email,  profile.residence  
                                from farmer
                                join profile on farmer.profile = profile.profile_id 
                                join plot on plot.farmer = farmer.farmer_id 
                                join cell on plot.village = cell.cell_id 
                                where plot.village=:cell ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":cell" => $cell_id));
        ?>
        <table class="corr_plots_tab">
            <thead>
                <tr class="corr_plots_tab_head">

                    <td> farmer_id </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> Plot estimated_value </td>
                    <td> gender </td>
                    <td> telephone_number </td>
                    <td> email </td>
                    <td> residence </td>

                </tr></thead><?php
            while ($row = $stmt->fetch()) {
                ?><tr>   
                    <td>        <?php echo $row['farmer_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['estimated_value']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['telephone_number']; ?> </td>
                    <td>        <?php echo $row['email']; ?> </td>
                    <td>        <?php echo $row['residence']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_first_plot_by_cell($cell) {
        $con = new dbconnection();
        $sql = "select plot.plot_id from plot
                    join cell on plot.village = cell.cell_id 
                     where cell.cell_id=:cellid and plot.plot_id not in (select plot from consolidation)
                     order by cell.cell_id asc                      limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("cellid" => $cell));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_last_plot_by_cell($cell) {
        $con = new dbconnection();
        $sql = "select plot.plot_id from plot
                    join cell on plot.village = cell.cell_id 
                    where cell.cell_id=:cellid and plot.plot_id not in (select plot from consolidation)
                    order by plot.plot_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("cellid" => $cell));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_last_plot() {
        $con = new dbconnection();
        $sql = " select plot.plot_id from plot order by plot_id desc limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_given_number_by_farmer($farmer) {
        $con = new dbconnection();
        $sql = " select consolidation.given_number 	 from consolidation
						 join plot on consolidation.plot = plot.plot_id 
						 join farmer on plot.farmer = farmer.farmer_id 
						where farmer.farmer_id=:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['given_number'];
        return $userid;
    }

    function get_plot_by_farmer($farmer) {
        $con = new dbconnection();
        $sql = "select   plot.plot_id
                from plot
                join farmer on plot.farmer = farmer.farmer_id 
                where  plot.farmer =:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_if_farmer_has_plot($farmer) {
        $con = new dbconnection();
        $sql = "select plot.farmer
                from plot
                join farmer on plot.farmer = farmer.farmer_id 
                where farmer.farmer_id=:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $res = $row['farmer'];
        if ($res > 0) {
            return true;
        } else {
            return false;
        }
    }

    function get_oders_seed_fertilizer() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select seed_order.seed_order_id,seed.name as seed_name, seed_order.date,seed_order.seed,seed_order.account,"
                . "seed_order.quantity, (seed_order.quantity *  seed.cost_per_unit) as tot,  seed_order.unit_measure, profile.name as farmer, profile.last_name from seed_order  "
                . "  join seed on seed_order.seed = seed.seed_id "
                . " join account on seed_order.account = account.account_id "
                . "  join profile on account.profile = profile.profile_id  "
                . " where seed_order.seed_orderdeleted='no' "
                . "   ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> Order number </td>
                    <td> date </td><td> seed/Fertilizer </td>
                    <td> Farmer name</td>
                    <td> Farmer Last name</td>
                    <td> quantity </td>
                    <td> Total </td>
                    <td class="off"> unit_measure </td>
                    <td>Delete</td><td>Update</td></tr>

            </thead>
            <tr class="separator_row"><td colspan="9">  Seeds  </td></tr>
            <?php
            $sum1 = 0;
            foreach ($db->query($sql) as $row) {
                $sum1 += $row['tot'];
                ?>
                <tr> 

                    <td>
                        <?php echo $row['seed_order_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['seed_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['farmer']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['tot']; ?>
                    </td>
                    <td class="off">
                        <?php echo $row['unit_measure']; ?>
                    </td>


                    <td>
                        <a href="#" class="seed_order_delete_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="seed_order_update_link" style="color: #000080;" value="
                           <?php echo $row['seed_order_id']; ?>">Update</a>
                    </td></tr>
                <?php
            }
            ?> <tr><td style="text-align: right; font-size: 17px; font-weight: bolder; color: #fff;" colspan="9">  Total:<?php echo '         ' . $sum1; ?>  </td></tr>
            <tr class="separator_row"><td colspan="9">Fertilizers</td></tr><?php
        $sql2 = "select fertilizer_order.fertilizer_order_id,fertilizer.name as fert_name, fertilizer_order.date,fertilizer_order.fertilizer,fertilizer_order.account,"
                . " fertilizer_order.quantity,fertilizer.cost_per_unit*fertilizer_order.quantity as total, fertilizer_order.unit_measure, profile.name as farmer,profile.last_name  from fertilizer_order"
                . "  join fertilizer on fertilizer_order.fertilizer = fertilizer.fertilizer_id  "
                . " join account on fertilizer_order.account = account.account_id "
                . "  join profile on account.profile = profile.profile_id "
                . " where fertilizer_order.fertilizer_orderdeleted='no'  ";
        $sum2 = 0;
        foreach ($db->query($sql2) as $row) {
            $sum2 += $row['total'];
                ?><tr> 

                    <td class="fertilizer_orderdeleted_id_cols fertilizer_order " title="fertilizer_order" >
                        <?php echo $row['fertilizer_order_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['fert_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['farmer']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['total']; ?>
                    </td>
                    <td class="off">
                        <?php echo $row['unit_measure']; ?>
                    </td>


                    <td>
                        <a href="#" class="fertilizer_order_delete_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_order_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="fertilizer_order_update_link" style="color: #000080;" value="
                           <?php echo $row['fertilizer_order_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?>

            <tr><td style="text-align: right; font-size: 17px; font-weight: bolder; color: #fff;" colspan="9">Total <?php echo '  ' . $sum2 ?></td></tr>
        </table>

        <?php
    }

    function get_famers_tel_numbers() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.name,  profile.last_name,  profile.telephone_number,  farmer.farmer_id
                from profile join farmer on farmer.profile = profile.profile_id   ";
        ?>
        <table class="dataList_table margin_free">
            <thead class="no_bg">
                <tr>
                    <td colspan="5">
                        <input type="text" class="textbox full_center_two_h heit_free" name="subj"  placeholder="subject"value="E-Hinga" /><br/><br/>
                    </td>
                </tr>
                <tr>
                    <td colspan="5">
                        <textarea name="msg" style="width: 100%; height: 100px;"></textarea>
                    </td>
                </tr>
                <tr style="background-color: #00ce49;">
                    <td>
                        <input  type="checkbox" name="farmerckbx"  class="farmr_chk_all"/>
                    </td>
                    <td> farmer_id </td>  <td> name </td><td> last_name </td><td> telephone_number </td></tr>
            </thead>

            <?php foreach ($db->query($sql) as $row) {
                ?><tr> 
                    <td>   <input type="checkbox" name="farmerckbx_pack[]"  value="<?php echo $row['telephone_number'] ?>"  class="farmr_chkbx"/></td>
                    <td>        <?php echo $row['farmer_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['telephone_number']; ?> </td>
                </tr>
            <?php } ?><tr>
                <td colspan="5">
                    <?php
                    $res = $this->get_if_any_farmer();
                    if ($res > 0) {
                        ?>
                        <input type="submit" class="confirm_buttons link_cursor" name="send_sms" value="Send Sms">
                    <?php } ?>
                </td>
            </tr></table>

        <?php
    }

    // <editor-fold defaultstate="collapsed" desc="---- used inside other functions -----------">
    function list_account($cat) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.dob,  profile.name,  profile.last_name,  profile.gender,  
                     profile.telephone_number,account.account_id,account.username,account.password, account_category.name as cat
                     from profile    join account on account.profile = profile.profile_id
                     join account_category on account_category.account_category_id=account.account_category 
                     where account.account_category=:cat";
        $stmt = $database->openconnection()->prepare($sql);
        $stmt->execute(array(":cat" => $cat));
        ?>
        <table class="dataList_table corr_plots_tab">
            <thead><tr class="corr_plots_tab_head">
                    <td> User ID </td>
                    <td> Username</td>
                    <td> password </td>
                    <td> dob </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telephone_number </td>
                    <td>Delete</td><td>Update</td></tr></thead>
            <?php while ($row = $stmt->fetch()) { ?>
                <tr> 
                    <td class="account" title="account"> <?php echo $row['account_id']; ?> </td>
                    <td> <?php echo $row['username']; ?> </td>
                    <td> <?php echo $row['password']; ?></td>
                    <td> <?php echo $row['dob']; ?></td>
                    <td> <?php echo $row['name']; ?> </td>
                    <td> <?php echo $row['last_name']; ?> </td>
                    <td> <?php echo $row['gender']; ?> </td>
                    <td> <?php echo $row['telephone_number']; ?> </td>
                    <td>
                        <?php if (!trim($row['cat'] == 'admin')) { ?>
                            <a href="#" class="account_delete_link" style="color: #000080;" value="<?php echo $row['account_id']; ?>">Delete</a>
                        <?php }
                        ?>

                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" value="
                           <?php echo $row['account_id']; ?>">Update</a>
                    </td></tr>

            <?php } ?></table> <?php
        }

// </editor-fold> 
        function get_tot_accounts_by_accCat($cat) {//noon consolidated
            $con = new dbconnection();
            $sql = "select count(*) as tot from account     
                    join account_category on account_category.account_category_id=account.account_category 
                    where account.account_category=:cat";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":cat" => $cat));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['tot'];
            return $userid;
        }

        // <editor-fold defaultstate="collapsed" desc="--------distribution calculations">

        function get_expected_harvest_by_seed($seed) {
            $res = '';
            $con = new dbconnection();
            $sql = "select seed.harvest_rate_m_sq from seed where  and seed.seed_id =:seed_id";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":seed_id" => $seed));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $qty = $row['harvest_rate_m_sq'];

            return $qty;
        }

        function get_needed_qtyseedBY_seed($farmer) {
            $res = '';
            $con = new dbconnection();
            $sql = "select  farmer.farmer_id, profile.name,  profile.last_name,consolidation.plot, seed.name as seed, 
                plot.area_m_sq, sum( area_m_sq*qty_m_sq) as tot_seed, sum(harvest_rate_m_sq*(area_m_sq*qty_m_sq)) as expharv
                from consolidation
                join plot on consolidation.plot = plot.plot_id 
                join seed on consolidation.seed = seed.seed_id 
                join farmer on plot.farmer = farmer.farmer_id 
                join account on consolidation.account = account.account_id 
                join profile on farmer.profile = profile.profile_id 
                where farmer.farmer_id=:farmer group by farmer_id, seed";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":farmer" => $farmer));
            ?>
        <table class="corr_plots_tab">
            <thead>
                <tr class="corr_plots_tab_head">
                    <td> farmer ID </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> Plot n<sup>o</sup> </td>
                    <td> Seed </td>
                    <td> Plot Size (m<sup>2</sup>)</td>
                    <td> Seed needed </td>
                    <td> Expected harvest  </td>

                </tr></thead><?php
        while ($row = $stmt->fetch()) {
                ?><tr>   
                    <td>        <?php echo $row['farmer_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['plot']; ?> </td>
                    <td>        <?php echo $row['seed']; ?> </td>
                    <td>        <?php echo $row['area_m_sq']; ?> </td>
                    <td class="col_highlight_good">        <?php
            echo $qty = ( $row['tot_seed'] >= 1000) ?
            $row['tot_seed'] / 1000 . ' Kg' : $row['tot_seed'] . ' gr';
                ?> </td>
                    <td class="col_highlight_good">        <?php
            echo $harv = ($row['expharv'] >= 1000) ?
            $row['expharv'] / 1000 . ' Kg' : $row['expharv'] . ' gr';
                ?> 
                    </td>
                </tr>
            <?php }
            ?>
            <tr >
                <td colspan="8"></td>
            </tr>
            <tr class="corr_plots_tab_head">

                <td>Farmer ID </td>
                <td>name </td>
                <td>last_name</td>
                <td>plot_id </td>
                <td>Fertilizer</td>
                <td>Plot size m<sup>2</sup></td>
                <td>&nbsp;</td>
                <td>Needed fertilizer</td>

                </td></tr><?php echo $this->get_plot_area_by_farmer($farmer); ?>
            <tr>
                <td colspan="8">
                    <input type="submit" name="send_distribution" value="Distribute" class="confirm_buttons">
                </td>
            </tr>
        </table>
        <?php
    }

    function get_seed_ordered_by_farmer($farmer) {
        $con = new dbconnection();
        $sql = "select seed_order.seed_id from seed_order
               where  seed_order.account =:account";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed_id'];
        return $userid;
    }

    function get_plot_area_by_farmer($farmer) {

        //this is the fertilizer ordered and the size of the 
        $con = new dbconnection();
        $sql = "select  farmer.farmer_id, profile.name,  profile.last_name, consolidation.plot, 
                seed.name as seed, fertilizer.name as fert ,     
                plot.area_m_sq, sum(plot.area_m_sq*  fertilizer.qty_per_msq) as tot_fert 
		        from consolidation 
                join plot on consolidation.plot = plot.plot_id 
                join seed on consolidation.seed = seed.seed_id 
                join fertilizer on fertilizer.seed=seed.seed_id
                join farmer on plot.farmer = farmer.farmer_id 
                join account on consolidation.account = account.account_id 
                join profile on farmer.profile = profile.profile_id 
                where farmer.farmer_id=:farmer 
                group by farmer_id, seed;
                ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        while ($row = $stmt->fetch()) {
            ?> <tr>
                <td> <?php echo $row['farmer_id']; ?></td>
                <td> <?php echo $row['name']; ?></td>
                <td> <?php echo $row['last_name']; ?></td>
                <td> <?php echo $row['plot']; ?></td> 
                <td> <?php echo $row['fert']; ?></td> 
                <td> <?php echo $row['area_m_sq']; ?></td>
                <td></td>
                <td style="background-color: #00ce49; font-weight: bold;">       
                    <?php
//                        echo $tot_fertilizer = (($row['area_m_sq'] * $row['qty_per_msq']) >= 1000) ? 
//                                ($row['area_m_sq'] * $row['qty_per_msq']) / 1000 . ' kg' : 
//                            $tot_fertilizer;
                    ?>
                    <a href="#"><?php echo $row['tot_fert']; ?></a>


                </td>
            </td> </tr><?php
        }
    }

    function get_plot_address($farmer) {
        $con = new dbconnection();
        $sql = "select plot.village    from plot "
                . " join farmer on plot.farmer = farmer.farmer_id  "
                . " where  plot.farmer =:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['village'];
        return $userid;
    }

    function get_seed_by_farmerconsol($farmer) {
        //used in the plot form to check of the farmer is not consolidating for the first time or not
        $con = new dbconnection();
        $sql = "select consolidation.seed "
                . " from consolidation  join plot on consolidation.plot = plot.plot_id "
                . "  join farmer on plot.farmer = farmer.farmer_id "
                . " where plot.farmer =:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed'];
        return $userid;
    }

    function get_seed_by_farmerconsol_count($farmer) {
        //used in the plot form to check of the farmer is not consolidating for the first time or not
        $con = new dbconnection();
        $sql = "select count(distinct consolidation.seed) as seed from consolidation  join plot on consolidation.plot = plot.plot_id "
                . "  join farmer on plot.farmer = farmer.farmer_id "
                . " where plot.farmer =:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed'];
        return $userid;
    }

    function get_farmer_id_by_account($account) {
        $con = new dbconnection();
        $sql = "select farmer.farmer_id from farmer
                join profile on farmer.profile = profile.profile_id 
                join account on account.profile = profile.profile_id 
                where   account.account_id =:account";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":account" => $account));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['farmer_id'];
        return $userid;
    }

// </editor-fold>
    function get_seed_name_by_the_seed_id($seed_id) {
        $con = new dbconnection();
        $sql = "select seed.name from  seed where seed.seed_id=:id";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":id" => $seed_id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name'];
        return $userid;
    }

    function get_if_any_plot() {
        $con = new dbconnection();
        $sql = "select    count(plot_id) as plot_id  from plot  ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['plot_id'];
        return $userid;
    }

    function get_if_any_farmer() {
        $con = new dbconnection();
        $sql = "select count(farmer.farmer_id) as farmer_id from farmer ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['farmer_id'];
        return $userid;
    }

    function get_if_any_seed() {
        $con = new dbconnection();
        $sql = "select    count(seed_id) as  seed_id from seed ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed_id'];
        return $userid;
    }

    function get_if_any_distribution() {
        $con = new dbconnection();
        $sql = "select count(distribution.distribution_id) as distribution_id  from distribution ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['distribution_id'];
        return $userid;
    }

    function farmer_consolidated($farmer) {
        $con = new dbconnection();
        $sql = "select farmer.farmer_id from farmer
                    where farmer_id  in 
                    (select farmer.farmer_id
                    from consolidation
                    join plot on consolidation.plot = plot.plot_id 
                    join farmer on plot.farmer = farmer.farmer_id )
                        and farmer.farmer_id=:farmerid";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("farmerid" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $res = $row['farmer_id'];
        if ($res > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function get_farmerid_by_accid($accid) {
        $con = new dbconnection();
        $sql = "select farmer.farmer_id from farmer
                join profile on farmer.profile = profile.profile_id 
                join account on account.profile = profile.profile_id 
                where  account.account_id =:accid";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":accid" => $accid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['farmer_id'];
        return $userid;
    }

    function get_famerid_by_plot($plot) {
        $con = new dbconnection();
        $sql = "select plot.farmer from plot "
                . "  join farmer on plot.farmer = farmer.farmer_id 
                     join cell on plot.village =cell.cell_id "
                . "  where  plot.plot_id=:plot";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":plot" => $plot));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['farmer'];
        return $userid;
    }

    function get_if_farmernoPlot_diffrnt_areas($farmer) {
        $con = new dbconnection();
        $sql = "SELECT count(distinct plot.village) as n FROM land_cons.plot where farmer=:farmer";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":farmer" => $farmer));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['n'];
        return $userid;
    }

    function get_last_seed() {
        $con = new dbconnection();
        $sql = "SELECT  seed.seed_id from seed order by seed_id desc limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed_id'];
        return $userid;
    }

    function get_seed_by_plot($plot) {
        $con = new dbconnection();
        $sql = "SELECT  plot.seed from plot where plot.plot_id=:plot";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['seed'];
        return $userid;
    }

    function get_farmer_by_consolidation($consolidation) {
        
    }

}
