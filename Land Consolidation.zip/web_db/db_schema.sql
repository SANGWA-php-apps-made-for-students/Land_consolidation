
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
`province_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`province_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district`
--

CREATE TABLE IF NOT EXISTS `district` (
`district_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `province`     int(11)   

,PRIMARY KEY (`district_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `district`     int(11)   

,PRIMARY KEY (`sector_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `sector`     int(11)   

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `village`
--

CREATE TABLE IF NOT EXISTS `village` (
`village_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `cell`     int(11)   

,PRIMARY KEY (`village_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`contact_us_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account`     int(11)   
,`date_contact`     Date 
,`message`     VARCHAR(60) 

,PRIMARY KEY (`contact_us_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `seed`
--

CREATE TABLE IF NOT EXISTS `seed` (
`seed_id`     int(11) NOT NULL AUTO_INCREMENT 
,`seeddeleted`     VARCHAR(60) 
,`name`     VARCHAR(60) 
, `cost_per_unit`     int(11)   

,PRIMARY KEY (`seed_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `fertilizer`
--

CREATE TABLE IF NOT EXISTS `fertilizer` (
`fertilizer_id`     int(11) NOT NULL AUTO_INCREMENT 
,`fertilizerdeleted`     VARCHAR(60) 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`fertilizer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
`settings_id`     int(11) NOT NULL AUTO_INCREMENT 
,`settingsdeleted`     VARCHAR(60) 
,`setting_name`     VARCHAR(60) 
, `qty_m_sq`     int(11)   
,`unit_kg_liter`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`settings_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `farmer`
--

CREATE TABLE IF NOT EXISTS `farmer` (
`farmer_id`     int(11) NOT NULL AUTO_INCREMENT 
,`farmerdeleted`     VARCHAR(60) 
, `profile`     int(11)   

,PRIMARY KEY (`farmer_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `plot`
--

CREATE TABLE IF NOT EXISTS `plot` (
`plot_id`     int(11) NOT NULL AUTO_INCREMENT 
,`plotdeleted`     VARCHAR(60) 
, `area_m_sq`     int(11)   
, `estimated_value`     int(11)   
, `farmer`     int(11)   

,PRIMARY KEY (`plot_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `consolidation`
--

CREATE TABLE IF NOT EXISTS `consolidation` (
`consolidation_id`     int(11) NOT NULL AUTO_INCREMENT 
,`consolidationdeleted`     VARCHAR(60) 
,`date`     Date 
, `account`     int(11)   
, `plot`     int(11)   
,`given_number`     VARCHAR(60) 

,PRIMARY KEY (`consolidation_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `distribution`
--

CREATE TABLE IF NOT EXISTS `distribution` (
`distribution_id`     int(11) NOT NULL AUTO_INCREMENT 
,`distributiondeleted`     VARCHAR(60) 
,`date`     Date 
, `seed`     int(11)   
,`fertilizer`     VARCHAR(60) 
,`farmer_consLand`     VARCHAR(60) 
, `account`     int(11)   
, `qty_seed`     int(11)   
, `qty_fertilizer`     int(11)   
, `expected_harvest`     int(11)   
, `total_value`     int(11)   
,`consolidated`     VARCHAR(60) 

,PRIMARY KEY (`distribution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
`expenses_id`     int(11) NOT NULL AUTO_INCREMENT 
,`expensesdeleted`     VARCHAR(60) 
,`date`     Date 
, `distribution`     int(11)   
,`expense_name`     VARCHAR(60) 
, `total_cost`     int(11)   

,PRIMARY KEY (`expenses_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `harvest`
--

CREATE TABLE IF NOT EXISTS `harvest` (
`harvest_id`     int(11) NOT NULL AUTO_INCREMENT 
,`harvestdeleted`     VARCHAR(60) 
,`date`     Date 
,`farmer_consolidation`     VARCHAR(60) 
, `distribution`     int(11)   
, `quantity_harvested`     int(11)   

,PRIMARY KEY (`harvest_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

