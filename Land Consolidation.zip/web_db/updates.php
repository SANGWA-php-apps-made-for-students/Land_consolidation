<?php

require_once 'connection.php';

class updates {

    function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
        $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
    }

    function update_account_category($name, $account_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
        $stmt->execute(array($name, $account_category_id));
    }

    function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
    }

    function update_image($path, $image_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
        $stmt->execute(array($path, $image_id));
    }

    function update_province($name, $province_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE province set 
name= ? WHERE province_id=?");
        $stmt->execute(array($name, $province_id));
    }

    function update_district($name, $province, $district_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE district set 
name= ?, province= ? WHERE district_id=?");
        $stmt->execute(array($name, $province, $district_id));
    }

    function update_sector($name, $district, $sector_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE sector set 
name= ?, district= ? WHERE sector_id=?");
        $stmt->execute(array($name, $district, $sector_id));
    }

    function update_cell($name, $sector, $cell_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
        $stmt->execute(array($name, $sector, $cell_id));
    }

    function update_contact_us($account, $date_contact, $message, $contact_us_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE contact_us set 
account= ?, date_contact= ?, message= ? WHERE contact_us_id=?");
        $stmt->execute(array($account, $date_contact, $message, $contact_us_id));
    }

    function update_village($name, $cell, $village_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE village set 
name= ?, cell= ? WHERE village_id=?");
        $stmt->execute(array($name, $cell, $village_id));
    }

    function update_seed($seeddeleted, $name, $cost_per_unit, $measure_unit, $qty_m_sq, $harvest_rate_m_sq, $seed_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE seed set 
seeddeleted= ?, name= ?, cost_per_unit= ?, measure_unit= ?, qty_m_sq= ?, harvest_rate_m_sq= ? WHERE seed_id=?");
        $stmt->execute(array($seeddeleted, $name, $cost_per_unit, $measure_unit, $qty_m_sq, $harvest_rate_m_sq, $seed_id));
    }

    function update_fertilizer($fertilizerdeleted, $name, $cost_per_unit, $measure_unit, $fertilizer_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE fertilizer set 
fertilizerdeleted= ?, name= ?, cost_per_unit= ?, measure_unit= ? WHERE fertilizer_id=?");
        $stmt->execute(array($fertilizerdeleted, $name, $cost_per_unit, $measure_unit, $fertilizer_id));
    }

    function update_settings($settingsdeleted, $account, $name, $value, $settings_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE settings set 
settingsdeleted= ?, account= ?, name= ?, value= ? WHERE settings_id=?");
        $stmt->execute(array($settingsdeleted, $account, $name, $value, $settings_id));
    }

    function update_farmer($farmerdeleted, $profile, $farmer_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE farmer set 
farmerdeleted= ?, profile= ? WHERE farmer_id=?");
        $stmt->execute(array($farmerdeleted, $profile, $farmer_id));
    }

    function update_plot($plotdeleted, $area_m_sq, $estimated_value, $farmer, $village, $plot_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE plot set 
plotdeleted= ?, area_m_sq= ?, estimated_value= ?, farmer= ?, village= ? WHERE plot_id=?");
        $stmt->execute(array($plotdeleted, $area_m_sq, $estimated_value, $farmer, $village, $plot_id));
    }

    function update_consolidation($consolidationdeleted, $date, $account, $plot, $given_number, $seed, $consolidation_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE consolidation set 
consolidationdeleted= ?, date= ?, account= ?, plot= ?, given_number= ?, seed= ? WHERE consolidation_id=?");
        $stmt->execute(array($consolidationdeleted, $date, $account, $plot, $given_number, $seed, $consolidation_id));
    }

    function update_distribution($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated, $distribution_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE distribution set 
distributiondeleted= ?, date= ?, seed= ?, fertilizer= ?, farmer_consLand= ?, account= ?, qty_seed= ?, qty_fertilizer= ?, expected_harvest= ?, total_value= ?, consolidated= ? WHERE distribution_id=?");
        $stmt->execute(array($distributiondeleted, $date, $seed, $fertilizer, $farmer_consLand, $account, $qty_seed, $qty_fertilizer, $expected_harvest, $total_value, $consolidated, $distribution_id));
    }

    function update_expenses($expensesdeleted, $date, $distribution, $expense_name, $total_cost, $expenses_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE expenses set 
expensesdeleted= ?, date= ?, distribution= ?, expense_name= ?, total_cost= ? WHERE expenses_id=?");
        $stmt->execute(array($expensesdeleted, $date, $distribution, $expense_name, $total_cost, $expenses_id));
    }

    function update_harvest($harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $harvest_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE harvest set 
harvestdeleted= ?, date= ?, farmer_consolidation= ?, distribution= ?, quantity_harvested= ? WHERE harvest_id=?");
        $stmt->execute(array($harvestdeleted, $date, $farmer_consolidation, $distribution, $quantity_harvested, $harvest_id));
    }

    function update_seed_order($seed_orderdeleted, $date, $seed, $account, $quantity, $unit_measure, $seed_order_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE seed_order set 
seed_orderdeleted= ?, date= ?, seed= ?, account= ?, quantity= ?, unit_measure= ? WHERE seed_order_id=?");
        $stmt->execute(array($seed_orderdeleted, $date, $seed, $account, $quantity, $unit_measure, $seed_order_id));
    }

    function update_fertilizer_order($fertilizer_orderdeleted, $date, $fertilizer, $account, $quantity, $unit_measure, $fertilizer_order_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE fertilizer_order set 
fertilizer_orderdeleted= ?, date= ?, fertilizer= ?, account= ?, quantity= ?, unit_measure= ? WHERE fertilizer_order_id=?");
        $stmt->execute(array($fertilizer_orderdeleted, $date, $fertilizer, $account, $quantity, $unit_measure, $fertilizer_order_id));
    }

}
