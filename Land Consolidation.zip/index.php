<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>CROP CULTIVATION MANAGEMENT SYSTEM</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/>    </head>
    <style>
        #home_pic{
            width: 470px;
            height: 470px;
            border-radius:  100%;
            border: 2px solid #fff;
            box-shadow:  0px 0px 25px #fff;
            background-image: url('web_images/maize.png');


        }
        h1, #home_part2 div{
            color: #fff;

        }
        h1{
            border: 1px solid #fff;
            width: 100%;
        }
        #home_part2{
            max-width: 450px;
            float: right;
            font-size: 16px;
            text-indent: 15px;
            border: none;
            box-shadow: none;

        }
        .whilte_text{
            font-size: 16px;
        }
    </style>
    <body>
        <form action="index.php" method="post">
            <div class="home_bg"></div> 

            <div class="parts eighty_centered home_parts no_paddin_shade_no_Border " style="box-shadow: none; padding: 0px;">
                <?php
                include 'header_menu.php';
                ?>
                <div class="parts full_center_two_h heit_free x_height_4x " style="border: none;box-shadow: none;  min-height: 450px;">
                    <div class="parts" id="home_part2">
                        <h1>
                            Our Land
                        </h1>
                        <div class="parts no_paddin_shade_no_Border">
                            <p>  Humanity has a huge advantage over all life on Earth—the ability to grow food. Every other lifeform spends most of their day hunting for and gathering nourishment. Today, billions of us are sustained by what farmers grow. When it comes to survival, growing food is clearly an asset. However, this upper hand is fragile.</p>
                            <p>Just like the air we breathe or the water we drink, soil needs to be protected. The dirt on a baseball field and the soil in your garden may look similar—but they're worlds apart. Soil is complicated. It comes in many forms, from many places, with a variety of names. Infertile dirt is easy to find while the lively, nutrient-rich soil that grows our food is rare and precious.</p>
                        </div>

                        <h1>
                            Our harvest
                        </h1>
                        <div class="parts  no_paddin_shade_no_Border">
                            <p>
                                Is it possible for the farmer in Rwanda who on an average owns less than two acres, to compete with the Latin American farmer who owns more than 50 hectares of land and exports soyabean meal? 
                                We may have to take some innovative measures, apart from several meaningful actions already initiated by the Government, to correct such imbalances.
                                Enhance value addition
                            </p>
                        </div>
                        <h1>
                            Our markets
                        </h1>
                    </div>
                    <div class="parys eighty_centered">

                    </div>
                    <div class="parts "id="home_pic">

                    </div>

                    <h1 class="parts full_center_two_h heit_free">
                        Our Economy
                    </h1>
                    <div class="parts whilte_text full_center_two_h heit_free no_paddin_shade_no_Border">
                        <p> Some of the major role of agriculture in economic development of a country are as follows:
                            Agricultural sector plays a strategic role in the process of economic development of a country.
                            It has already made a significant contribution to the economic prosperity of advanced countries and its role in the economic development of less developed countries is of vital importance
                        </p>
                        <p>
                            In other words, where per capita real income is low, emphasis is being laid on agriculture and other primary industries.
                            “Increase in agricultural production and the rise in the per-capita income of the rural community, together with the industrialisation and urbanisation, lead to an increased demand in industrial production”-Dr. Bright Singh.
                            The history of England is clear evidence that Agricultural Revolution preceded the Industrial Revolution there. In U.S.A. and Japan, also agricultural development has helped to a greater extent in the process of their industrialisation. Similarly, various under-developed countries of the world engaged in the process of economic development have by now learnt the limitations of putting over-emphasis on industrialisation as a means to attain higher per capita real income. “Thus industrial and agricultural developments are not alternatives but are complementary and are mutually supporting with respect to both inputs and outputs.”
                        </p>

                    </div>
                </div>
                <div id="fb-root"></div>
                <div class="parts eighty_centered footer">Copyrights <?php echo date("Y"); ?>
                    <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>        </div>  
            </div>

        </form>

        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>      
    </body>
</html>
