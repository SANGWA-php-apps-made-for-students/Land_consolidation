var selected_id = '';//this id defferentiates if the user selects the distribution for harvest or for expenses
var distr_selected = '';//this is to be initilized where use chooses the farmer fon distribution form

$(document).ready(function () {
    try {
        validate_numbers_textfields();
        get_new_data_hide_show();
        get_account_category_id_combo();
        get_profile_id_combo();
        get_image_id_combo();
        get_province_id_combo();
        get_district_id_combo();
        get_sector_id_combo();
        get_cell_id_combo();

        get_farmer_id_combo();
        get_plot_id_combo();
        get_seed_id_combo();
        get_account_id_combo();
        get_distribution_id_combo();
        get_plot_id_combo();
        get_fertilizer_id_combo();

        //deletion updates
        account_category_del_udpate();
        account_del_udpate();
        profile_del_udpate();
        image_del_udpate();
        province_del_udpate();
        district_del_udpate();
        sector_del_udpate();
        cell_del_udpate();
        contact_us_del_udpate();
        village_del_udpate();
        seed_del_udpate();
        fertilizer_del_udpate();
        settings_del_udpate();
        farmer_del_udpate();
        plot_del_udpate();
        consolidation_del_udpate();
        distribution_del_udpate();
        expenses_del_udpate();
        harvest_del_udpate();
        hide_select_pane();
        selectable_link_click();
        show_farmer();
        show_checkbox_farmer();
        show_distribution();
        show_distribution_by_harvest();
        show_plot_with_cells();
        show_farmer_no_plot();
        show_farmer_distr();
        get_check_all_farmers();
        get_village_id_combo();
        seed_order_del_udpate();
        fertilizer_order_del_udpate();
        get_plot_with_village_selected();
        hide_famers_plots();
    } catch (err) {
        alert(err.message);
    }

});

function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {
        $('.new_data_box').slideToggle(200);
    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').text();
            $.post('../Admin/handler.php', {cbo_account_category: cbo_account_category}, function (data) {
                $('#txt_account_category_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').text();
            $.post('../Admin/handler.php', {cbo_profile: cbo_profile}, function (data) {
                $('#txt_profile_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').text();
            $.post('../Admin/handler.php', {cbo_image: cbo_image}, function (data) {
                $('#txt_image_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_province_id_combo() {
    try {
        $('.cbo_province').change(function () {
            var cbo_province = $('.cbo_province option:selected').text();
            $.post('../Admin/handler.php', {cbo_province: cbo_province}, function (data) {
                $('#txt_province_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_district_id_combo() {
    try {
        $('.cbo_district').change(function () {
            var cbo_district = $('.cbo_district option:selected').text();
            $.post('../Admin/handler.php', {cbo_district: cbo_district}, function (data) {
                $('#txt_district_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').text();
            $.post('../Admin/handler.php', {cbo_sector: cbo_sector}, function (data) {
                $('#txt_sector_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
            $('#txt_cell_id').val(cbo_cell);

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').text();
            $.post('../Admin/handler.php', {cbo_profile: cbo_profile}, function (data) {
                $('#txt_profile_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_farmer_id_combo() {
    try {
        $('.cbo_farmer').change(function () {
            var cbo_farmer = $('.cbo_farmer option:selected').text();
            $.post('../Admin/handler.php', {cbo_farmer: cbo_farmer}, function (data) {
                $('#txt_farmer_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_plot_id_combo() {
    try {
        $('.cbo_plot').change(function () {
            var cbo_plot = $('.cbo_plot option:selected').text();
            alert(cbo_plot);
            $.post('../Admin/handler.php', {cbo_plot: cbo_plot}, function (data) {
                $('#txt_plot_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_seed_id_combo() {
    try {
        $('.cbo_seed').change(function () {
            var cbo_seed = $('.cbo_seed option:selected').val();

            $('#txt_seed_id').val(cbo_seed);

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_distribution_id_combo() {
    try {
        $('.cbo_distribution').change(function () {
            var cbo_distribution = $('.cbo_distribution option:selected').text();
            $.post('../Admin/handler.php', {cbo_distribution: cbo_distribution}, function (data) {
                $('#txt_distribution_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_village_id_combo() {
    try {
        $('.cbo_village').change(function () {
            var cbo_village = $('.cbo_village option:selected').val();
            $('#txt_village_id').val(cbo_village);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_fertilizer_id_combo() {
    try {
        $('.cbo_fertilizer').change(function () {
            var cbo_fertilizer = $('.cbo_fertilizer option:selected').val();
            $('#txt_fertilizer_id').val(cbo_fertilizer);
        });
    } catch (err) {
        alert(err.message);
    }
}

//update from account ...

function account_del_udpate() {
    $('.account_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account').attr('title').trim();
        var id_update = $(this).attr('value').trim();

        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
           

        }).complete(function () {
//            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
    $('.account_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account').attr('title');
        var id_delete = $(this).attr('value').trim();
         
        $(this).closest('tr').slideUp(400);
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
         
        }).complete(function () {

        });

    });
}//update from account_category ...

function account_category_del_udpate() {
    $('.account_category_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.account_category').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
    $('.account_category_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.account_category').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from profile ...

function profile_del_udpate() {
    $('.profile_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.profile').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
    $('.profile_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.profile').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from image ...

function image_del_udpate() {
    $('.image_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.image').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
    $('.image_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.image').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from province ...

function province_del_udpate() {
    $('.province_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.province').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprovince.. 
    $('.province_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.province').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from district ...

function district_del_udpate() {
    $('.district_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict.. 
    $('.district_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.district').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from sector ...

function sector_del_udpate() {
    $('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
    $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cell ...

function cell_del_udpate() {
    $('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title').trim();
        var id_update = $(this).attr('value').trim();

        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
    $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
            alert(data);
        }).complete(function () {

        });

    });
}//update from contact_us ...

function contact_us_del_udpate() {
    $('.contact_us_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcontact_us.. 
    $('.contact_us_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.contact_us').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from village ...

function village_del_udpate() {
    $('.village_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage.. 
    $('.village_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.village').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {

        });

    });
}//update from seed ...

function seed_del_udpate() {
    $('.seed_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.seed').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromseed.. 
    $('.seed_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.seed').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from fertilizer ...

function fertilizer_del_udpate() {
    $('.fertilizer_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.fertilizer').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfertilizer.. 
    $('.fertilizer_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.fertilizer').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from settings ...

function settings_del_udpate() {
    $('.settings_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.settings').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsettings.. 
    $('.settings_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.settings').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from farmer ...

function farmer_del_udpate() {
    $('.farmer_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.farmer').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfarmer.. 
    $('.farmer_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.farmer').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from plot ...

function plot_del_udpate() {
    $('.plot_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.plot').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromplot.. 
    $('.plot_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.plot').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from consolidation ...

function consolidation_del_udpate() {
    $('.consolidation_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.consolidation').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromconsolidation.. 
    $('.consolidation_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.consolidation').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from distribution ...

function distribution_del_udpate() {
    $('.distribution_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.distribution').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistribution.. 
    $('.distribution_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.distribution').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from expenses ...

function expenses_del_udpate() {
    $('.expenses_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.expenses').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromexpenses.. 
    $('.expenses_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.expenses').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from harvest ...

function harvest_del_udpate() {
    $('.harvest_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.harvest').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromharvest.. 
    $('.harvest_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.harvest').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}
function seed_order_del_udpate() {
    $('.seed_order_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.seed_order').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromseed_order.. 
    $('.seed_order_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.seed_order').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from fertilizer_order ...

function fertilizer_order_del_udpate() {
    $('.fertilizer_order_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.fertilizer_order').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromfertilizer_order.. 
    $('.fertilizer_order_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.fertilizer_order').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}

//selecting the extisting record for the foreign

function get_foreign_click(dialog_title, table) {
    $(".foreign_select").show("puff", {percent: 100}, 100, function () {
        $('.dialog').show("drop", {direction: 'up'}, 500);
    });
    $('.dialog_title').html(dialog_title);
    //we hide all the table and show only one table
    $('.tables').hide();
    $('#' + table).show();
    //here is to show the dialog   
}
function selectable_link_click() {
    //account
    $('.select_link_farmer').click(function () {
        var farmer_id = $(this).closest('td').siblings('.farmerid_cols').text().trim();
        var farmer_name = $(this).closest('td').siblings('.farmer_name').text().trim();
        var consolidated = $(this).closest('td').siblings('.cons_not').text().trim();
        if (consolidated == 'Consolidated') {
            $('#txt_cconsolidated').val('consolidated');
        }

        $('#txt_farmer_id').val(farmer_id);
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('#name_holder').html('(' + farmer_name + ')');
        $('.menu').show();
        //request for profile
        //stock for product
        if (distr_selected == 'farmer_ditribution') {
            //show the gif and calculate
            $('.ready_to_hide').slideUp(200);
            var farmer_needed_seeds = farmer_id;
            
             $('#calc_row').addClass('load_bg');
            $.post('../Admin/handler.php', {farmer_needed_seeds: farmer_needed_seeds}, function (data) {
                $('#calc_row').show().html(data);
            }).complete(function () {
                 $('#calc_row').removeClass('load_bg');
            });

        }
    });
    $('.select_link_distribution').click(function () {
        var distr_id = $(this).closest('td').siblings('.distrId_cols').text().trim();
        var distr_date = $(this).closest('td').siblings('.distr_date_cols').text().trim();

        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        if (selected_id != 'harvest') {
            $('#selected_profile').html('(' + distr_date + ')');
            $('#txt_distribution_id').val(distr_id);

        } else if (selected_id == 'harvest') {
            $('#selected_distr_harvest').html(distr_date);
            $("#txt_distr_harvst_id").val(distr_id);
        }
        $('.menu').show();

        //request for profile

        //stock for product
    });
    $('.select_link_stockstock').click(function () {
        var item_id = $(this).closest('td').siblings('.item_id_col').text().trim();
        var item_name = $(this).closest('td').siblings('.item_name_col').text().trim();
        $('#txt_item_id').val(item_id);
        var quantity_av = item_id;
        $('#item_id_holder').html('(' + item_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $.post('../Admin/handler.php', {quantity_av: quantity_av}, function (data) {
            $('#Qty_check').val(data);
        });
    });
    
    }

function show_farmer() {
    $('#foreign_farmer').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a farmer', 'farmer');

    });

}
function show_farmer_distr() {
    $('#foreign_farmer_distr').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a farmer', 'farmer_with_plots');
        distr_selected = 'farmer_ditribution';

    });

}

function show_farmer_no_plot() {
    $('#foreign_farmer_no_plot').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a farmer', 'farmer_no_plot');

    });

}

function show_checkbox_farmer() {
    $('#foreign_farmer_check').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select  farmers', 'farmer_chk');

    });
}
function show_distribution() {
    $('#foreign_distribution').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select  distribution', 'distribution_expense');
      
    });
}
function show_distribution_by_harvest() {
    //show distribution wheren we click harvest lisnk
    $('#foreign_harvest').unbind('click').click(function () {
        selected_id = 'harvest';
        $('.menu').hide();
        get_foreign_click('select  distribution', 'distribution');
         
    });
}

function show_plot_with_cells() {
    $('#foreign_plots_by_cell').unbind('click').click(function () {
        get_foreign_click('Plots By cells (All cells belong to Nyakaliro)', 'plots_with_cells');
    });
}
function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}
function get_check_all_farmers() {
    $('.farmr_chk_all').on('change', function () {
        if ($(this).is(':checked')) {
            $('.farmr_chkbx').prop('checked', true);
        } else if (!$(this).is(':checked')) {

            $('.farmr_chkbx').prop('checked', false);
        }
    });
}
function get_plot_with_village_selected() {
    $('.cell_select_link').unbind('click').click(function () {
        var cell = $(this).closest('td').siblings('.plotcell_cellid_cols').text().trim();
        var cell_name = $(this).closest('td').siblings('.cell_name_cols').text().trim();


        $('#selected_cell_name').html('Plots from:       <b>' + cell_name + '</b>');
        $('#txt_selected_cell').val(cell);
        $('.foreign_select').fadeOut(300);
        $('.menu').show();
        $('.dialog').hide("drop", {direction: "up"}, 500);
    });
}
function hide_famers_plots() {
    $('#hide_famer_btn').unbind('click').click(function () {
        $('.corr_plots').slideToggle(200);
    });
}