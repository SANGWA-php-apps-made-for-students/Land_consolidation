-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 05, 2018 at 12:02 PM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kptcsumh_land_cons`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `account_category` int(11) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(60) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_category`, `date_created`, `profile`, `username`, `password`, `is_online`) VALUES
(87, 17, '2017-12-16', 104, 'paul@gmail.com', '123', 'no'),
(92, 14, '2017-12-18', 109, 'ahmed@gmail.com', '123', 'no'),
(101, 20, '2015-12-19', 118, 'felicien@gmail.com', '123', 'no'),
(102, 20, '2015-12-19', 119, 'fabien@gmail.com', '123', 'no'),
(103, 20, '2015-12-19', 120, 'fiacle@gmail.com', '123', 'no'),
(105, 20, '2016-12-19', 121, 'ferooz@gmail.com', '123', 'no'),
(106, 20, '2017-12-20', 122, 'musa@gmail.com', '123', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `account_category`
--

CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `account_category`
--

INSERT INTO `account_category` (`account_category_id`, `name`) VALUES
(14, 'agronomist'),
(17, 'admin'),
(20, 'farmer');

-- --------------------------------------------------------

--
-- Table structure for table `cell`
--

CREATE TABLE `cell` (
  `cell_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cell`
--

INSERT INTO `cell` (`cell_id`, `name`, `sector`) VALUES
(18, 'Gishore', 9),
(19, 'Gatare', 9),
(20, 'Rwimbogo', 9),
(21, 'Munini', 9),
(22, 'Bihembe', 9);

-- --------------------------------------------------------

--
-- Table structure for table `consolidation`
--

CREATE TABLE `consolidation` (
  `consolidation_id` int(11) NOT NULL,
  `consolidationdeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `plot` int(11) DEFAULT NULL,
  `given_number` varchar(60) DEFAULT NULL,
  `seed` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `consolidation`
--

INSERT INTO `consolidation` (`consolidation_id`, `consolidationdeleted`, `date`, `account`, `plot`, `given_number`, `seed`) VALUES
(18, 'no', '2015-12-19', 92, 12, '11-14', 5),
(19, 'no', '2015-12-19', 92, 14, '11-14', 5),
(21, 'no', '2015-12-19', 92, 15, '13-15', 4),
(22, 'no', '2016-12-19', 87, 11, '11-16', 5),
(23, 'no', '2016-12-19', 87, 12, '11-16', 5),
(24, 'no', '2016-12-19', 87, 14, '11-16', 5),
(25, 'no', '2016-12-19', 87, 16, '11-16', 5),
(26, 'no', '2017-12-20', 87, 17, '17-20', 6),
(27, 'no', '2017-12-20', 87, 19, '17-20', 6),
(28, 'no', '2017-12-20', 87, 20, '17-20', 6),
(29, 'no', '2018-08-01', 92, 21, '21-22', 4),
(30, 'no', '2018-08-01', 92, 22, '21-22', 4);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `contact_us_id` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `date_contact` date DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `distribution`
--

CREATE TABLE `distribution` (
  `distribution_id` int(11) NOT NULL,
  `distributiondeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `seed` int(11) DEFAULT NULL,
  `fertilizer` varchar(60) DEFAULT NULL,
  `farmer_consLand` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `qty_seed` int(11) DEFAULT NULL,
  `qty_fertilizer` int(11) DEFAULT NULL,
  `expected_harvest` int(11) DEFAULT NULL,
  `total_value` int(11) DEFAULT NULL,
  `consolidated` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `distribution`
--

INSERT INTO `distribution` (`distribution_id`, `distributiondeleted`, `date`, `seed`, `fertilizer`, `farmer_consLand`, `account`, `qty_seed`, `qty_fertilizer`, `expected_harvest`, `total_value`, `consolidated`) VALUES
(46, 'no', '2016-12-19', 4, '0', '68', 87, 10000000, 0, 60000000, 0, 'yes'),
(47, 'no', '2016-12-19', 5, '0', '68', 87, 7820000, 0, 54740000, 0, 'yes'),
(48, 'no', '2016-12-19', 0, '11', '68', 87, 0, 40000, 54740000, 0, 'yes'),
(49, 'no', '2016-12-19', 0, '13', '68', 87, 0, 20000, 54740000, 0, 'yes'),
(50, 'no', '2016-12-19', 5, '0', '71', 87, 16100000, 0, 112700000, 0, 'yes'),
(51, 'no', '2016-12-19', 0, '11', '71', 87, 0, 70000, 112700000, 0, 'yes'),
(52, 'no', '2017-12-19', 5, '0', '71', 87, 16100000, 0, 112700000, 0, 'yes'),
(53, 'no', '2017-12-19', 0, '11', '71', 87, 0, 70000, 112700000, 0, 'yes'),
(54, 'no', '2016-09-19', 4, '0', '68', 87, 10000000, 0, 60000000, 0, 'yes'),
(55, 'no', '2016-09-19', 5, '0', '68', 87, 24840000, 0, 173880000, 0, 'yes'),
(56, 'no', '2016-09-19', 0, '11', '68', 87, 0, 40000, 173880000, 0, 'yes'),
(57, 'no', '2016-09-19', 0, '13', '68', 87, 0, 20000, 173880000, 0, 'yes'),
(58, 'no', '2016-09-19', 5, '0', '71', 87, 16100000, 0, 112700000, 0, 'yes'),
(59, 'no', '2016-09-19', 0, '11', '71', 87, 0, 70000, 112700000, 0, 'yes'),
(60, 'no', '2016-09-19', 4, '0', '68', 87, 10000000, 0, 60000000, 0, 'yes'),
(61, 'no', '2016-09-19', 5, '0', '68', 87, 24840000, 0, 173880000, 0, 'yes'),
(62, 'no', '2016-09-19', 0, '11', '68', 87, 0, 40000, 173880000, 0, 'yes'),
(63, 'no', '2016-09-19', 0, '13', '68', 87, 0, 20000, 173880000, 0, 'yes'),
(64, 'no', '2016-09-19', 5, '0', '69', 87, 36800000, 0, 257600000, 0, 'yes'),
(65, 'no', '2016-11-19', 5, '0', '69', 92, 36800000, 0, 257600000, 0, 'yes'),
(66, 'no', '2016-11-19', 5, '0', '71', 92, 16100000, 0, 112700000, 0, 'yes'),
(67, 'no', '2016-11-19', 0, '11', '71', 92, 0, 70000, 112700000, 0, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `district_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `province` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expenses_id` int(11) NOT NULL,
  `expensesdeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `distribution` int(11) DEFAULT NULL,
  `expense_name` varchar(60) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expenses_id`, `expensesdeleted`, `date`, `distribution`, `expense_name`, `total_cost`) VALUES
(36, 'no', '2016-09-19', 46, 'cultivating', 60000),
(37, 'no', '2016-09-19', 47, 'cultivating', 60000),
(38, 'no', '2016-09-19', 48, 'cultivating', 60000),
(39, 'no', '2016-09-19', 49, 'cultivating', 60000),
(40, 'no', '2016-09-19', 54, 'cultivating', 60000),
(41, 'no', '2016-09-19', 55, 'cultivating', 60000),
(42, 'no', '2016-09-19', 56, 'cultivating', 60000),
(43, 'no', '2016-09-19', 57, 'cultivating', 60000),
(44, 'no', '2016-09-19', 60, 'cultivating', 60000),
(45, 'no', '2016-09-19', 61, 'cultivating', 60000),
(46, 'no', '2016-09-19', 62, 'cultivating', 60000),
(47, 'no', '2016-09-19', 63, 'cultivating', 60000),
(48, 'no', '2016-09-19', 50, 'mowing', 200000),
(49, 'no', '2016-09-19', 51, 'mowing', 200000),
(50, 'no', '2016-09-19', 52, 'mowing', 200000),
(51, 'no', '2016-09-19', 53, 'mowing', 200000),
(52, 'no', '2016-09-19', 58, 'mowing', 200000),
(53, 'no', '2016-09-19', 59, 'mowing', 200000),
(54, 'no', '2016-09-19', 64, 'security', 8000),
(55, 'no', '2016-09-19', 64, 'security', 780);

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `farmer_id` int(11) NOT NULL,
  `farmerdeleted` varchar(60) DEFAULT NULL,
  `profile` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`farmer_id`, `farmerdeleted`, `profile`) VALUES
(68, 'no', 118),
(69, 'no', 119),
(70, 'no', 120),
(71, 'no', 121),
(72, 'no', 122);

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer`
--

CREATE TABLE `fertilizer` (
  `fertilizer_id` int(11) NOT NULL,
  `fertilizerdeleted` varchar(60) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `cost_per_unit` varchar(60) DEFAULT NULL,
  `qty_per_msq` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fertilizer`
--

INSERT INTO `fertilizer` (`fertilizer_id`, `fertilizerdeleted`, `name`, `cost_per_unit`, `qty_per_msq`) VALUES
(11, 'no', '  NPK', '  5670', 1000),
(13, 'no', '  MANURE 45G', '  1200', 500),
(14, 'no', 'NPK1717', '400', 30);

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer_order`
--

CREATE TABLE `fertilizer_order` (
  `fertilizer_order_id` int(11) NOT NULL,
  `fertilizer_orderdeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `fertilizer` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_measure` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fertilizer_order`
--

INSERT INTO `fertilizer_order` (`fertilizer_order_id`, `fertilizer_orderdeleted`, `date`, `fertilizer`, `account`, `quantity`, `unit_measure`) VALUES
(1, 'no', '2015-12-19', 11, 101, 15, 'Kg'),
(2, 'no', '2015-12-19', 13, 101, 60, 'Kg'),
(3, 'no', '2016-12-19', 11, 105, 8000, 'Kg'),
(4, 'no', '2016-12-19', 11, 105, 56000, 'Kg'),
(5, 'no', '2017-12-20', 14, 106, 60, 'Kg'),
(6, 'no', '2017-12-20', 14, 106, 60, 'Kg');

-- --------------------------------------------------------

--
-- Table structure for table `harvest`
--

CREATE TABLE `harvest` (
  `harvest_id` int(11) NOT NULL,
  `harvestdeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `farmer_consolidation` varchar(60) DEFAULT NULL,
  `distribution` int(11) DEFAULT NULL,
  `quantity_harvested` int(11) DEFAULT NULL,
  `cost_per_unit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `harvest`
--

INSERT INTO `harvest` (`harvest_id`, `harvestdeleted`, `date`, `farmer_consolidation`, `distribution`, `quantity_harvested`, `cost_per_unit`) VALUES
(16, 'no', '2016-09-19', 'yes', 46, 600, 2300000),
(17, 'no', '2016-09-19', 'yes', 47, 600, 2300000),
(18, 'no', '2016-09-19', 'yes', 48, 600, 2300000),
(19, 'no', '2016-09-19', 'yes', 49, 600, 2300000),
(20, 'no', '2016-09-19', 'yes', 54, 600, 2300000),
(21, 'no', '2016-09-19', 'yes', 55, 600, 2300000),
(22, 'no', '2016-09-19', 'yes', 56, 600, 2300000),
(23, 'no', '2016-09-19', 'yes', 57, 600, 2300000),
(24, 'no', '2016-09-19', 'yes', 60, 600, 2300000),
(25, 'no', '2016-09-19', 'yes', 61, 600, 2300000),
(26, 'no', '2016-09-19', 'yes', 62, 600, 2300000),
(27, 'no', '2016-09-19', 'yes', 63, 600, 2300000),
(28, 'no', '2016-09-19', 'yes', 50, 300, 200),
(29, 'no', '2016-09-19', 'yes', 51, 300, 200),
(30, 'no', '2016-09-19', 'yes', 52, 300, 200),
(31, 'no', '2016-09-19', 'yes', 53, 300, 200),
(32, 'no', '2016-09-19', 'yes', 58, 300, 200),
(33, 'no', '2016-09-19', 'yes', 59, 300, 200),
(34, 'no', '2016-09-19', 'yes', 64, 450, 400);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `image_id` int(11) NOT NULL,
  `path` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`image_id`, `path`) VALUES
(9, '18.jpeg'),
(10, '19.jpeg'),
(12, '.jpeg'),
(13, '20.png'),
(14, '21.png'),
(15, '22.png'),
(16, '23.png'),
(17, '24.png'),
(18, '25.JPG'),
(19, '26.jpeg'),
(20, '27.jpeg'),
(21, '28.jpeg'),
(22, '29.jpeg'),
(23, '30.jpeg'),
(24, '31.jpeg'),
(25, '32.jpeg'),
(26, '33.jpeg'),
(27, '34.jpeg'),
(28, '35.jpeg'),
(29, '36.jpeg'),
(30, '37.jpeg'),
(31, '38.jpeg'),
(32, '39.jpeg'),
(33, '40.jpeg'),
(34, '41.jpeg'),
(35, '42.jpeg'),
(36, '43.jpeg'),
(37, '44.jpeg'),
(38, '45.jpeg'),
(39, '46.jpeg'),
(40, '47.jpeg'),
(41, '48.jpeg'),
(42, '49.jpeg'),
(43, '50.jpeg'),
(44, '51.jpeg'),
(45, '52.jpeg'),
(46, '53.jpeg'),
(47, '54.jpeg'),
(48, '55.jpeg'),
(49, '56.jpeg'),
(50, '57.jpeg'),
(51, '58.jpeg'),
(52, '59.jpeg'),
(53, '60.jpeg'),
(54, '61.jpeg'),
(55, '62.jpeg'),
(56, '63.jpeg'),
(57, '64.jpeg'),
(58, '65.jpeg'),
(59, '66.jpeg'),
(60, '67.jpeg'),
(61, '68.jpeg'),
(62, '69.jpeg'),
(63, '70.jpeg'),
(64, '71.jpeg'),
(65, '72.jpeg'),
(66, '73.jpeg'),
(67, '74.jpeg'),
(68, '75.jpeg'),
(69, '76.jpeg'),
(70, '77.jpeg'),
(71, '78.jpeg'),
(72, '79.jpeg'),
(73, '80.jpeg'),
(74, '81.png'),
(75, '82.png'),
(76, '83.PNG'),
(77, '84.png'),
(78, '.png'),
(79, '86.png'),
(80, '87.PNG'),
(81, '88.PNG'),
(82, '89.jpeg'),
(83, '90.PNG'),
(84, '91.png'),
(85, '92.xcf'),
(86, '93.png'),
(87, '94.jpeg'),
(88, '95.PNG'),
(89, '96.jpeg'),
(90, '97.jpeg'),
(91, '98.jpeg'),
(92, '99.jpeg'),
(93, '100.jpeg'),
(94, '101.jpeg'),
(95, '102.jpeg'),
(96, '104.jpeg'),
(97, '105.jpeg'),
(98, '106.jpeg'),
(99, '107.jpeg'),
(100, '104.jpeg'),
(101, '109.jpeg'),
(102, '110.jpeg'),
(103, '111.jpeg'),
(104, '112.jpeg'),
(105, '113.jpeg'),
(106, '114.jpeg'),
(107, '115.jpeg'),
(108, '116.jpeg'),
(109, '117.jpeg'),
(110, '118.jpeg'),
(111, '119.jpeg'),
(112, '120.jpeg'),
(113, '121.docx');

-- --------------------------------------------------------

--
-- Table structure for table `plot`
--

CREATE TABLE `plot` (
  `plot_id` int(11) NOT NULL,
  `plotdeleted` varchar(60) DEFAULT NULL,
  `area_m_sq` double DEFAULT NULL,
  `estimated_value` int(11) DEFAULT NULL,
  `farmer` int(11) DEFAULT NULL,
  `village` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `plot`
--

INSERT INTO `plot` (`plot_id`, `plotdeleted`, `area_m_sq`, `estimated_value`, `farmer`, `village`) VALUES
(11, 'no', 40000, 15000000, 68, 18),
(12, 'no', 34000, 7000000, 68, 18),
(13, 'no', 60000, 4500000, 69, 19),
(14, 'no', 80000, 4000000, 69, 18),
(15, 'no', 50000, 23000000, 68, 19),
(16, 'no', 70000, 4000000, 71, 18),
(17, 'no', 56000, 340000, 70, 21),
(18, 'no', 800000, 7800000, 70, 22),
(19, 'no', 10000, 2000000, 72, 21),
(20, 'no', 20000, 10000000, 72, 21),
(21, 'no', 89000, 23000000, 69, 18),
(22, 'no', 70000, 34500000, 69, 18);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `gender` varchar(60) DEFAULT NULL,
  `telephone_number` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `residence` varchar(60) DEFAULT NULL,
  `image` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_id`, `dob`, `name`, `last_name`, `gender`, `telephone_number`, `email`, `residence`, `image`) VALUES
(104, '1990-12-16', 'paul', 'HABIMANA', 'Male', '0784113888', 'paul@gmail.com', 'Kicukiro', 20),
(109, '1980-01-01', 'ahmed', 'BARIHAMWE', 'Male', '078993434', 'ahmed@gmail.com', 'Kicukiro', 100),
(110, '1979-12-04', 'Ahmed', 'HABIMANA', 'Male', '0788790115', 'ahmed@gmail.com', 'Kimisagara', 101),
(111, '1980-01-01', 'Fabien', 'HABIMANA', 'Male', '0788790115', 'fabien@gmail.com', 'Kicukiro', 102),
(112, '1980-01-01', 'Felicien', 'BAHANUZI', 'Male', '078993434', 'felicien@gmail.com', 'Kicukiro', 103),
(113, '1980-01-01', 'Ferooz', 'BAHANUZI', 'Male', '0788790115', 'felicien@gmail.com', 'Kicukiro', 104),
(114, '1980-01-01', 'Felicien', 'BAHANUZI', 'Male', '0788790115', 'felicien@gmail.com', 'Kicukiro', 105),
(115, '1979-12-19', 'Fabien', 'HABIMANA', 'Male', '0788790115', 'fabien@gmail.com', 'Kimicanga', 106),
(116, '1979-06-13', 'fiacle', 'NSABIMANA', 'Male', '0788456454', 'fiacle@gmail.com', 'Kicukiro', 107),
(117, '1979-11-05', 'Faluki', 'BYIRINGORO', 'Male', '078993434', 'Faluki@gmail.com', 'Nyarungenge', 108),
(118, '1990-01-10', 'Felicien', 'BAHANUZI', 'Male', '078993434', 'felicien@gmail.com', 'Nyagasambu', 109),
(119, '1990-01-10', 'Fabien', 'UWIHANGANYE', 'Male', '0788456454', 'fabien@gmail.com', 'Kicukiro', 110),
(120, '1989-12-20', 'Fiacle', 'UWIMANA', 'Male', '07867676766', 'fiacle@gmail.com', 'Nyamirambo', 111),
(121, '1990-01-10', 'Ferooz', 'SEMANA', 'Male', '0788790115', 'ferooz@gmail.com', 'KACYIRU', 112),
(122, '1990-01-03', 'HABUMUREMYI', 'Musa', 'Male', '0783069600', 'musa@gmail.com', 'RWAMAGANA', 113);

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE `province` (
  `province_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE `sector` (
  `sector_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`sector_id`, `name`) VALUES
(9, 'Nyakaliro');

-- --------------------------------------------------------

--
-- Table structure for table `seed`
--

CREATE TABLE `seed` (
  `seed_id` int(11) NOT NULL,
  `seeddeleted` varchar(60) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `cost_per_unit` int(11) DEFAULT NULL,
  `measure_unit` varchar(60) DEFAULT NULL,
  `qty_m_sq` int(11) DEFAULT NULL,
  `harvest_rate_m_sq` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seed`
--

INSERT INTO `seed` (`seed_id`, `seeddeleted`, `name`, `cost_per_unit`, `measure_unit`, `qty_m_sq`, `harvest_rate_m_sq`) VALUES
(4, 'no', 'Maize', 450, 'kg', 200, 6),
(5, 'no', 'Sorghum', 500, 'kg', 230, 7),
(6, 'no', 'Maize', 200, 'kg', 50, 7);

-- --------------------------------------------------------

--
-- Table structure for table `seed_order`
--

CREATE TABLE `seed_order` (
  `seed_order_id` int(11) NOT NULL,
  `seed_orderdeleted` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `seed` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_measure` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seed_order`
--

INSERT INTO `seed_order` (`seed_order_id`, `seed_orderdeleted`, `date`, `seed`, `account`, `quantity`, `unit_measure`) VALUES
(1, 'no', '2015-12-19', 5, 101, 70, 'kg'),
(2, 'no', '2015-12-19', 5, 101, 80, 'kg'),
(3, 'no', '2017-12-20', 6, 106, 150, 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL,
  `settingsdeleted` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `value` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `village`
--

CREATE TABLE `village` (
  `village_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `village`
--

INSERT INTO `village` (`village_id`, `name`, `cell`) VALUES
(9, '  ngarura', 8),
(10, '  seriba', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `acc_cat_idx` (`account_category`),
  ADD KEY `acc_profl_idx` (`profile`);

--
-- Indexes for table `account_category`
--
ALTER TABLE `account_category`
  ADD PRIMARY KEY (`account_category_id`);

--
-- Indexes for table `cell`
--
ALTER TABLE `cell`
  ADD PRIMARY KEY (`cell_id`);

--
-- Indexes for table `consolidation`
--
ALTER TABLE `consolidation`
  ADD PRIMARY KEY (`consolidation_id`),
  ADD KEY `cons_plot_idx` (`plot`),
  ADD KEY `cons_seed_idx` (`seed`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`contact_us_id`);

--
-- Indexes for table `distribution`
--
ALTER TABLE `distribution`
  ADD PRIMARY KEY (`distribution_id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expenses_id`),
  ADD KEY `distr_expe_idx` (`distribution`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`farmer_id`),
  ADD KEY `farmer_prof_idx` (`profile`);

--
-- Indexes for table `fertilizer`
--
ALTER TABLE `fertilizer`
  ADD PRIMARY KEY (`fertilizer_id`);

--
-- Indexes for table `fertilizer_order`
--
ALTER TABLE `fertilizer_order`
  ADD PRIMARY KEY (`fertilizer_order_id`),
  ADD KEY `fertorder_account_idx` (`account`);

--
-- Indexes for table `harvest`
--
ALTER TABLE `harvest`
  ADD PRIMARY KEY (`harvest_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `plot`
--
ALTER TABLE `plot`
  ADD PRIMARY KEY (`plot_id`),
  ADD KEY `farm_plot_idx` (`farmer`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`profile_id`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`province_id`);

--
-- Indexes for table `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`sector_id`);

--
-- Indexes for table `seed`
--
ALTER TABLE `seed`
  ADD PRIMARY KEY (`seed_id`);

--
-- Indexes for table `seed_order`
--
ALTER TABLE `seed_order`
  ADD PRIMARY KEY (`seed_order_id`),
  ADD KEY `seedorder_acc_idx` (`account`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settings_id`);

--
-- Indexes for table `village`
--
ALTER TABLE `village`
  ADD PRIMARY KEY (`village_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `account_category`
--
ALTER TABLE `account_category`
  MODIFY `account_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cell`
--
ALTER TABLE `cell`
  MODIFY `cell_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `consolidation`
--
ALTER TABLE `consolidation`
  MODIFY `consolidation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `contact_us_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `distribution`
--
ALTER TABLE `distribution`
  MODIFY `distribution_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expenses_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `farmer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `fertilizer`
--
ALTER TABLE `fertilizer`
  MODIFY `fertilizer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `fertilizer_order`
--
ALTER TABLE `fertilizer_order`
  MODIFY `fertilizer_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `harvest`
--
ALTER TABLE `harvest`
  MODIFY `harvest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `plot`
--
ALTER TABLE `plot`
  MODIFY `plot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `province`
--
ALTER TABLE `province`
  MODIFY `province_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sector`
--
ALTER TABLE `sector`
  MODIFY `sector_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `seed`
--
ALTER TABLE `seed`
  MODIFY `seed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seed_order`
--
ALTER TABLE `seed_order`
  MODIFY `seed_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settings_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `village`
--
ALTER TABLE `village`
  MODIFY `village_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `acc_cat` FOREIGN KEY (`account_category`) REFERENCES `account_category` (`account_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `acc_profl` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `consolidation`
--
ALTER TABLE `consolidation`
  ADD CONSTRAINT `cons_plot` FOREIGN KEY (`plot`) REFERENCES `plot` (`plot_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `cons_seed` FOREIGN KEY (`seed`) REFERENCES `seed` (`seed_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `distr_expe` FOREIGN KEY (`distribution`) REFERENCES `distribution` (`distribution_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `farmer`
--
ALTER TABLE `farmer`
  ADD CONSTRAINT `farmer_prof` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `fertilizer_order`
--
ALTER TABLE `fertilizer_order`
  ADD CONSTRAINT `fertorder_account` FOREIGN KEY (`account`) REFERENCES `account` (`account_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `plot`
--
ALTER TABLE `plot`
  ADD CONSTRAINT `farm_plot` FOREIGN KEY (`farmer`) REFERENCES `farmer` (`farmer_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `seed_order`
--
ALTER TABLE `seed_order`
  ADD CONSTRAINT `seedorder_acc` FOREIGN KEY (`account`) REFERENCES `account` (`account_id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
