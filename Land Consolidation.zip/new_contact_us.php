<?php
session_start();

//require_once 'web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
//    header('location:index.php');
}
if (isset($_POST['send_contact_us'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            require_once 'web_db/updates.php';
            $upd_obj = new updates();
            $account = 8;
            $date_contact = date("y-m-d");
            $message = $_POST['txt_message'];
            $obj->update_contact_us($account, $date_contact, $message, $contact_us_id);
        }
    } else {
        require_once 'web_db/new_values.php';
        $obj = new new_values();
        $account = 8;
        $date_contact = date("y-m-d");
        $message = $_POST['txt_message'];
        $obj->new_contact_us($account, $date_contact, $message);
    }
}
?>

<html>
    <head>
        <title>
            contact_us</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>  
    <body>
        <form action="new_contact_us.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <div class="home_bg">      </div>
            <div class="parts eighty_centered home_parts no_paddin_shade_no_Border heit_free" style="box-shadow: none; min-height: 400px;">
                <?php
                include './header_menu.php';
                ?>
                <div class="parts eighty_centered no_paddin_shade_no_Border">   
                    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div> 
                </div>
                <div class="parts eighty_centered off saved_dialog">
                    contact_us saved successfully!
                </div>
                <div class="parts full_center_two_h heit_free skin " >
                    <div class="parts  xx_titles no_shade_noBorder ">  contact_us</div>
                    <table class="new_data_table whilte_text" >
                        <tr><td>message :</td><td> <textarea   name="txt_message" class="textbox"></textarea>        </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_contact_us" value="Save"/>  </td></tr>
                    </table>
                </div>

                <div class="parts eighty_centered datalist_box" >
                    <?php
//                    $obj = new multi_values();
//                    $obj->list_contact_us();
                    ?>

                </div>  
        </form>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </div>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

</body>
</hmtl>
<?php
/*
function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $model->get_chosen_contact_us_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_date_contact_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $date_contact = new multi_values();
            return $model->get_chosen_contact_us_date_contact($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_message_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'contact_us') {
            $id = $_SESSION['id_upd'];
            $message = new multi_values();
            return $model->get_chosen_contact_us_message($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function new_contact_us($account, $date_contact, $message) {
    try {
        require_once('web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $db->prepare("insert into contact_us values(:contact_us_id, :account,  :date_contact,  :message)");
        $stm->execute(array(':contact_us_id' => 0, ':account' => $account, ':date_contact' => $date_contact, ':message' => $message
        ));
    } catch (PDOException $e) {
        echo 'Error .. ' . $e;
    }
}



*/