<div class="parts  full_center_two_h heit_free  no_paddin_shade_no_Border " id="title_holder">      
    <div class="parts  eighty_centered no_shade_noBorder" id="title">

    </div>
</div>       
<div class="parts menu full_center_two_h heit_free no_shade_noBorder">
    <a href="index.php">Home</a>
    <a href="aboutus.php">About us</a>
    <a href="new_contact_us.php">Contact us</a>


    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
